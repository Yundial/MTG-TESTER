# MTG Tester

App per provare i propri mazzi di **Magic: The Gathering** contro un avversario virtuale, tutta in italiano.

- **iPhone (e qualsiasi browser, anche Android)**: web app pubblicata gratis su GitHub Pages, da aggiungere alla schermata Home.
- **Android con Forge**: nella cartella `forge/` ci sono gli stessi mazzi dell'avversario nel formato di Forge
  e la guida per installarlo (`forge/GUIDA_FORGE.md`).

## Cosa fa la web app

- **Archivio mazzi**: crea, modifica, duplica, rinomina, elimina; importa ed esporta liste (Arena, MTGO, Moxfield, file `.dck` di Forge).
- **Ricerca carte** in italiano o in inglese, per codice di set e numero (es. `M10 146`) e con filtri incrociati:
  tipo, colore, costo di mana, rarità, legalità nel formato, testo della carta.
- **Due formati**: 60 carte (20 punti vita) e Commander (100 carte, comandante, 40 punti vita, tassa e 21 danni da comandante).
- **Avversario a 4 livelli** (Difficile e Incubo usano gli stessi mazzi):
  - *Facile* – gioca per divertirsi: Rosso Goblin, Verde Bestioni, Bianco Soldati, Nero Zombi · Commander: Krenko
  - *Medio* – gioca bene ma con calma, ideale per provare i mazzi: Boros Aggro, Dimir Controllo, Golgari Midrange, Izzet Incantesimi · Commander: Talrand
  - *Difficile* – competitivo, neutralizza spesso e usa i trucchi in combattimento; *Incubo* – simula le giocate e gli attacchi prima di decidere:
    Rosso Burn, Azorius Controllo, Gruul Midrange, Rakdos Midrange · Commander: Sheoldred
- **Mazzi dell'avversario modificabili**: prima della partita puoi vederli e cambiarli; la modifica resta salvata.
- **Partita salvata**: se chiudi l'app, la partita si riprende dalla schermata iniziale.
- **Mazzi per Forge**: una schermata con un tasto «Copia» per ogni mazzo (dell'avversario e tuoi), da incollare in Forge su Android.
- **Backup / Ripristino** di mazzi e modifiche in un file `.json`.

### Le regole simulate

Il motore (in `web/js/engine/`) è scritto apposta per questa app: turni e fasi, pila e priorità, mana e pagamento automatico,
combattimento completo (attacco improvviso, doppio attacco, travolgere, tocco letale, legame vitale, volare, raggiungere,
minacciare, cautela, rapidità, difensore…), azioni di stato, regola delle leggende, mulligan londinese, Aure ed Equipaggiamenti,
planeswalker, pedine, Commander.

Gli effetti delle carte vengono letti dal testo oracle inglese di Scryfall: sono gestiti i più comuni (danni, distruzione, esilio,
rimbalzo, pescare, scartare, contromagie, potenziamenti, segnalini, pedine, ricerca nel grimorio, profetizzare, sacrifici,
inneschi di entrata, morte, attacco, mantenimento, "ogni volta che lanci"…). Quando una riga non è capita la carta resta
giocabile con il resto, ed è segnalata con ⚠ nell'editor e nei dettagli della carta.

## Pubblicare il sito (GitHub Pages)

1. Crea un repository pubblico su GitHub e carica il file `progetto.zip` (questa cartella compressa).
2. Crea il file `.github/workflows/build.yml` con il contenuto di `DA_COPIARE_build.yml`
   (dal sito: *Add file → Create new file*, scrivi il percorso completo come nome del file).
3. Nel repository: **Settings → Pages → Source: GitHub Actions**.
4. Nella scheda **Actions** parte *Prova e pubblica il sito*: prima prova il motore, poi pubblica.
   Il sito sarà su `https://<utente>.github.io/<repo>/`.
5. Sull'iPhone apri l'indirizzo con Safari → Condividi → «Aggiungi alla schermata Home».

## Primo avvio

Le carte si scaricano da Scryfall quando servono (serve internet) e restano salvate nel telefono:
dopo la prima partita con un mazzo si può giocare anche offline. I nomi e i testi italiani arrivano in sottofondo.

## Struttura

```
web/                 la web app (HTML/CSS/JavaScript senza librerie)
  js/engine/         motore delle regole: cards.js (lettura dei testi), mana.js, game.js, bot.js
  js/botdecks.js     mazzi dell'avversario
forge/               mazzi per Forge (.dck) e guida per Android
test/                test delle regole, partite bot contro bot, prova dell'interfaccia nel browser
tools/               esportazione dei mazzi per Forge
```

Test in locale (serve Node.js): `node test/rules_test.mjs`, `node test/duel.mjs 2`, `node test/levels.mjs 2`.

## Licenze

Dati e immagini delle carte: [Scryfall](https://scryfall.com). Magic: The Gathering è un marchio di Wizards of the Coast;
questa è un'app non ufficiale per uso personale.
