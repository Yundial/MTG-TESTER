# Giocare con Forge su Android

Forge è un programma gratuito e open source (licenza GPL-3.0) che applica le regole complete di Magic a quasi tutte le carte
e ha un avversario controllato dal computer. Esiste già come app Android: non serve compilarla.

## 1. Installare Forge

1. Sul telefono apri la pagina dei rilasci di Forge: <https://github.com/Card-Forge/forge/releases>
   e scarica l'APK Android più recente (Forge indica come requisiti Android 11 o superiore e almeno 6 GB di RAM).
2. Apri il file scaricato e consenti l'installazione da origini sconosciute, come per i tuoi APK.
3. Al primo avvio Forge scarica da solo i file che gli servono (serve internet e qualche minuto).

L'interfaccia di Forge è in inglese. Se tra le impostazioni trovi la scelta della lingua con l'italiano, puoi attivarla;
i nomi delle carte restano comunque in inglese.

## 2. Caricare i mazzi

In questa cartella trovi gli stessi mazzi dell'avversario di MTG Tester, nel formato di Forge:

```
mazzi/
  60 carte/1 Facile/           Rosso Goblin, Verde Bestioni, Bianco Soldati, Nero Zombi
  60 carte/2 Medio/            Boros Aggro, Dimir Controllo, Golgari Midrange, Izzet Incantesimi
  60 carte/3 Difficile e Incubo/  Rosso Burn, Azorius Controllo, Gruul Midrange, Rakdos Midrange
  Commander/1 Facile/          Krenko
  Commander/2 Medio/           Talrand
  Commander/3 Difficile e Incubo/ Sheoldred
  TUTTE_LE_LISTE.txt           tutte le liste in formato testo, da copiare e incollare
```

**Metodo semplice (copia e incolla):** apri `TUTTE_LE_LISTE.txt`, copia la lista che ti interessa, poi in Forge apri
l'editor dei mazzi (Deck Editor), crea un mazzo nuovo e usa la funzione di importazione (Import) incollando il testo.
Lo stesso vale per i tuoi mazzi: in MTG Tester, nel menu ⋮ del mazzo, tocca «Copia lista» e incollala in Forge.

**Metodo con i file:** copia i file `.dck` nella cartella dei mazzi di Forge sul telefono
(`decks/constructed` per i mazzi da 60 carte, `decks/commander` per Commander). La posizione esatta della cartella dati
dipende dalla versione di Forge e di Android: se non la trovi, usa il metodo del copia e incolla.
Da MTG Tester puoi esportare qualsiasi tuo mazzo come file `.dck` (menu ⋮ → «Esporta per Forge»).

## 3. La difficoltà

In Forge la forza dell'avversario dipende soprattutto dal mazzo che gli dai: per una partita «Facile» scegli per lui
un mazzo della cartella `1 Facile`, per una «Difficile» uno della cartella `3 Difficile e Incubo`.
Nelle impostazioni di Forge c'è anche un profilo di comportamento dell'IA (AI Profile): se la tua versione lo offre,
puoi provare i profili più prudenti o più aggressivi.

## Differenze con MTG Tester

| | MTG Tester (web app) | Forge (Android) |
|---|---|---|
| Funziona su iPhone | sì | no |
| Lingua | italiano | inglese |
| Effetti delle carte | regole base, parole chiave ed effetti più comuni (le carte non gestite sono segnalate) | quasi tutte le carte |
| Difficoltà | 4 livelli dell'avversario | dipende dal mazzo e dal profilo IA |
| Mazzi | archivio, ricerca in italiano, backup | editor di Forge |
