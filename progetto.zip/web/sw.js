// Service worker: tiene in memoria l'app e le immagini delle carte per usarla anche senza rete.
const APP = 'mtgt-app-v1';
const IMG = 'mtgt-img-v1';
const CORE = ['./', 'index.html', 'style.css', 'manifest.webmanifest', 'icon-192.png', 'icon-180.png',
  'js/main.js', 'js/data.js', 'js/store.js', 'js/botdecks.js', 'js/ui_core.js', 'js/ui_decks.js', 'js/ui_game.js',
  'js/engine/cards.js', 'js/engine/mana.js', 'js/engine/game.js', 'js/engine/bot.js'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(APP).then(c => c.addAll(CORE)).catch(() => {}).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== APP && k !== IMG).map(k => caches.delete(k))))
    .then(() => self.clients.claim()));
});

self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET') return;
  // immagini delle carte (Scryfall): prima la copia salvata
  if (url.hostname === 'cards.scryfall.io') {
    e.respondWith(caches.open(IMG).then(async c => {
      const hit = await c.match(e.request);
      if (hit) return hit;
      const r = await fetch(e.request);
      if (r.ok || r.type === 'opaque') c.put(e.request, r.clone());
      return r;
    }));
    return;
  }
  if (url.origin !== location.origin) return;
  // app: prima la rete (per ricevere gli aggiornamenti), poi la copia salvata
  e.respondWith(fetch(e.request).then(r => {
    if (r.ok) { const cl = r.clone(); caches.open(APP).then(c => c.put(e.request, cl)); }
    return r;
  }).catch(() => caches.match(e.request, { ignoreSearch: true }).then(r => r || caches.match('index.html'))));
});
