// Nuova partita (formato, mazzo, difficoltà, avversario) e schermata del duello.
import { ensureCards, nameIt, defByName, Cards } from './data.js';
import { Store, deckCount, deckNames, deckProblems, allNames } from './store.js';
import { BOT_DECKS } from './botdecks.js';
import { h, clear, go, back, home, modal, toast, confirmBox, cardImg, cardDetail, topBar, onLongPress, manaSymbols, closeAllModals } from './ui_core.js';
import { BotEditorScreen, coverOf } from './ui_decks.js';
import {
  createGame, run, respond, defOf, cname, stats, isCreature, isLand, isType, actionInfo, legalActions, STEP_IT, refName, restoreTokens, attackersFor,
} from './engine/game.js';
import { botAnswer, seedBot, LEVELS } from './engine/bot.js';
import { KW_IT } from './engine/cards.js';

export const DIFFS = ['Facile', 'Medio', 'Difficile', 'Incubo'];
const DIFF_DESC = [
  'Gioca per divertirsi: attacca a caso, sbaglia i blocchi e usa poco gli istantanei.',
  'Gioca bene ma con calma: ideale per provare i tuoi mazzi.',
  'Competitivo: neutralizza spesso, rimuove le minacce e usa i trucchi in combattimento.',
  'Simula le giocate e gli attacchi prima di decidere: è dura vincere.',
];
const LVL_NAME = ['Facile', 'Medio', 'Difficile e Incubo'];
export const deckLevel = d => Math.min(d, 2);
export const NG = { step: 0, format: 'constructed', deckId: null, difficulty: 1, botId: null, first: 'random' };

// ------------------------------------------------------------------ nuova partita
export function NewGameScreen(homeScreen) {
  return {
    refreshOnNames: true,
    onBack() { if (NG.step > 0) { NG.step--; this.redraw(); return false; } return true; },
    render(self) {
      const box = h('div.list');
      const nav = h('div.pad-x.row.between');
      self.redraw = () => draw();
      function choice(sel, title, sub, cover, onclick, trailing = null) {
        return h('div.row-card' + (sel ? '.selected' : ''), { onclick },
          cover !== undefined ? cardImg(cover, { cls: 'thumb' }) : null,
          h('div.grow', h('div.title', title), sub ? h('div.muted.small', sub) : null), trailing);
      }
      function draw() {
        clear(box); clear(nav);
        const titles = ['Formato', 'Il tuo mazzo', 'Difficoltà', 'Mazzo dell\'avversario', 'Chi inizia'];
        box.appendChild(h('div.steps', titles.map((t, i) => h('span' + (i === NG.step ? '.on' : i < NG.step ? '.done' : ''), t))));
        if (NG.step === 0) {
          box.append(
            choice(NG.format === 'constructed', '60 carte', 'Duello 1 contro 1 a 20 punti vita (Standard, Pioneer, Modern…)', undefined, () => { NG.format = 'constructed'; NG.deckId = null; NG.botId = null; NG.step = 1; draw(); }),
            choice(NG.format === 'commander', 'Commander', 'Mazzi da 100 carte con comandante, 40 punti vita, 21 danni da comandante', undefined, () => { NG.format = 'commander'; NG.deckId = null; NG.botId = null; NG.step = 1; draw(); }));
        } else if (NG.step === 1) {
          const decks = Store.decks.filter(d => d.format === NG.format);
          if (!decks.length) box.appendChild(h('p.muted.pad', `Non hai ancora mazzi ${NG.format === 'commander' ? 'Commander' : 'da 60 carte'}. Creane uno in «I miei mazzi».`));
          for (const d of decks) {
            const probs = deckProblems(d);
            box.appendChild(choice(NG.deckId === d.id, d.name, `${deckCount(d)} carte${probs.length ? ' · ⚠ ' + probs[0] : ''}`, coverOf(d), () => {
              if (NG.format === 'commander' && !d.commander) { toast('Questo mazzo non ha un comandante'); return; }
              if (deckCount(d) < 20) { toast('Il mazzo ha troppe poche carte'); return; }
              NG.deckId = d.id; NG.step = 2; draw();
            }));
          }
        } else if (NG.step === 2) {
          DIFFS.forEach((t, i) => box.appendChild(choice(NG.difficulty === i, t, DIFF_DESC[i], undefined, () => { NG.difficulty = i; NG.botId = null; NG.step = 3; draw(); })));
        } else if (NG.step === 3) {
          const lvl = deckLevel(NG.difficulty);
          const decks = BOT_DECKS.filter(b => b.format === NG.format);
          const order = [...decks.filter(b => b.level === lvl), ...decks.filter(b => b.level !== lvl)];
          box.appendChild(h('p.small.muted.pad-x', `Consigliati per ${DIFFS[NG.difficulty]}: i primi della lista. Puoi scegliere qualsiasi mazzo, vederlo e modificarlo.`));
          box.appendChild(choice(NG.botId === 'random', 'Casuale', `Un mazzo a caso tra quelli del livello ${LVL_NAME[lvl]}`, undefined, () => { NG.botId = 'random'; NG.step = 4; draw(); }));
          let lastLvl = -1;
          for (const b0 of order) {
            if (b0.level !== lastLvl) { lastLvl = b0.level; box.appendChild(h('div.group-title', LVL_NAME[b0.level])); }
            const b = Store.botDeck(b0.id);
            box.appendChild(choice(NG.botId === b.id, b.name + (Store.isBotModified(b.id) ? ' ✎' : ''), b.desc, b.commander || b.cards.find(x => !/^(Plains|Island|Swamp|Mountain|Forest)$/.test(x.name))?.name,
              () => { NG.botId = b.id; NG.step = 4; draw(); },
              h('button.text.small', { onclick: e => { e.stopPropagation(); go(BotEditorScreen(b.id)); } }, 'Vedi/Modifica')));
          }
        } else if (NG.step === 4) {
          [['random', 'Casuale', 'Si lancia una moneta'], ['me', 'Inizio io', ''], ['bot', 'Inizia l\'avversario', '']].forEach(([k, t, s]) =>
            box.appendChild(choice(NG.first === k, t, s, undefined, () => { NG.first = k; draw(); })));
          const d = Store.get(NG.deckId);
          box.appendChild(h('div.pad.col',
            h('div.small.muted', `Tu: ${d?.name} · Avversario: ${NG.botId === 'random' ? 'casuale' : Store.botDeck(NG.botId)?.name} · ${DIFFS[NG.difficulty]}`),
            h('button.primary.block', { onclick: start }, 'Inizia la partita')));
        }
        if (NG.step > 0) nav.appendChild(h('button.text', { onclick: () => { NG.step--; draw(); } }, '‹ Indietro'));
      }
      function start() {
        const d = Store.get(NG.deckId);
        if (!d) { NG.step = 1; draw(); return; }
        let botId = NG.botId;
        if (botId === 'random') { const pool = BOT_DECKS.filter(b => b.format === NG.format && b.level === deckLevel(NG.difficulty)); botId = pool[Math.floor(Math.random() * pool.length)].id; }
        go(DuelScreen({ format: NG.format, deck: JSON.parse(JSON.stringify(d)), botId, difficulty: NG.difficulty, first: NG.first }, homeScreen));
      }
      draw();
      return { el: h('div.screen', topBar('Nuova partita', () => { if (NG.step > 0) { NG.step--; draw(); } else back(); }), box, nav) };
    },
  };
}

// ------------------------------------------------------------------ duello
export function DuelScreen(config, homeScreen, saved = null) {
  return {
    onBack() { if (this.leave) { this.leave(); return false; } return true; },
    render(self) {
      const root = h('div.screen.duel');
      let G = null, cfg = config, alive = true, timer = null;
      const HUMAN = 0, BOT = 1;
      let ui = { mode: null, sel: new Set(), blocks: [], blockSel: null, attackTgt: {} };
      let lastLog = 0;
      self.leave = () => confirmBox('Abbandonare la partita?', 'La partita in corso verrà chiusa.', 'Abbandona', () => { Store.clearGame(); alive = false; home(homeScreen); });

      async function prepare() {
        clear(root).appendChild(h('div.prep', h('div.spinner'), h('p', 'Preparo le carte…'), h('p.small.muted', 'La prima volta servono internet e qualche secondo.')));
        try {
          if (saved) {
            G = saved.G; cfg = saved.config;
            await ensureCards([...allNames(cfg.deck), ...botNames(cfg.botId)]);
            restoreTokens(G);
          } else {
            const bot = Store.botDeck(cfg.botId);
            const missing = await ensureCards([...allNames(cfg.deck), ...allNames(bot)], t => { const p = root.querySelector('.prep p'); if (p) p.textContent = t; });
            if (missing.length) toast(`${missing.length} carte non trovate: escluse dalla partita`);
            const first = cfg.first === 'me' ? HUMAN : cfg.first === 'bot' ? BOT : null;
            const seed = (Math.random() * 2 ** 31) | 0;
            seedBot(seed);
            G = createGame({ format: cfg.format, seed, first, players: [
              { name: 'Tu', deck: deckNames(cfg.deck), commander: cfg.deck.commander, bot: null },
              { name: bot.name.split(',')[0], deck: deckNames(bot), commander: bot.commander || null, bot: LEVELS[cfg.difficulty] },
            ] });
            G.stopAll = !!Store.opts.stopAll;
            run(G);
          }
        } catch (e) {
          clear(root).appendChild(h('div.prep', h('p.warn', 'Non riesco a caricare le carte. Serve la connessione a internet la prima volta.'), h('p.small.muted', String(e.message || e)),
            h('button.primary', { onclick: prepare }, 'Riprova'), h('button.text', { onclick: () => home(homeScreen) }, 'Torna al menu')));
          return;
        }
        lastLog = G.log.length;
        draw();
        loop();
      }
      function botNames(id) { const b = Store.botDeck(id); return b ? allNames(b) : []; }
      function persist() { if (G && !G.over) Store.saveGame({ config: cfg, G }); }

      // ---- ciclo: il bot risponde da solo, il giocatore tramite l'interfaccia
      function loop() {
        clearTimeout(timer);
        if (!alive || !G) return;
        if (G.over) { draw(); Store.clearGame(); return gameOver(); }
        const P = G.pending;
        if (!P) return;
        if (P.player === BOT) {
          timer = setTimeout(() => {
            if (!alive) return;
            const before = G.log.length;
            try { respond(G, botAnswer(G, LEVELS[cfg.difficulty])); } catch (e) { console.error(e); toast('Errore del motore: ' + e.message); return; }
            const visible = G.log.length !== before;
            if (visible) draw();
            if (visible) persist();
            timer = setTimeout(loop, visible ? 420 / (Store.opts.botSpeed || 1) : 0);
          }, 10);
          return;
        }
        // tocca a noi
        ui = { mode: null, sel: new Set(), blocks: [], blockSel: null, attackTgt: {} };
        if (P.type === 'attack') ui.mode = 'attack';
        if (P.type === 'block') ui.mode = 'block';
        draw();
        persist();
        if (['mulligan', 'choose', 'yesno', 'targets'].includes(P.type)) promptDialog(P);
      }
      function answer(a) {
        closeAllModals();
        ui = { mode: null, sel: new Set(), blocks: [], blockSel: null, attackTgt: {} };
        try { respond(G, a); } catch (e) { console.error(e); toast('Errore: ' + e.message); }
        loop();
      }

      // ---- disegno
      function draw() {
        if (!G) return;
        const P = G.pending;
        const myTurn = G.active === HUMAN;
        const acts = P && P.player === HUMAN && P.type === 'priority' ? P.actions : [];
        const actIds = new Set(acts.map(a => a.id));
        for (const a of acts) if (a.t === 'land') for (const id of G.players[HUMAN].hand) if (G.objs[id].key === G.objs[a.id].key) actIds.add(id);
        clear(root);
        root.append(
          playerBar(BOT),
          field(BOT, actIds),
          centerStrip(),
          field(HUMAN, actIds),
          playerBar(HUMAN),
          handStrip(actIds),
          actionBar(P, myTurn));
      }

      function playerBar(p) {
        const Pl = G.players[p];
        const pool = Object.entries(Pl.pool).flatMap(([c, n]) => Array(Math.max(0, n)).fill('{' + c + '}')).join('');
        const cmdIds = Pl.command;
        const cmdDmg = Math.max(0, ...Object.values(G.players[1 - p].cmdDmg || {}));
        return h('div.pbar.' + (p === HUMAN ? 'me' : 'opp') + (G.active === p ? '.active' : ''),
          h('b', Pl.name),
          h('span.life', '♥ ', h('b', Pl.life)),
          p === BOT ? h('span', '✋', Pl.hand.length) : null,
          h('button.pile', { onclick: () => pileDialog('Grimorio', [], `${Pl.library.length} carte`) }, '📚', Pl.library.length),
          h('button.pile', { onclick: () => pileDialog(`Cimitero (${Pl.name})`, Pl.gy) }, '🪦', Pl.gy.length),
          Pl.exile.length ? h('button.pile', { onclick: () => pileDialog(`Esilio (${Pl.name})`, Pl.exile) }, '⛔', Pl.exile.length) : null,
          cmdIds.length ? h('button.pile', { onclick: () => pileDialog('Zona di comando', cmdIds, Pl.cmdTax ? `Tassa del comandante: +${Pl.cmdTax * 2}` : '') }, '👑', Pl.cmdTax ? `+${Pl.cmdTax * 2}` : '') : null,
          cmdDmg && G.format === 'commander' ? h('span.small.warn', `⚔${cmdDmg}/21`) : null,
          pool ? h('span.small', manaSymbols(pool)) : null,
          h('span.grow'),
          p === BOT ? h('button.icon.small', { onclick: menuDialog, 'aria-label': 'Menu' }, '☰') : null);
      }

      function field(p, actIds) {
        const objs = G.bf.map(id => G.objs[id]).filter(o => o.ctrl === p);
        const lands = objs.filter(o => isLand(o) && !isCreature(G, o));
        const others = objs.filter(o => !lands.includes(o));
        const creatures = others.filter(o => isCreature(G, o) || isType(o, 'planeswalker'));
        const rest = others.filter(o => !creatures.includes(o));
        const mainRow = h('div.frow', creatures.map(o => permTile(o, actIds)));
        const restRow = rest.length ? h('div.frow.small-row', rest.map(o => permTile(o, actIds))) : null;
        const landRow = h('div.frow.lands', groupLands(lands, actIds));
        const box = h('div.field.' + (p === HUMAN ? 'me' : 'opp'));
        if (p === BOT) box.append(landRow, restRow || '', mainRow);
        else box.append(mainRow, restRow || '', landRow);
        if (!creatures.length) mainRow.appendChild(h('div.empty-row', p === BOT ? 'Nessuna creatura avversaria' : 'Nessuna tua creatura'));
        return box;
      }
      function groupLands(lands, actIds) {
        const out = [];
        const groups = new Map();
        for (const o of lands) {
          if (actIds.has(o.id) || o.att || G.combat?.attackers.some(a => a.id === o.id)) { out.push(permTile(o, actIds)); continue; }
          const k = o.key + '|' + o.tapped;
          if (!groups.has(k)) groups.set(k, []);
          groups.get(k).push(o);
        }
        for (const list of groups.values()) out.push(permTile(list[0], actIds, list.length));
        return out;
      }

      function permTile(o, actIds, count = 1) {
        const d = defOf(o);
        const st = isCreature(G, o) ? stats(G, o) : null;
        const C = G.combat;
        const attacking = C?.attackers.some(a => a.id === o.id);
        const blocking = C?.blocks.some(b => b.b === o.id);
        const sel = ui.sel.has(o.id) || ui.blockSel === o.id || ui.blocks.some(b => b.b === o.id);
        const PP = G.pending && G.pending.player === HUMAN ? G.pending : null;
        const canAttack = ui.mode === 'attack' && PP?.type === 'attack' && PP.options.includes(o.id);
        const canBlock = ui.mode === 'block' && PP?.type === 'block' && !!PP.options[o.id];
        const isAttTarget = ui.mode === 'block' && PP?.type === 'block' && ui.blockSel != null && !!PP.options[ui.blockSel]?.includes(o.id);
        const hl = actIds.has(o.id) || canAttack || canBlock || isAttTarget;
        const cls = ['perm', o.tapped ? 'tapped' : '', hl ? 'hl' : '', sel ? 'sel' : '', attacking ? 'attacking' : '', blocking ? 'blocking' : '', isAttTarget ? 'target' : ''].filter(Boolean).join('.');
        const tile = h('div.' + cls, cardImg(o.key.startsWith('tok:') ? null : d.name, { cls: 'cimg' }));
        if (o.key.startsWith('tok:')) { tile.firstChild.remove(); tile.prepend(h('div.card-img.cimg.token', h('div.name-tile.' + (d.colors[0] ? d.colors[0].toLowerCase() : 'colorless'), h('span', d.nameIt), d.power != null ? h('b', `${d.power}/${d.toughness}`) : null))); }
        if (st) {
          const mod = st.p !== d.power || st.t !== d.toughness;
          tile.appendChild(h('div.pt' + (o.dmg ? '.hurt' : mod ? '.buff' : ''), `${st.p}/${st.t - o.dmg}`));
        }
        if (isType(o, 'planeswalker')) tile.appendChild(h('div.loy', o.c.loyalty));
        if (o.c.p1) tile.appendChild(h('div.ctr', `+${o.c.p1}`));
        if (o.c.m1) tile.appendChild(h('div.ctr.neg', `-${o.c.m1}`));
        if (count > 1) tile.appendChild(h('div.cnt', '×' + count));
        if (o.sick && isCreature(G, o) && !(st && st.kw.haste) && o.ctrl === G.active && !o.tapped) tile.appendChild(h('div.zz', 'z'));
        if (o.att) tile.appendChild(h('div.att', '↳ ' + cname(G.objs[o.att] || o)));
        const onIt = G.bf.filter(id => G.objs[id].att === o.id);
        if (onIt.length) tile.appendChild(h('div.att-on', { title: onIt.map(id => cname(G.objs[id])).join(', ') }, '◆' + (onIt.length > 1 ? onIt.length : '')));
        const blockedBy = ui.blocks.filter(b => b.a === o.id).length || C?.blocks.filter(b => b.a === o.id).length;
        if (blockedBy && attacking) tile.appendChild(h('div.ctr.blk', '⛨' + blockedBy));
        tile.addEventListener('click', () => onPerm(o));
        onLongPress(tile, () => detailOf(o));
        return tile;
      }
      function detailOf(o) {
        const d = defOf(o);
        const st = isCreature(G, o) ? stats(G, o) : null;
        const kwList = st ? Object.keys(st.kw).filter(k => st.kw[k] && KW_IT[k]).map(k => KW_IT[k]) : [];
        const onIt = G.bf.filter(id => G.objs[id].att === o.id).map(id => cname(G.objs[id]));
        const extra = [o.tapped ? 'Tappata' : '', onIt.length ? 'Con: ' + onIt.join(', ') : '', o.att ? 'Assegnata a: ' + cname(G.objs[o.att]) : '', o.dmg ? `Danni subiti: ${o.dmg}` : '', o.c.p1 ? `Segnalini +1/+1: ${o.c.p1}` : '', o.sick && st ? 'Appena entrata (non può attaccare)' : '', kwList.length ? 'Abilità: ' + kwList.join(', ') : ''].filter(Boolean).join(' · ');
        if (o.key.startsWith('tok:')) {
          modal({ title: d.nameIt, body: h('div.col', h('div.gold.small', d.typeLine), st ? h('div', `${st.p}/${st.t}`) : null, h('div.small.muted', extra), d.abilities.map(a => h('div.small', a.text || ''))), buttons: [{ label: 'Chiudi', onclick: c => c() }] });
          return;
        }
        cardDetail(d.name, [], { p: st?.p, t: st?.t, kw: st?.kw, loyalty: o.c.loyalty, extra });
      }

      function centerStrip() {
        const P = G.pending;
        const turnOf = G.active === HUMAN ? 'Tuo turno' : 'Turno avversario';
        let msg = '';
        if (P?.player === HUMAN) {
          if (P.type === 'priority') {
            const top = G.stack[G.stack.length - 1];
            msg = top && top.ctrl !== HUMAN ? `${top.name}: vuoi rispondere?` : (G.active === HUMAN && (G.step === 'main1' || G.step === 'main2') ? 'Tocca una carta per giocarla.' : 'Puoi usare istantanei o abilità.');
          } else if (P.type === 'attack') msg = 'Tocca le creature che attaccano.';
          else if (P.type === 'block') msg = ui.blockSel != null ? 'Ora tocca la creatura attaccante da bloccare.' : 'Tocca una tua creatura per bloccare, poi l\'attaccante.';
        } else if (P) msg = 'L\'avversario sta pensando…';
        const stack = G.stack.length ? h('div.stack', [...G.stack].reverse().map((s, i) => h('button.stack-item' + (s.ctrl === HUMAN ? '.me' : '.opp') + (i === 0 ? '.top' : ''),
          { onclick: () => cardDetail(defOf(G.objs[s.src])?.name || s.key) },
          h('b', s.name), s.trig ? ' (innesco)' : s.kind === 'ability' ? ' (abilità)' : '',
          s.targets?.flat().length ? h('span.small', ' → ' + s.targets.flat().map(r => refName(G, r)).join(', ')) : null))) : null;
        const last = G.log.slice(-2).map(l => l.text);
        return h('div.center',
          h('div.row.between.small', h('span.gold', `${turnOf} · ${STEP_IT[G.step] || ''}`), h('button.text.small', { onclick: logDialog }, 'Registro')),
          stack,
          h('div.logline.small', last.map(t => h('div.ellipsis', t))),
          msg ? h('div.msg', msg) : null);
      }

      function handStrip(actIds) {
        const Pl = G.players[HUMAN];
        const cards = [...Pl.hand, ...Pl.command.filter(id => actIds.has(id))];
        const strip = h('div.hand');
        for (const id of cards) {
          const o = G.objs[id];
          const tile = h('div.hand-card' + (actIds.has(id) ? '.hl' : '') + (o.zone === 'command' ? '.cmd' : ''), cardImg(defOf(o).name));
          tile.addEventListener('click', () => onHand(o));
          onLongPress(tile, () => cardDetail(defOf(o).name));
          strip.appendChild(tile);
        }
        if (!cards.length) strip.appendChild(h('div.muted.small.pad', 'Nessuna carta in mano'));
        return strip;
      }

      function actionBar(P, myTurn) {
        const bar = h('div.actionbar');
        if (!P || P.player !== HUMAN) { bar.appendChild(h('div.busy.grow', h('div.bar'))); return bar; }
        if (P.type === 'priority') {
          const top = G.stack[G.stack.length - 1];
          let label = 'Continua';
          if (top) label = top.ctrl === HUMAN ? 'Risolvi' : 'Lascia risolvere';
          else if (myTurn && G.step === 'main1') label = attackersFor(G, HUMAN).length ? 'Vai al combattimento' : 'Fine turno';
          else if (myTurn && G.step === 'main2') label = 'Fine turno';
          else if (!myTurn && G.step === 'end') label = 'Passa';
          bar.appendChild(h('button.primary', { onclick: () => answer({ pass: true }) }, label));
        } else if (P.type === 'attack') {
          bar.append(
            h('button.outline', { onclick: () => { P.options.forEach(id => ui.sel.add(id)); draw(); } }, 'Tutte'),
            h('button.primary', { onclick: confirmAttack }, ui.sel.size ? `Attacca con ${ui.sel.size}` : 'Non attaccare'));
        } else if (P.type === 'block') {
          bar.append(
            ui.blocks.length ? h('button.outline', { onclick: () => { ui.blocks = []; ui.blockSel = null; draw(); } }, 'Annulla blocchi') : null,
            h('button.primary', { onclick: () => answer({ blocks: ui.blocks }) }, ui.blocks.length ? `Conferma ${ui.blocks.length} blocc${ui.blocks.length === 1 ? 'o' : 'hi'}` : 'Nessun blocco'));
        } else {
          bar.appendChild(h('button.primary', { onclick: () => promptDialog(P) }, 'Rispondi'));
        }
        return bar;
      }

      // ---- interazione
      function onHand(o) {
        const P = G.pending;
        const acts = P?.player === HUMAN && P.type === 'priority' ? P.actions.filter(a => a.id === o.id || (a.t === 'land' && G.objs[a.id].key === o.key)) : [];
        if (!acts.length) { cardDetail(defOf(o).name); return; }
        actionMenu(o, acts);
      }
      function onPerm(o) {
        const P = G.pending;
        if (ui.mode === 'attack') {
          if (P.options.includes(o.id)) { if (ui.sel.has(o.id)) ui.sel.delete(o.id); else ui.sel.add(o.id); draw(); }
          else detailOf(o);
          return;
        }
        if (ui.mode === 'block') {
          if (P.options[o.id]) {
            const i = ui.blocks.findIndex(b => b.b === o.id);
            if (i >= 0) { ui.blocks.splice(i, 1); ui.blockSel = null; }
            else ui.blockSel = ui.blockSel === o.id ? null : o.id;
            draw(); return;
          }
          if (ui.blockSel != null && P.options[ui.blockSel]?.includes(o.id)) { ui.blocks.push({ b: ui.blockSel, a: o.id }); ui.blockSel = null; draw(); return; }
          detailOf(o); return;
        }
        const acts = P?.player === HUMAN && P.type === 'priority' ? P.actions.filter(a => a.id === o.id) : [];
        if (!acts.length) { detailOf(o); return; }
        actionMenu(o, acts);
      }
      function confirmAttack() {
        const P = G.pending;
        const list = [...ui.sel];
        const pws = P.targets.filter(t => t.id !== undefined);
        if (!pws.length || !list.length) { answer({ attacks: list.map(id => ({ id })) }); return; }
        // ci sono planeswalker avversari: si sceglie chi attaccare
        const tgts = {};
        let i = 0;
        const ask = () => {
          if (i >= list.length) { answer({ attacks: list.map(id => ({ id, tgt: tgts[id] })) }); return; }
          const id = list[i];
          modal({ title: `${cname(G.objs[id])} attacca…`, dismissable: false, body: h('div.menu',
            h('button.menu-item', { onclick: () => { closeAllModals(); tgts[id] = { p: BOT }; i++; ask(); } }, `${G.players[BOT].name} (${G.players[BOT].life} punti vita)`),
            pws.map(t => h('button.menu-item', { onclick: () => { closeAllModals(); tgts[id] = { id: t.id }; i++; ask(); } }, `${cname(G.objs[t.id])} (fedeltà ${G.objs[t.id].c.loyalty})`))) });
        };
        ask();
      }

      function actionMenu(o, acts) {
        const d = defOf(o);
        const btns = acts.map(a => {
          let label;
          if (a.t === 'land') label = 'Gioca questa terra';
          else if (a.t === 'cast') { const info = actionInfo(G, HUMAN, a); label = h('span', 'Lancia ', manaSymbols(info.cost.replace(/ \+\d+$/, '')), info.cost.match(/ \+\d+$/) ? ` (tassa${info.cost.match(/ \+\d+$/)[0]})` : ''); }
          else { const ab = d.abilities[a.ai]; label = ab.equip ? 'Equipaggia' : (ab.text || 'Attiva abilità'); }
          return h('button.action-btn', { onclick: () => { closeAllModals(); startAction(a); } }, label);
        });
        modal({ title: nameIt(d.name), wide: true, body: h('div.col', h('div.row', h('div.thumb-lg', { onclick: () => cardDetail(d.name) }, cardImg(d.name)), h('div.grow.small', d.textIt || d.oracle)), btns),
          buttons: [{ label: 'Dettagli', onclick: c => { c(); cardDetail(d.name); } }, { label: 'Annulla', onclick: c => c() }] });
      }

      /** Raccoglie le scelte (modalità, X, sacrifici, bersagli) e invia l'azione */
      function startAction(a) {
        const info = actionInfo(G, HUMAN, a);
        const full = { ...a };
        const steps = [];
        if (info.modes) steps.push(next => pickMode(info, m => { full.mode = m; next(); }));
        if (info.xMax > 0 || (a.t === 'cast' && defOf(G.objs[a.id]).cost.X)) steps.push(next => pickX(info.xMax, x => { full.x = x; next(); }));
        if (info.sac) steps.push(next => pickCards('Scegli cosa sacrificare', info.sac.options, info.sac.n, info.sac.n, ids => { full.sac = ids; next(); }, true));
        steps.push(next => {
          const specs = info.modes ? info.modes.find(m => m.i === full.mode).specs : info.specs;
          if (!specs.length) { full.targets = []; next(); return; }
          pickTargets(specs, defOf(G.objs[a.id]).name, t => { full.targets = t; next(); }, true);
        });
        let k = 0;
        const nextStep = () => { if (k < steps.length) steps[k++](nextStep); else answer(full); };
        nextStep();
      }
      function pickMode(info, done) {
        modal({ title: 'Scegli una modalità', wide: true, body: h('div.menu', info.modes.map(m => h('button.menu-item' + (m.ok ? '' : '.disabled'), { onclick: () => { if (!m.ok) { toast('Nessun bersaglio valido'); return; } closeAllModals(); done(m.i); } }, m.text))),
          buttons: [{ label: 'Annulla', onclick: c => c() }] });
      }
      function pickX(max, done) {
        let x = Math.max(0, max);
        const val = h('b.xval', x);
        modal({ title: 'Scegli il valore di X', body: h('div.row.center-row', h('button.qty', { onclick: () => { x = Math.max(0, x - 1); val.textContent = x; } }, '−'), val, h('button.qty', { onclick: () => { x = Math.min(max, x + 1); val.textContent = x; } }, '+'), h('span.small.muted', `max ${max}`)),
          buttons: [{ label: 'Annulla', onclick: c => c() }, { label: 'Conferma', kind: 'text.gold', onclick: c => { c(); done(x); } }] });
      }
      function refTile(r, selected, onclick) {
        if (r.p !== undefined) return h('div.pcell' + (selected ? '.on' : ''), { onclick }, h('div.pimg.player-tile', h('b', r.p === HUMAN ? 'Tu' : G.players[r.p].name), h('span', '♥ ' + G.players[r.p].life)), h('div.tiny.center', 'Giocatore'));
        if (r.sid !== undefined) { const s = G.stack.find(x => x.sid === r.sid); return h('div.pcell' + (selected ? '.on' : ''), { onclick }, h('div.pimg', cardImg(defOf(G.objs[s.src]).name)), h('div.tiny.center', (s.ctrl === HUMAN ? 'tua: ' : 'avv.: ') + s.name)); }
        const o = G.objs[r.id];
        const st = isCreature(G, o) && o.zone === 'bf' ? stats(G, o) : null;
        const lbl = (o.zone === 'gy' ? 'cimitero · ' : '') + (o.ctrl === HUMAN || (o.zone !== 'bf' && o.owner === HUMAN) ? 'tua' : 'avversario') + (st ? ` · ${st.p}/${st.t - o.dmg}` : '');
        return h('div.pcell' + (selected ? '.on' : ''), { onclick }, h('div.pimg', o.key.startsWith('tok:') ? h('div.card-img', h('div.name-tile.colorless', h('span', cname(o)))) : cardImg(defOf(o).name)), h('div.tiny.center', lbl));
      }
      function pickTargets(specs, title, done, cancellable) {
        const chosen = specs.map(() => []);
        let i = 0;
        const ask = () => {
          if (i >= specs.length) { done(chosen); return; }
          const { spec, options } = specs[i];
          const n = spec.count || 1;
          const sel = [];
          const grid = h('div.pgrid');
          const drawGrid = () => {
            clear(grid);
            options.forEach(r => grid.appendChild(refTile(r, sel.includes(r), () => {
              const k = sel.indexOf(r);
              if (k >= 0) sel.splice(k, 1); else { if (sel.length >= n) sel.shift(); sel.push(r); }
              drawGrid();
              if (n === 1 && !spec.upTo) { closeAllModals(); chosen[i] = [...sel]; i++; ask(); }
            })));
          };
          drawGrid();
          const kind = { any: 'un bersaglio (creatura, planeswalker o giocatore)', player: 'un giocatore', opp: 'un avversario', playerpw: 'un giocatore o planeswalker', spell: 'una magia in pila', card: 'una carta nel cimitero', obj: 'un permanente' }[spec.kind];
          modal({ title: `${nameIt(title)}: scegli ${n > 1 ? 'fino a ' + n + ' bersagli' : kind}`, wide: true, dismissable: false, body: grid, buttons: [
            cancellable ? { label: 'Annulla', onclick: c => c() } : null,
            n > 1 || spec.upTo ? { label: 'Conferma', kind: 'text.gold', onclick: c => { if (!spec.upTo && !sel.length) { toast('Scegli almeno un bersaglio'); return; } c(); chosen[i] = [...sel]; i++; ask(); } } : null,
          ].filter(Boolean) });
        };
        ask();
      }
      function pickCards(title, ids, min, max, done, cancellable, extra = null) {
        const sel = [];
        const grid = h('div.pgrid');
        const counter = h('span.small.muted');
        const drawGrid = () => {
          clear(grid);
          for (const id of ids) {
            const o = G.objs[id];
            const k = sel.indexOf(id);
            grid.appendChild(h('div.pcell' + (k >= 0 ? '.on' : ''), { onclick: () => { if (k >= 0) sel.splice(k, 1); else { if (sel.length >= max) sel.shift(); sel.push(id); } drawGrid(); } },
              h('div.pimg', o.key.startsWith('tok:') ? h('div.card-img', h('div.name-tile.colorless', h('span', cname(o)))) : cardImg(defOf(o).name), k >= 0 && max > 1 ? h('span.badge', k + 1) : null),
              h('div.tiny.center.ellipsis', cname(o))));
          }
          counter.textContent = `Scelte ${sel.length}${max !== min ? ` (da ${min} a ${max})` : ` di ${min}`}`;
        };
        drawGrid();
        modal({ title, wide: true, dismissable: false, body: h('div.col', extra, counter, grid), buttons: [
          cancellable ? { label: 'Annulla', onclick: c => c() } : null,
          { label: 'Dettagli', onclick: () => { if (sel.length) cardDetail(defOf(G.objs[sel[sel.length - 1]]).name); else toast('Seleziona una carta'); } },
          { label: 'Conferma', kind: 'text.gold', onclick: c => { if (sel.length < min) { toast(`Scegline ${min}`); return; } c(); done([...sel]); } },
        ].filter(Boolean) });
      }

      function promptDialog(P) {
        if (P.type === 'mulligan') {
          const hand = G.players[HUMAN].hand;
          modal({ title: P.mulls ? `Mano dopo ${P.mulls} mulligan` : 'La tua mano iniziale', wide: true, dismissable: false, body: h('div.col',
            h('div.pgrid', hand.map(id => h('div.pcell', { onclick: () => cardDetail(defOf(G.objs[id]).name) }, h('div.pimg', cardImg(defOf(G.objs[id]).name))))),
            h('p.small.muted', `Terre: ${hand.filter(id => isLand(G.objs[id])).length}. ${P.bottom ? `Se tieni, metterai ${P.bottom} cart${P.bottom === 1 ? 'a' : 'e'} in fondo al grimorio.` : ''} ${G.startPlayer === HUMAN ? 'Inizi tu.' : 'Inizia l\'avversario.'}`)),
          buttons: [{ label: 'Mulligan', onclick: () => answer({ keep: false }) }, { label: 'Tengo', kind: 'text.gold', onclick: () => answer({ keep: true }) }] });
          return;
        }
        if (P.type === 'choose') {
          const extra = P.purpose === 'scry' || P.purpose === 'surveil' ? h('p.small.muted', 'Le carte non scelte restano in cima al grimorio nello stesso ordine.') : P.cultivate ? h('p.small.muted', 'La prima carta scelta va sul campo tappata, la seconda in mano.') : null;
          const list = P.purpose === 'search' ? [...P.cards].sort((x, y) => cname(G.objs[x]).localeCompare(cname(G.objs[y]))).filter((id, i, arr) => i === arr.findIndex(z => G.objs[z].key === G.objs[id].key)) : P.cards;
          pickCards(P.title, list, Math.min(P.min, list.length), P.max, ids => answer({ ids }), false, extra);
          return;
        }
        if (P.type === 'yesno') {
          modal({ title: P.title, dismissable: false, body: h('div.col', P.card ? h('div.row', h('div.thumb-lg', cardImg(defByName(P.card) ? P.card : null)), h('div.small.grow', P.text || '')) : null),
            buttons: [{ label: 'No', onclick: () => answer({ yes: false }) }, { label: 'Sì', kind: 'text.gold', onclick: () => answer({ yes: true }) }] });
          return;
        }
        if (P.type === 'targets') {
          pickTargets(P.specs, P.title.split(':')[0], t => answer({ targets: t }), false);
        }
      }

      // ---- finestre varie
      function pileDialog(title, ids, note = '') {
        modal({ title, wide: true, body: h('div.col', note ? h('p.small.muted', note) : null, ids.length ? h('div.pgrid', [...ids].reverse().map(id => {
          const o = G.objs[id];
          return h('div.pcell', { onclick: () => cardDetail(defOf(o).name) }, h('div.pimg', cardImg(defOf(o).name)), h('div.tiny.center.ellipsis', cname(o)));
        })) : h('p.muted', ids === undefined ? '' : (note ? '' : 'Vuoto'))), buttons: [{ label: 'Chiudi', onclick: c => c() }] });
      }
      function logDialog() {
        const box = h('div.logbox', G.log.slice(-200).map(l => h('div' + (l.p === HUMAN ? '.me' : l.p === BOT ? '.opp' : '.sys'), l.text)));
        modal({ title: 'Registro della partita', wide: true, body: box, buttons: [{ label: 'Chiudi', onclick: c => c() }] });
        setTimeout(() => { box.scrollTop = box.scrollHeight; }, 30);
      }
      function menuDialog() {
        const stop = h('input', { type: 'checkbox', checked: !!G.stopAll, onchange: e => { G.stopAll = e.target.checked; Store.opts.stopAll = G.stopAll; Store.saveOpts(); } });
        const fast = h('input', { type: 'checkbox', checked: (Store.opts.botSpeed || 1) > 1, onchange: e => { Store.opts.botSpeed = e.target.checked ? 3 : 1; Store.saveOpts(); } });
        modal({ title: 'Partita', body: h('div.col',
          h('label.option', stop, h('span', 'Fermati a ogni passaggio (per usare istantanei in qualsiasi momento)')),
          h('label.option', fast, h('span', 'Mosse dell\'avversario veloci')),
          h('div.small.muted', `Avversario: ${G.players[BOT].name} · ${DIFFS[cfg.difficulty]}`),
          h('button.outline', { onclick: () => { closeAllModals(); logDialog(); } }, 'Registro della partita'),
          h('button.outline', { onclick: () => { closeAllModals(); botDeckDialog(); } }, 'Lista del mazzo avversario'),
          h('button.outline.danger', { onclick: () => { closeAllModals(); confirmBox('Arrendersi?', 'La partita finisce con la tua sconfitta.', 'Mi arrendo', () => { G.players[HUMAN].life = 0; G.over = { winner: BOT, reason: 'Ti sei arreso.' }; Store.clearGame(); draw(); gameOver(); }); } }, 'Arrenditi'),
          h('button.text.danger', { onclick: () => { closeAllModals(); self.leave(); } }, 'Esci dalla partita')),
        buttons: [{ label: 'Chiudi', onclick: c => c() }] });
      }
      function botDeckDialog() {
        const b = Store.botDeck(cfg.botId);
        modal({ title: b.name, wide: true, body: h('div.col', b.commander ? h('div', '👑 ', nameIt(b.commander)) : null, b.cards.map(x => h('div.small', `${x.n} ${nameIt(x.name)}`))), buttons: [{ label: 'Chiudi', onclick: c => c() }] });
      }
      function gameOver() {
        const w = G.over.winner;
        const title = w === HUMAN ? '🏆 Hai vinto!' : w === BOT ? 'Hai perso' : 'Pareggio';
        modal({ title, dismissable: false, body: h('div.col', h('p', G.over.reason), h('p.small.muted', `Turni giocati: ${G.turn}`)), buttons: [
          { label: 'Registro', onclick: () => logDialog() },
          { label: 'Menu', onclick: () => { closeAllModals(); alive = false; home(homeScreen); } },
          { label: 'Rivincita', kind: 'text.gold', onclick: () => { closeAllModals(); alive = false; home(homeScreen); go(DuelScreen({ ...cfg }, homeScreen)); } },
        ] });
      }

      prepare();
      return { el: root, cleanup: () => { alive = false; clearTimeout(timer); } };
    },
  };
}
void legalActions; void back; void Cards;
