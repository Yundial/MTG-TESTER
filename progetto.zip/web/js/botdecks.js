// Mazzi dell'avversario virtuale. level: 0 = Facile, 1 = Medio, 2 = Difficile e Incubo.
// Le liste sono nel formato "quantità Nome inglese", lo stesso dell'importazione.

export const BOT_DECKS = [
  // ------------------------------------------------------------------ 60 carte · Facile
  { id: 'f-goblin', level: 0, format: 'constructed', colors: 'R', name: 'Rosso Goblin', desc: 'Goblin e fulmini da set base: attacca appena può.', list: `
4 Raging Goblin
4 Goblin Piker
4 Gray Ogre
4 Hill Giant
2 Fire Elemental
2 Goblin Instigator
2 Beetleback Chief
4 Shock
4 Lightning Strike
4 Krenko's Command
2 Volcanic Hammer
24 Mountain` },
  { id: 'f-verde', level: 0, format: 'constructed', colors: 'G', name: 'Verde Bestioni', desc: 'Creature grosse e Crescita Gigante.', list: `
4 Llanowar Elves
4 Grizzly Bears
4 Trained Armodon
4 Centaur Courser
3 Giant Spider
3 Craw Wurm
2 Pelakka Wurm
4 Giant Growth
4 Titanic Growth
4 Rampant Growth
24 Forest` },
  { id: 'f-bianco', level: 0, format: 'constructed', colors: 'W', name: 'Bianco Soldati', desc: 'Tante piccole creature e Inno Glorioso.', list: `
4 Savannah Lions
4 Elite Vanguard
4 Healer's Hawk
4 Ajani's Pridemate
4 Benalish Marshal
3 Serra Angel
4 Raise the Alarm
3 Pacifism
2 Glorious Anthem
4 Inspired Charge
24 Plains` },
  { id: 'f-nero', level: 0, format: 'constructed', colors: 'B', name: 'Nero Zombi', desc: 'Non morti, Omicidio e scarti.', list: `
4 Diregraf Ghoul
4 Walking Corpse
4 Typhoid Rats
4 Vampire Interloper
3 Vampire Nighthawk
3 Gravedigger
2 Sengir Vampire
4 Murder
3 Sign in Blood
3 Mind Rot
2 Moment of Craving
24 Swamp` },
  // ------------------------------------------------------------------ 60 carte · Medio
  { id: 'm-boros', level: 1, format: 'constructed', colors: 'RW', name: 'Boros Aggro', desc: 'Creature veloci e bruciature, chiude in fretta.', list: `
4 Monastery Swiftspear
4 Savannah Lions
4 Skyknight Legionnaire
4 Ajani's Pridemate
2 Serra Angel
4 Lightning Bolt
4 Lightning Helix
4 Searing Spear
3 Boros Charm
3 Inspired Charge
4 Sacred Foundry
4 Inspiring Vantage
8 Plains
8 Mountain` },
  { id: 'm-dimir', level: 1, format: 'constructed', colors: 'UB', name: 'Dimir Controllo', desc: 'Neutralizza, rimuove e pesca: vince alla lunga.', list: `
4 Opt
4 Counterspell
3 Mana Leak
4 Doom Blade
2 Murder
3 Hero's Downfall
2 Divination
4 Baleful Strix
3 Cloudkin Seer
3 Ravenous Chupacabra
2 Mulldrifter
2 Air Elemental
4 Watery Grave
4 Drowned Catacomb
8 Island
8 Swamp` },
  { id: 'm-golgari', level: 1, format: 'constructed', colors: 'BG', name: 'Golgari Midrange', desc: 'Creature solide, guadagno di vita e rimozioni.', list: `
4 Llanowar Elves
4 Gifted Aetherborn
4 Vampire Nighthawk
4 Centaur Courser
3 Thragtusk
2 Pelakka Wurm
4 Ravenous Chupacabra
4 Cast Down
3 Vraska's Contempt
2 Rampant Growth
2 Sign in Blood
4 Overgrown Tomb
4 Woodland Cemetery
8 Forest
8 Swamp` },
  { id: 'm-izzet', level: 1, format: 'constructed', colors: 'UR', name: 'Izzet Incantesimi', desc: 'Istantanei e stregonerie che generano pedine.', list: `
4 Monastery Swiftspear
4 Young Pyromancer
3 Third Path Iconoclast
2 Talrand, Sky Summoner
4 Opt
4 Lightning Bolt
2 Searing Spear
3 Izzet Charm
3 Frost Bite
3 Negate
2 Counterspell
2 Think Twice
4 Steam Vents
4 Spirebluff Canal
8 Island
8 Mountain` },
  // ------------------------------------------------------------------ 60 carte · Difficile e Incubo
  { id: 'd-burn', level: 2, format: 'constructed', colors: 'R', name: 'Rosso Burn', desc: 'Stile Modern: brucia i punti vita in pochi turni.', list: `
4 Goblin Guide
4 Monastery Swiftspear
4 Burning-Tree Emissary
4 Bonecrusher Giant
4 Lightning Bolt
4 Lava Spike
4 Rift Bolt
4 Skewer the Critics
4 Searing Spear
4 Play with Fire
20 Mountain` },
  { id: 'd-azorius', level: 2, format: 'constructed', colors: 'WU', name: 'Azorius Controllo', desc: 'Contromagie, sterminio e angeli per chiudere.', list: `
4 Opt
4 Counterspell
2 Absorb
3 Dovin's Veto
4 Path to Exile
2 Supreme Verdict
2 Wrath of God
3 Banishing Light
2 Sphinx's Revelation
2 Think Twice
2 Cloudkin Seer
3 Lyra Dawnbringer
2 Baneslayer Angel
4 Hallowed Fountain
4 Glacial Fortress
9 Island
8 Plains` },
  { id: 'd-gruul', level: 2, format: 'constructed', colors: 'RG', name: 'Gruul Midrange', desc: 'Accelera, combatte e travolge.', list: `
4 Llanowar Elves
4 Burning-Tree Emissary
4 Bonecrusher Giant
3 Steel Leaf Champion
3 Questing Beast
3 Thragtusk
3 Stormbreath Dragon
4 Lightning Bolt
4 Searing Spear
4 Domri's Ambush
4 Stomping Ground
4 Rootbound Crag
4 Karplusan Forest
6 Forest
6 Mountain` },
  { id: 'd-rakdos', level: 2, format: 'constructed', colors: 'BR', name: 'Rakdos Midrange', desc: 'Rimuove tutto e attacca con creature resistenti.', list: `
4 Dreadhorde Butcher
4 Vampire Nighthawk
2 Gifted Aetherborn
4 Bonecrusher Giant
2 Murderous Rider
3 Ravenous Chupacabra
4 Lightning Bolt
4 Terminate
3 Dreadbore
2 Hero's Downfall
2 Anger of the Gods
2 Sign in Blood
4 Blood Crypt
4 Dragonskull Summit
8 Swamp
8 Mountain` },
  // ------------------------------------------------------------------ Commander
  { id: 'c-krenko', level: 0, format: 'commander', colors: 'R', name: 'Krenko, Boss della Cosca', commander: 'Krenko, Mob Boss', desc: 'Commander Goblin: invade il campo di pedine.', list: `
1 Sol Ring
1 Arcane Signet
1 Mind Stone
1 Fire Diamond
1 Commander's Sphere
1 Wayfarer's Bauble
1 Raging Goblin
1 Goblin Piker
1 Goblin Instigator
1 Beetleback Chief
1 Mogg War Marshal
1 Siege-Gang Commander
1 Goblin Chieftain
1 Goblin Matron
1 Goblin King
1 Goblin Warchief
1 Mogg Fanatic
1 Goblin Bombardment
1 Goblin Arsonist
1 Goblin Heelcutter
1 Legion Loyalist
1 Hordeling Outburst
1 Krenko's Command
1 Dragon Fodder
1 Goblin Rally
1 Shock
1 Lightning Bolt
1 Lightning Strike
1 Volcanic Hammer
1 Searing Spear
1 Hill Giant
1 Gray Ogre
1 Fire Elemental
1 Shivan Dragon
1 Furnace Whelp
1 Goblin Sky Raider
1 Goblin Guide
1 Monastery Swiftspear
1 Bonecrusher Giant
1 Skewer the Critics
1 Lava Spike
1 Rift Bolt
1 Play with Fire
1 Ember Hauler
1 Ogre Battledriver
1 Impact Tremors
1 Goblin Oriflamme
1 Fervor
1 Brute Force
1 Titan's Strength
1 Stoke the Flames
1 Incinerate
1 Flame Slash
1 Vulshok Morningstar
1 Bonesplitter
1 Goblin Rabblemaster
1 Blaze
1 Goblin Tunneler
1 Battle-Rattle Shaman
1 Goblin Motivator
1 Goblin Shortcutter
1 Mogg Raider
1 Ghitu Lavarunner
36 Mountain` },
  { id: 'c-talrand', level: 1, format: 'commander', colors: 'U', name: 'Talrand, Evocatore Celeste', commander: 'Talrand, Sky Summoner', desc: 'Commander di istantanei e stregonerie: ogni magia crea un Drake.', list: `
1 Sol Ring
1 Arcane Signet
1 Mind Stone
1 Sky Diamond
1 Commander's Sphere
1 Thought Vessel
1 Wayfarer's Bauble
1 Opt
1 Think Twice
1 Divination
1 Deep Analysis
1 Counterspell
1 Mana Leak
1 Negate
1 Essence Scatter
1 Cancel
1 Dissolve
1 Exclude
1 Syncopate
1 Quench
1 Spell Pierce
1 Annul
1 Remove Soul
1 Censor
1 Lose Focus
1 Mystical Dispute
1 Unsummon
1 Into the Roil
1 Blink of an Eye
1 Cyclonic Rift
1 Vapor Snag
1 Aetherize
1 Evacuation
1 Frost Breath
1 Sleep Paralysis
1 Cloudkin Seer
1 Air Elemental
1 Mulldrifter
1 Sphinx of Magosi
1 Serendib Efreet
1 Man-o'-War
1 Riftwing Cloudskate
1 Murmuring Mystic
1 Archaeomancer
1 Mnemonic Wall
1 Phantom Monster
1 Wind Drake
1 Thieving Magpie
1 Spectral Sailor
1 Aether Adept
1 Exclusion Mage
1 Sphinx of Uthuun
1 Cloud Elemental
1 Coral Barrier
1 Wall of Frost
1 Mahamoti Djinn
1 Air Servant
1 Frost Lynx
1 Waterknot
1 Warden of Evos Isle
1 Storm Crow
1 Faerie Miscreant
37 Island` },
  { id: 'c-sheoldred', level: 2, format: 'commander', colors: 'B', name: "Sheoldred, l'Apocalisse", commander: 'Sheoldred, the Apocalypse', desc: 'Commander nero: rimozioni a ripetizione e prosciuga i punti vita.', list: `
1 Sol Ring
1 Arcane Signet
1 Mind Stone
1 Charcoal Diamond
1 Commander's Sphere
1 Wayfarer's Bauble
1 Thought Vessel
1 Dark Ritual
1 Demonic Tutor
1 Diabolic Tutor
1 Murder
1 Doom Blade
1 Go for the Throat
1 Hero's Downfall
1 Cast Down
1 Snuff Out
1 Dismember
1 Infernal Grasp
1 Bloodchief's Thirst
1 Eviscerate
1 Victim of Night
1 Deadly Rollick
1 Damnation
1 Languish
1 Sheoldred's Edict
1 Liliana's Triumph
1 Diabolic Edict
1 Geth's Verdict
1 Sign in Blood
1 Night's Whisper
1 Read the Bones
1 Ambition's Cost
1 Phyrexian Arena
1 Mind Rot
1 Vampire Nighthawk
1 Gifted Aetherborn
1 Typhoid Rats
1 Gravedigger
1 Ravenous Chupacabra
1 Shriekmaw
1 Nekrataal
1 Noxious Gearhulk
1 Grave Titan
1 Massacre Wurm
1 Sengir Vampire
1 Vampire of the Dire Moon
1 Bloodgift Demon
1 Vampire Sovereign
1 Phyrexian Rager
1 Dusk Legion Zealot
1 Liliana Vess
1 Midnight Reaper
1 Gray Merchant of Asphodel
1 Vampire Nocturnus
1 Dread Shade
1 Erebos's Titan
1 Kalastria Highborn
1 Desecration Demon
1 Phyrexian Obliterator
1 Withered Wretch
1 Fleshbag Marauder
1 Murderous Cut
37 Swamp` },
];

/** "4 Lightning Bolt" -> [{ n, name }] */
export function parseList(text) {
  const out = [];
  for (const raw of String(text).split(/\r?\n/)) {
    const l = raw.trim();
    const m = l.match(/^(\d+)x?\s+(.+?)\s*$/);
    if (m) out.push({ n: +m[1], name: m[2] });
  }
  return out;
}
