// Archivio mazzi, editor (ricerca su Scryfall in italiano + filtri), mazzi dell'avversario, backup.
import { card, ensureCards, searchCards, remember, FILTERS, nameIt, defByName, previewDef, clearCache, Cards } from './data.js';
import { BOT_DECKS } from './botdecks.js';
import { Store, parseDeckText, toText, toForge, deckProblems, deckCount, allNames, partialCards, isBasic } from './store.js';
import { h, clear, go, back, modal, toast, confirmBox, cardImg, cardDetail, topBar, download, rerender, manaSymbols, supportBadge, onLongPress } from './ui_core.js';

const FMT = { constructed: '60 carte', commander: 'Commander' };
const safeFile = s => s.replace(/[^\w\- ]+/g, '_').trim() || 'mazzo';
const coverOf = d => d.commander || (d.cards.find(x => defByName(x.name)?.types.includes('creature')) || d.cards[0])?.name || null;

// ------------------------------------------------------------------ archivio
export function DecksScreen() {
  return {
    refreshOnNames: true,
    render() {
      const list = h('div.list');
      const fill = () => {
        clear(list);
        if (!Store.decks.length) list.appendChild(h('p.muted.pad', 'Nessun mazzo in archivio. Creane uno con il tasto in basso oppure importa una lista (Arena, MTGO, Moxfield, Forge).'));
        for (const d of Store.decks) {
          const probs = deckProblems(d);
          list.appendChild(h('div.row-card', { onclick: () => go(EditorScreen(d.id)) },
            cardImg(coverOf(d), { cls: 'thumb' }),
            h('div.grow',
              h('div.title', d.name),
              h('div.muted.small', `${FMT[d.format]} · ${deckCount(d)} carte${d.commander ? ' · ' + nameIt(d.commander) : ''}`),
              probs.length ? h('div.warn.small.ellipsis', '⚠ ' + probs[0]) : null),
            h('button.icon', { onclick: e => { e.stopPropagation(); deckMenu(d, fill); }, 'aria-label': 'Opzioni' }, '⋮')));
        }
      };
      fill();
      const el = h('div.screen',
        topBar('I miei mazzi', back, h('button.text', { onclick: () => importDialog(fill) }, 'Importa')),
        list,
        h('button.fab', { onclick: () => newDeckDialog() }, '+ Nuovo mazzo'));
      return { el };
    },
  };
}

function newDeckDialog() {
  const name = h('input.field', { value: 'Nuovo mazzo', maxlength: 60 });
  modal({ title: 'Nuovo mazzo', body: h('div.col', h('label.small', 'Nome'), name, h('p.small.muted', 'Scegli il formato:')), buttons: [
    { label: 'Annulla', onclick: c => c() },
    { label: 'Commander', onclick: c => { c(); const d = Store.create(name.value.trim() || 'Nuovo mazzo', 'commander'); go(EditorScreen(d.id, 1)); } },
    { label: '60 carte', kind: 'text.gold', onclick: c => { c(); const d = Store.create(name.value.trim() || 'Nuovo mazzo', 'constructed'); go(EditorScreen(d.id, 1)); } },
  ] });
}

function deckMenu(d, refresh) {
  let close = () => {};
  close = modal({ title: d.name, body: h('div.menu',
    h('button.menu-item', { onclick: () => { close(); go(EditorScreen(d.id)); } }, 'Modifica'),
    h('button.menu-item', { onclick: () => { close(); Store.duplicate(d.id); toast(`Creata una copia di «${d.name}»`); refresh(); } }, 'Duplica'),
    h('button.menu-item', { onclick: () => { close(); renameDialog(d, refresh); } }, 'Rinomina'),
    h('button.menu-item', { onclick: async () => { close(); try { await navigator.clipboard.writeText(toText(d)); toast('Lista copiata negli appunti'); } catch (_) { download(safeFile(d.name) + '.txt', toText(d), 'text/plain'); } } }, 'Copia lista (Arena / Moxfield / Forge)'),
    h('button.menu-item', { onclick: () => { close(); download(safeFile(d.name) + '.dck', toForge(d), 'text/plain'); } }, 'Esporta per Forge (.dck)'),
    h('button.menu-item', { onclick: () => { close(); download(safeFile(d.name) + '.txt', toText(d), 'text/plain'); } }, 'Esporta lista (.txt)'),
    h('button.menu-item.danger', { onclick: () => { close(); confirmBox(`Eliminare «${d.name}»?`, "Il mazzo verrà cancellato dall'archivio.", 'Elimina', () => { Store.remove(d.id); refresh(); }); } }, 'Elimina')),
  buttons: [{ label: 'Chiudi', onclick: c => c() }] });
}

function renameDialog(d, refresh) {
  const inp = h('input.field', { value: d.name, maxlength: 60 });
  modal({ title: 'Rinomina mazzo', body: inp, buttons: [
    { label: 'Annulla', onclick: c => c() },
    { label: 'Salva', onclick: c => { d.name = inp.value.trim() || d.name; Store.upsert(d); c(); refresh(); } },
  ] });
  setTimeout(() => inp.focus(), 50);
}

function importDialog(refresh) {
  const name = h('input.field', { value: 'Mazzo importato' });
  const text = h('textarea.field', { rows: 8, placeholder: '4 Lightning Bolt\n20 Mountain\n…\n\nAccetta le liste di Arena, MTGO, Moxfield e i file .dck di Forge. I nomi delle carte vanno in inglese.' });
  const file = h('input', { type: 'file', accept: '.txt,.dck,.dec,.mwdeck,text/plain', onchange: async () => {
    const f = file.files[0]; if (!f) return;
    text.value = await f.text();
    name.value = f.name.replace(/\.(txt|dck|dec|mwdeck)$/i, '');
  } });
  const err = h('div.warn.small');
  let busy = false;
  modal({ title: 'Importa lista', body: h('div.col', h('label.small', 'Nome del mazzo'), name, h('label.small', 'Scegli un file…'), file, h('label.small', '…oppure incolla il testo'), text, err),
    buttons: [
      { label: 'Annulla', onclick: c => c() },
      { label: 'Importa', onclick: async c => {
        if (busy) return;
        const d = parseDeckText(text.value, name.value.trim() || 'Mazzo importato');
        if (!d) { err.textContent = 'Nessuna carta trovata nel testo.'; return; }
        if (name.value.trim() && name.value.trim() !== 'Mazzo importato') d.name = name.value.trim();
        busy = true; err.textContent = 'Controllo le carte su Scryfall…';
        try {
          const missing = await ensureCards(allNames(d));
          if (missing.length) {
            d.cards = d.cards.filter(x => !missing.includes(x.name));
            if (missing.includes(d.commander)) d.commander = null;
          }
          Store.upsert(d); c(); refresh();
          if (missing.length) modal({ title: 'Carte non trovate', body: h('div', h('p', `Importato «${d.name}», ma ${missing.length} nomi non sono stati riconosciuti (servono i nomi inglesi):`), h('ul', missing.map(m => h('li', m)))), buttons: [{ label: 'OK', onclick: x => x() }] });
          else toast(`Importato «${d.name}»`);
        } catch (e) { err.textContent = 'Serve la connessione a internet per controllare le carte. ' + (e.message || ''); }
        busy = false;
      } },
    ] });
}

// ------------------------------------------------------------------ editor
const GROUPS = [['creature', 'Creature'], ['planeswalker', 'Planeswalker'], ['instant', 'Istantanei'], ['sorcery', 'Stregonerie'],
  ['enchantment', 'Incantesimi'], ['artifact', 'Artefatti'], ['battle', 'Battaglie'], ['land', 'Terre'], ['other', 'Altro']];
function groupOf(name) {
  const d = defByName(name);
  if (!d) return 'other';
  for (const [g] of GROUPS) if (d.types.includes(g)) return g === 'artifact' && d.types.includes('creature') ? 'creature' : g;
  return 'other';
}

export function EditorScreen(deckId, startTab = 0) {
  return {
    render() {
      const d = Store.get(deckId);
      if (!d) { setTimeout(back, 0); return { el: h('div') }; }
      return deckEditor({ deck: d, title: 'Modifica mazzo', nameEditable: true, onSave: x => Store.upsert(x), startTab });
    },
  };
}

export function BotEditorScreen(botId) {
  return {
    render() {
      const b = Store.botDeck(botId);
      if (!b) { setTimeout(back, 0); return { el: h('div') }; }
      const deck = { id: 'bot:' + botId, name: b.name, format: b.format, commander: b.commander || null, cards: b.cards.map(x => ({ ...x })) };
      const header = () => h('p.muted.small.pad-x',
        (Store.isBotModified(botId) ? '✎ Versione modificata da te. ' : 'Versione originale. ') +
        'Le modifiche si salvano subito e valgono per tutti i prossimi duelli contro questo mazzo.');
      return deckEditor({
        deck, title: 'Mazzo avversario: ' + b.name, nameEditable: false, header,
        onSave: x => Store.saveBot(botId, x.cards, x.commander),
        actions: () => Store.isBotModified(botId) ? h('button.text', { onclick: () => confirmBox('Ripristinare il mazzo originale?', `Le tue modifiche a «${b.name}» andranno perse.`, 'Ripristina', () => { Store.resetBot(botId); rerender(); }) }, 'Ripristina') : null,
      });
    },
  };
}

function deckEditor({ deck, title, nameEditable, onSave, header = null, actions = null, startTab = 0 }) {
  let tab = startTab;
  const isCmd = deck.format === 'commander';
  const state = { query: '', filter: { type: [], color: [], mv: [], rarity: [], format: isCmd ? 'commander' : null, identity: null, text: '' }, onlyId: true, showFilters: false, results: [], loading: false, error: '' };
  const status = h('div.small.pad-x');
  const tabs = h('div.tabs');
  const content = h('div.tab-content');
  const loadNote = h('div.small.muted.pad-x');

  function save() { onSave(deck); refreshHead(); }
  function count(name) { return deck.cards.find(x => x.name === name)?.n || 0; }
  function add(c) {
    const name = c.name;
    remember(c);
    const max = isCmd ? (isBasic(name) ? 99 : 1) : (isBasic(name) || /any number of cards named/i.test(c.oracle_text || '') ? 99 : 4);
    const x = deck.cards.find(y => y.name === name);
    if (deck.commander === name) { toast('È già il comandante'); return; }
    if (x) { if (x.n >= max) { toast(isCmd ? 'In Commander è ammessa una sola copia' : 'Massimo 4 copie'); return; } x.n++; }
    else deck.cards.push({ name, n: 1 });
    save();
    toast(`${nameIt(name)} aggiunta (${count(name)})`);
  }
  function removeOne(name) {
    const x = deck.cards.find(y => y.name === name);
    if (!x) return;
    x.n--;
    if (x.n <= 0) deck.cards = deck.cards.filter(y => y !== x);
    save();
  }
  function setCommander(c) {
    remember(c);
    if (deck.commander && deck.commander !== c.name) toast(`Comandante: ${nameIt(c.name)}`);
    deck.cards = deck.cards.filter(y => y.name !== c.name);
    deck.commander = c.name;
    save();
  }
  function refreshHead() {
    const probs = deckProblems(deck);
    const partial = partialCards(deck);
    clear(status).append(
      h('div.row.between', h('span', `${FMT[deck.format]} · ${deckCount(deck)} carte`),
        partial.length ? h('button.text.small', { onclick: () => partialDialog(partial) }, `⚠ ${partial.length} con effetti non simulati`) : null),
      probs.length ? h('div.warn', probs.slice(0, 3).map(p => h('div', '⚠ ' + p))) : h('div.ok', '✓ Mazzo valido per il formato'));
    drawTabs();
    if (tab === 0) drawTab();
  }
  function drawTabs() {
    clear(tabs).append(
      h('button.tab' + (tab === 0 ? '.on' : ''), { onclick: () => { tab = 0; drawTabs(); drawTab(); } }, `Mazzo (${deckCount(deck)})`),
      h('button.tab' + (tab === 1 ? '.on' : ''), { onclick: () => { tab = 1; drawTabs(); drawTab(); } }, 'Cerca carte'));
  }

  // ---- elenco del mazzo
  function drawDeck() {
    const box = h('div.results');
    if (isCmd) {
      box.appendChild(h('div.group-title', 'Comandante'));
      box.appendChild(deck.commander ? deckRow(deck.commander, null) : h('p.small.muted', 'Nessun comandante: cercalo nella scheda «Cerca carte» e tocca «Comandante».'));
    }
    if (!deck.cards.length) box.appendChild(h('p.muted.pad', 'Il mazzo è vuoto. Usa «Cerca carte» per aggiungere carte.'));
    const by = {};
    for (const x of deck.cards) (by[groupOf(x.name)] ||= []).push(x);
    for (const [g, label] of GROUPS) {
      const list = by[g]; if (!list) continue;
      list.sort((a, b) => (defByName(a.name)?.cmc ?? 0) - (defByName(b.name)?.cmc ?? 0) || nameIt(a.name).localeCompare(nameIt(b.name)));
      box.appendChild(h('div.group-title', `${label} (${list.reduce((s, x) => s + x.n, 0)})`));
      for (const x of list) box.appendChild(deckRow(x.name, x.n));
    }
    // curva di mana
    const curve = Array(8).fill(0);
    for (const x of deck.cards) { const d = defByName(x.name); if (d && !d.types.includes('land')) curve[Math.min(7, Math.round(d.cmc || 0))] += x.n; }
    const max = Math.max(1, ...curve);
    box.appendChild(h('div.group-title', 'Curva di mana'));
    box.appendChild(h('div.curve', curve.map((n, i) => h('div.bar', h('div.fill', { style: { height: Math.round(60 * n / max) + 'px' } }), h('b', n || ''), h('span', i === 7 ? '7+' : i)))));
    return box;
  }
  function deckRow(name, n) {
    const d = defByName(name);
    const img = cardImg(name, { cls: 'thumb' });
    const row = h('div.result',
      img,
      h('div.grow', { onclick: () => cardDetail(name) },
        h('div.ellipsis', nameIt(name), ' ', supportBadge(name)),
        h('div.muted.small.ellipsis', d ? (d.typeIt || d.typeLine) : name)),
      d ? manaSymbols(d.manaCost) : null,
      n == null ? h('button.text.small', { onclick: () => { deck.commander = null; save(); } }, 'Rimuovi') : [
        h('button.qty', { onclick: () => removeOne(name), 'aria-label': 'Togli' }, '−'),
        h('b.qtyn', n),
        h('button.qty', { onclick: () => add(card(name) || { name }), 'aria-label': 'Aggiungi' }, '+'),
      ]);
    onLongPress(row, () => cardDetail(name));
    return row;
  }

  // ---- ricerca
  function drawSearch() {
    const input = h('input.field', { value: state.query, placeholder: 'Nome (italiano o inglese) o codice, es. «Fulmine», «M10 146»', enterkeyhint: 'search',
      oninput: e => { state.query = e.target.value; }, onkeydown: e => { if (e.key === 'Enter') { e.target.blur(); run(); } } });
    const resBox = h('div.results');
    const filt = h('div.filters');
    const fCount = () => ['type', 'color', 'mv', 'rarity'].reduce((s, k) => s + state.filter[k].length, 0) + (state.filter.format && !isCmd ? 1 : 0) + (state.filter.text ? 1 : 0);
    const fBtn = h('button.outline' + (fCount() ? '.on' : ''), { onclick: () => { state.showFilters = !state.showFilters; drawFilters(); } }, `Filtri${fCount() ? ' (' + fCount() + ')' : ''}`);
    function chips(key, items, multi = true) {
      return h('div.chips.wrap', items.map(([v, label]) => {
        const on = multi ? state.filter[key].includes(v) : state.filter[key] === v;
        return h('button.chip' + (on ? '.on' : ''), { onclick: () => {
          if (multi) { const a = state.filter[key]; const i = a.indexOf(v); if (i >= 0) a.splice(i, 1); else a.push(v); }
          else state.filter[key] = on ? null : v;
          drawFilters(); fBtn.textContent = `Filtri${fCount() ? ' (' + fCount() + ')' : ''}`; fBtn.classList.toggle('on', !!fCount());
        } }, label);
      }));
    }
    function drawFilters() {
      clear(filt);
      if (!state.showFilters) return;
      const txt = h('input.field', { value: state.filter.text, placeholder: 'Testo della carta contiene (in inglese, es. «flying», «draw»)', oninput: e => { state.filter.text = e.target.value; } });
      filt.append(
        h('div.fgroup', h('b.small', 'Tipo'), chips('type', FILTERS.type)),
        h('div.fgroup', h('b.small', 'Colore'), chips('color', FILTERS.color)),
        h('div.fgroup', h('b.small', 'Costo di mana'), chips('mv', FILTERS.mv)),
        h('div.fgroup', h('b.small', 'Rarità'), chips('rarity', FILTERS.rarity)),
        isCmd ? null : h('div.fgroup', h('b.small', 'Legale in'), chips('format', FILTERS.format, false)),
        isCmd && deck.commander ? h('label.option.small', h('input', { type: 'checkbox', checked: state.onlyId, onchange: e => { state.onlyId = e.target.checked; } }), 'Solo carte nell\'identità di colore del comandante') : null,
        h('div.fgroup', h('b.small', 'Testo'), txt),
        h('button.text', { onclick: () => { state.filter = { type: [], color: [], mv: [], rarity: [], format: isCmd ? 'commander' : null, identity: null, text: '' }; drawFilters(); fBtn.textContent = 'Filtri'; fBtn.classList.remove('on'); } }, 'Azzera filtri'));
    }
    async function run() {
      state.loading = true; state.error = ''; drawResults();
      try {
        const f = { ...state.filter };
        if (isCmd && deck.commander && state.onlyId) f.identity = (card(deck.commander)?.color_identity || []).join('').toLowerCase() || 'c';
        state.results = await searchCards(state.query, f);
        if (!state.results.length) state.error = 'Nessuna carta trovata.';
      } catch (e) { state.results = []; state.error = 'Ricerca non riuscita: serve la connessione a internet. ' + (e.message || ''); }
      state.loading = false; drawResults();
    }
    function drawResults() {
      clear(resBox);
      if (state.loading) { resBox.appendChild(h('div.center.pad', h('div.spinner'))); return; }
      if (state.error) resBox.appendChild(h('p.muted.pad', state.error));
      for (const c of state.results) {
        const def = previewDef(c);
        const nm = c.printed_name || c.name;
        const legend = /legendary/i.test(c.type_line || '') && /creature/i.test(c.type_line || '');
        const row = h('div.result',
          h('div.thumb', { onclick: () => { remember(c); cardDetail(c.name); } }, resultImg(c)),
          h('div.grow', { onclick: () => { remember(c); cardDetail(c.name); } },
            h('div.ellipsis', nm, ' ', def && def.unsupported.length ? h('span.badge-warn', '⚠') : null),
            h('div.muted.small.ellipsis', (c.printed_type_line || c.type_line || '') + (c.printed_name && c.printed_name !== c.name ? ' · ' + c.name : ''))),
          manaSymbols(c.mana_cost || c.card_faces?.[0]?.mana_cost || ''),
          isCmd && legend ? h('button.text.small', { onclick: () => setCommander(c) }, 'Comand.') : null,
          h('button.qty.add', { onclick: () => add(c), 'aria-label': 'Aggiungi' }, '+'));
        resBox.appendChild(row);
      }
    }
    drawFilters();
    drawResults();
    return h('div.search', h('div.row', input, h('button.primary', { onclick: run }, 'Cerca')), h('div.row.between', fBtn, h('span.muted.small', 'Tieni premuto per i dettagli')), filt, resBox);
  }
  function resultImg(c) {
    const src = c.imgSmall || c.image_uris?.small || c.card_faces?.[0]?.image_uris?.small;
    const w = h('div.card-img');
    w.appendChild(h('div.name-tile.unknown', h('span', c.printed_name || c.name)));
    if (src) { const im = h('img', { src, alt: '', loading: 'lazy' }); im.onload = () => w.classList.add('loaded'); w.appendChild(im); }
    return w;
  }

  function drawTab() {
    clear(content).appendChild(tab === 0 ? drawDeck() : drawSearch());
  }

  const nameField = nameEditable ? h('input.field.title-input', { value: deck.name, maxlength: 60, onchange: e => { deck.name = e.target.value.trim() || deck.name; save(); } }) : null;
  const el = h('div.screen',
    topBar(title, back, actions ? actions() : null),
    nameField ? h('div.pad-x', nameField) : null,
    header ? header() : null,
    status, loadNote, tabs, content);
  refreshHead();
  drawTab();
  // le carte del mazzo non ancora in memoria (es. dopo un ripristino) si scaricano
  const missing = allNames(deck).filter(n => !Cards.has(n));
  if (missing.length) {
    loadNote.textContent = `Scarico i dati di ${missing.length} carte…`;
    ensureCards(missing).then(() => { loadNote.textContent = ''; refreshHead(); drawTab(); })
      .catch(() => { loadNote.textContent = 'Alcune carte non sono disponibili senza connessione.'; });
  }
  return { el };
}

function partialDialog(names) {
  modal({ title: 'Effetti non simulati', wide: true, body: h('div.col',
    h('p.small.muted', 'Queste carte si giocano normalmente, ma alcune righe del loro testo vengono ignorate dal simulatore. Tocca una carta per i dettagli.'),
    names.map(n => h('button.action', { onclick: () => cardDetail(n) }, cardImg(n, { cls: 'thumb' }), h('div.grow', h('b', nameIt(n)), h('div.small.muted.clamp2', defByName(n).unsupported.join(' · '))))),
  ), buttons: [{ label: 'Chiudi', onclick: c => c() }] });
}

// ------------------------------------------------------------------ backup
export function BackupScreen() {
  return {
    render() {
      const file = h('input', { type: 'file', accept: '.json,application/json', style: { display: 'none' }, onchange: async () => {
        const f = file.files[0]; if (!f) return;
        try { const r = Store.restore(await f.text()); toast(`Ripristinati ${r.decks} mazzi e ${r.bots} mazzi avversari`); }
        catch (e) { modal({ title: 'Ripristino non riuscito', body: h('p', e.message), buttons: [{ label: 'OK', onclick: c => c() }] }); }
        file.value = '';
      } });
      const el = h('div.screen',
        topBar('Backup e dati', back),
        h('div.pad.col',
          h('p', 'Il backup contiene tutti i tuoi mazzi e le modifiche ai mazzi dell\'avversario, in un file .json.'),
          h('button.primary', { onclick: () => download(`mtgtester-backup-${new Date().toISOString().slice(0, 10)}.json`, Store.backupJson()) }, 'Salva backup'),
          h('button.outline', { onclick: () => file.click() }, 'Ripristina da file'),
          file,
          h('hr'),
          h('p.small.muted', `Carte scaricate in memoria: ${Cards.size}. Servono per giocare anche senza rete; si riscaricano da sole se le cancelli.`),
          h('button.outline', { onclick: () => confirmBox('Cancellare i dati delle carte?', 'I mazzi restano. I dati delle carte verranno scaricati di nuovo quando servono.', 'Cancella', async () => { await clearCache(); toast('Dati delle carte cancellati'); rerender(); }) }, 'Cancella dati delle carte'),
          h('hr'),
          h('p.small.muted', 'Dati e immagini delle carte: Scryfall. Magic: The Gathering è un marchio di Wizards of the Coast. App per uso personale, non ufficiale.')));
      return { el };
    },
  };
}
export { coverOf };

// ------------------------------------------------------------------ mazzi per Forge (un tocco per copiare)
async function copyText(text) {
  try { await navigator.clipboard.writeText(text); return true; } catch (_) { /* si prova il metodo vecchio */ }
  const ta = h('textarea', { style: { position: 'fixed', top: '-1000px' } });
  ta.value = text; document.body.appendChild(ta); ta.select();
  let ok = false; try { ok = document.execCommand('copy'); } catch (_) { /* */ }
  ta.remove();
  return ok;
}
const LVL_FORGE = ['Facile', 'Medio', 'Difficile e Incubo'];

export function ForgeScreen() {
  return {
    render() {
      const box = h('div.list');
      const row = (title, sub, text) => {
        const b = h('button.primary.small-btn', { onclick: async () => {
          if (await copyText(text)) { b.textContent = '✓ Copiato'; toast('Lista copiata: ora incollala in Forge'); setTimeout(() => { b.textContent = 'Copia'; }, 2500); }
          else modal({ title: 'Copia manuale', wide: true, body: h('textarea.field', { rows: 12, readonly: true }, text), buttons: [{ label: 'Chiudi', onclick: c => c() }] });
        } }, 'Copia');
        return h('div.row-card', h('div.grow', h('div.title', title), sub ? h('div.muted.small', sub) : null), b);
      };
      box.appendChild(h('div.tip.col',
        h('b', 'Come si fa (3 passaggi)'),
        h('div', '1. Tocca «Copia» accanto al mazzo che vuoi.'),
        h('div', '2. Apri Forge → Deck Editor → crea un mazzo nuovo → Import.'),
        h('div', '3. Incolla il testo (tieni premuto → Incolla) e salva.'),
        h('div.small.muted', 'Forge si scarica gratis da github.com/Card-Forge/forge/releases (Android 11 o superiore).')));
      if (Store.decks.length) {
        box.appendChild(h('div.group-title', 'I tuoi mazzi'));
        for (const d of Store.decks) box.appendChild(row(d.name, `${FMT[d.format]} · ${deckCount(d)} carte`, toText(d)));
      }
      for (const fmt of ['constructed', 'commander']) {
        for (let lvl = 0; lvl < 3; lvl++) {
          const list = BOT_DECKS.filter(b => b.format === fmt && b.level === lvl);
          if (!list.length) continue;
          box.appendChild(h('div.group-title', `Mazzi avversario · ${FMT[fmt]} · ${LVL_FORGE[lvl]}`));
          for (const b0 of list) { const b = Store.botDeck(b0.id); box.appendChild(row(b.name, b.desc, toText(b))); }
        }
      }
      return { el: h('div.screen', topBar('Mazzi per Forge (Android)', back), box) };
    },
  };
}
