// Archivio dei mazzi (memoria del browser), mazzi del bot modificati, backup e import/export.
import { BOT_DECKS, parseList } from './botdecks.js';
import { card, defByName } from './data.js';

const K_DECKS = 'mtgt.decks', K_BOT = 'mtgt.botmods', K_OPTS = 'mtgt.opts', K_GAME = 'mtgt.game';
const BASICS = ['Plains', 'Island', 'Swamp', 'Mountain', 'Forest', 'Wastes', 'Snow-Covered Plains', 'Snow-Covered Island', 'Snow-Covered Swamp', 'Snow-Covered Mountain', 'Snow-Covered Forest'];
export const isBasic = n => BASICS.includes(n);

function read(key, def) { try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : def; } catch (_) { return def; } }
function write(key, v) { try { localStorage.setItem(key, JSON.stringify(v)); return true; } catch (_) { return false; } }
const uid = () => (crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2));

export const Store = {
  decks: read(K_DECKS, []),
  botMods: read(K_BOT, {}),
  opts: Object.assign({ stopAll: false, botSpeed: 1, showEnglish: false }, read(K_OPTS, {})),

  save() { return write(K_DECKS, this.decks); },
  saveOpts() { write(K_OPTS, this.opts); },
  get(id) { return this.decks.find(d => d.id === id) || null; },
  upsert(d) {
    d.updated = Date.now();
    const i = this.decks.findIndex(x => x.id === d.id);
    if (i >= 0) this.decks[i] = d; else this.decks.unshift(d);
    this.save();
  },
  create(name = 'Nuovo mazzo', format = 'constructed') { const d = { id: uid(), name, format, commander: null, cards: [], updated: Date.now() }; this.upsert(d); return d; },
  remove(id) { this.decks = this.decks.filter(d => d.id !== id); this.save(); },
  duplicate(id) {
    const d = this.get(id); if (!d) return null;
    const c = { ...d, id: uid(), name: d.name + ' (copia)', cards: d.cards.map(x => ({ ...x })) };
    this.upsert(c); return c;
  },

  // ---- mazzi dell'avversario
  botBase(id) {
    const b = BOT_DECKS.find(x => x.id === id);
    if (!b) return null;
    return { ...b, cards: parseList(b.list).map(x => ({ name: x.name, n: x.n })) };
  },
  botDeck(id) {
    const b = this.botBase(id); if (!b) return null;
    const m = this.botMods[id];
    return m ? { ...b, cards: m.cards.map(x => ({ ...x })), commander: m.commander ?? b.commander } : b;
  },
  isBotModified(id) { return !!this.botMods[id]; },
  saveBot(id, cards, commander) {
    const b = this.botBase(id); if (!b) return;
    const key = l => l.map(x => x.name + '×' + x.n).sort().join('|');
    if (key(b.cards) === key(cards) && (commander ?? null) === (b.commander ?? null)) delete this.botMods[id];
    else this.botMods[id] = { cards: cards.map(x => ({ ...x })), commander };
    write(K_BOT, this.botMods);
  },
  resetBot(id) { delete this.botMods[id]; write(K_BOT, this.botMods); },

  // ---- partita in corso (si riprende se l'app viene chiusa)
  saveGame(g) { if (!write(K_GAME, g)) try { localStorage.removeItem(K_GAME); } catch (_) { /* */ } },
  loadGame() { return read(K_GAME, null); },
  clearGame() { try { localStorage.removeItem(K_GAME); } catch (_) { /* */ } },

  // ---- backup
  backupJson() {
    return JSON.stringify({ app: 'mtgtester', version: 1, created: new Date().toISOString(), decks: this.decks, botOverrides: this.botMods }, null, 1);
  },
  restore(text) {
    let o;
    try { o = JSON.parse(text); } catch (_) { throw new Error('Il file non è un backup valido.'); }
    if (!o || o.app !== 'mtgtester' || !Array.isArray(o.decks)) throw new Error('Il file non è un backup di MTG Tester.');
    let n = 0;
    for (const d of o.decks) {
      if (!d || !d.id || !Array.isArray(d.cards)) continue;
      const clean = { id: String(d.id), name: String(d.name || 'Mazzo'), format: d.format === 'commander' ? 'commander' : 'constructed',
        commander: d.commander || null, cards: d.cards.filter(x => x && x.name).map(x => ({ name: String(x.name), n: Math.max(1, x.n | 0) })), updated: d.updated || Date.now() };
      const i = this.decks.findIndex(x => x.id === clean.id);
      if (i >= 0) this.decks[i] = clean; else this.decks.push(clean);
      n++;
    }
    this.save();
    let b = 0;
    if (o.botOverrides && typeof o.botOverrides === 'object') {
      for (const [k, v] of Object.entries(o.botOverrides)) if (v && Array.isArray(v.cards)) { this.botMods[k] = v; b++; }
      write(K_BOT, this.botMods);
    }
    return { decks: n, bots: b };
  },
};

export const deckCount = d => d.cards.reduce((s, x) => s + x.n, 0) + (d.commander ? 1 : 0);
export const deckNames = d => [...d.cards.flatMap(x => Array(x.n).fill(x.name))];
export const allNames = d => [...new Set([...d.cards.map(x => x.name), ...(d.commander ? [d.commander] : [])])];

/** Legge una lista: formato Arena/MTGO/Moxfield ("4 Lightning Bolt (M10) 146"), Forge (.dck) o semplice */
export function parseDeckText(text, fallbackName = 'Mazzo importato') {
  let name = fallbackName, commander = null, sec = 'main';
  const cards = new Map();
  for (const raw of String(text).split(/\r?\n/)) {
    let l = raw.trim();
    if (!l || l.startsWith('//') || l.startsWith('#')) continue;
    const meta = l.match(/^name\s*=\s*(.+)$/i);
    if (meta) { name = meta[1].trim(); continue; }
    const head = l.replace(/^\[|\]$/g, '').replace(/:$/, '').toLowerCase();
    if (/^(deck|main|mainboard|maindeck|mazzo)$/.test(head)) { sec = 'main'; continue; }
    if (/^(sideboard|side|maybeboard|considering|tokens?)$/.test(head)) { sec = 'side'; continue; }
    if (/^(commander|comandante|commanders)$/.test(head)) { sec = 'cmd'; continue; }
    if (/^(metadata|about)$/.test(head)) { sec = 'meta'; continue; }
    if (sec === 'meta') continue;
    if (/^sb:\s*/i.test(l)) continue;
    const m = l.match(/^(\d+)\s*x?\s+(.+)$/i);
    let n = 1, nm = l;
    if (m) { n = +m[1]; nm = m[2]; }
    nm = nm.replace(/\|.*$/, '').replace(/\s+\([A-Za-z0-9]{2,6}\)\s*[\w★-]*\s*$/, '').replace(/\s+\*[A-Z]+\*$/, '').replace(/\s+#.*$/, '').trim();
    if (!nm) continue;
    if (sec === 'side') continue;
    if (sec === 'cmd') { commander = nm; continue; }
    cards.set(nm, (cards.get(nm) || 0) + n);
  }
  const list = [...cards.entries()].map(([name, n]) => ({ name, n }));
  if (!list.length && !commander) return null;
  return { id: uid(), name, format: commander || list.reduce((s, x) => s + x.n, 0) >= 95 ? 'commander' : 'constructed', commander, cards: list, updated: Date.now() };
}

export function toText(d) {
  const lines = [];
  if (d.commander) lines.push('Commander', `1 ${d.commander}`, '', 'Deck');
  for (const x of d.cards) lines.push(`${x.n} ${x.name}`);
  return lines.join('\n') + '\n';
}
/** Formato .dck di Forge */
export function toForge(d) {
  const lines = ['[metadata]', `Name=${d.name}`];
  if (d.commander) lines.push('[Commander]', `1 ${d.commander}`);
  lines.push('[Main]');
  for (const x of d.cards) lines.push(`${x.n} ${x.name}`);
  lines.push('[Sideboard]');
  return lines.join('\n') + '\n';
}

/** Problemi del mazzo secondo le regole del formato */
export function deckProblems(d, legality = null) {
  const out = [];
  const n = deckCount(d);
  if (d.format === 'commander') {
    if (!d.commander) out.push('Manca il comandante.');
    if (n !== 100) out.push(`Il mazzo ha ${n} carte: in Commander ne servono esattamente 100 (comandante compreso).`);
    for (const x of d.cards) if (x.n > 1 && !isBasic(x.name)) out.push(`«${x.name}» compare ${x.n} volte (in Commander una sola copia).`);
    const cmd = d.commander && card(d.commander);
    if (cmd) {
      const tl = (cmd.type_line || '').toLowerCase();
      if (!(tl.includes('legendary') && tl.includes('creature')) && !/can be your commander/i.test(cmd.oracle_text || '')) out.push('Il comandante deve essere una creatura leggendaria.');
      const id = new Set(cmd.color_identity || []);
      const off = d.cards.filter(x => { const c = card(x.name); return c && (c.color_identity || []).some(k => !id.has(k)); });
      if (off.length) out.push(`Fuori dall'identità di colore del comandante: ${off.slice(0, 6).map(x => x.name).join(', ')}${off.length > 6 ? '…' : ''}.`);
    }
  } else {
    if (n < 60) out.push(`Il mazzo ha ${n} carte: ne servono almeno 60.`);
    for (const x of d.cards) if (x.n > 4 && !isBasic(x.name) && !/any number of cards named/i.test(card(x.name)?.oracle_text || '')) out.push(`«${x.name}» compare ${x.n} volte (massimo 4).`);
  }
  if (legality) {
    const bad = d.cards.filter(x => { const c = card(x.name); return c && c.legalities && c.legalities[legality] && c.legalities[legality] !== 'legal'; });
    if (bad.length) out.push(`Non legali in ${legality}: ${bad.slice(0, 6).map(x => x.name).join(', ')}${bad.length > 6 ? '…' : ''}.`);
  }
  return out;
}

/** Carte del mazzo che il simulatore gestisce solo in parte */
export function partialCards(d) {
  return allNames(d).filter(n => { const def = defByName(n); return def && def.unsupported.length; });
}
