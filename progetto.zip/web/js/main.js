// Avvio della web app.
import { initData, resumeItalian, itListeners } from './data.js';
import { Store } from './store.js';
import { h, clear, setRoot, replace, go, current, rerender } from './ui_core.js';
import { DecksScreen, BackupScreen, ForgeScreen } from './ui_decks.js';
import { NewGameScreen, NG, DuelScreen, DIFFS } from './ui_game.js';

const app = document.getElementById('app');
setRoot(app);
history.replaceState({ depth: 1 }, '');

const standalone = window.matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;

function HomeScreen() {
  return {
    refreshOnNames: true,
    render() {
      const btn = (icon, title, sub, onclick) => h('button.home-btn', { onclick }, h('span.home-icon', icon), h('span.grow', h('b', title), h('span.muted.small', sub)));
      const isIos = /iPhone|iPad|iPod/.test(navigator.userAgent);
      const saved = Store.loadGame();
      const el = h('div.screen.home',
        h('div.home-title', 'MTG Tester'),
        h('p.muted.center', 'Prova i tuoi mazzi di Magic contro un avversario virtuale'),
        saved && saved.G && !saved.G.over ? btn('↻', 'Riprendi la partita', `Turno ${saved.G.turn} · ${DIFFS[saved.config.difficulty]} · ${saved.G.players[1].name}`, () => go(DuelScreen(saved.config, HomeScreen(), saved))) : null,
        btn('▶', 'Gioca una partita di prova', '60 carte o Commander, 4 livelli di difficoltà', () => { NG.step = 0; NG.botId = null; go(NewGameScreen(HomeScreen())); }),
        btn('🂠', 'I miei mazzi', `${Store.decks.length} mazzi in archivio`, () => go(DecksScreen())),
        btn('⇪', 'Mazzi per Forge (Android)', 'Copia un mazzo con un tocco e incollalo in Forge', () => go(ForgeScreen())),
        btn('⤓', 'Backup e dati', 'Salva o ripristina mazzi e modifiche', () => go(BackupScreen())),
        !standalone && isIos ? h('div.tip', h('b', 'Consiglio: '), 'tocca Condividi ', h('span.share-ico', '⬆︎'), ' e poi «Aggiungi alla schermata Home». Così l\'app si apre a schermo intero e i mazzi restano salvati al sicuro.') : null,
        h('p.tiny.muted.center', 'Dati e immagini: Scryfall · App non ufficiale per uso personale'));
      return { el };
    },
  };
}

async function boot() {
  clear(app).appendChild(h('div.screen.boot', h('div.home-title', 'MTG Tester'), h('div.spinner')));
  try { await initData(); } catch (_) { /* si continua: le carte si scaricano quando servono */ }
  try { navigator.storage?.persist?.(); } catch (_) { /* */ }
  replace(HomeScreen());
  // quando arrivano i nomi italiani si aggiorna la schermata (non durante il duello)
  let t = null;
  itListeners.add(() => { clearTimeout(t); t = setTimeout(() => { const s = current(); if (s && s.refreshOnNames) rerender(); }, 800); });
  resumeItalian();
}

if ('serviceWorker' in navigator && location.protocol !== 'file:') {
  navigator.serviceWorker.register('sw.js').catch(() => {});
}
boot();
