// Dati delle carte: Scryfall (testi oracle, nomi e testi italiani, immagini) con copia locale in IndexedDB.
import { registerCard, DEFS } from './engine/game.js';
import { compileCard } from './engine/cards.js';

const API = 'https://api.scryfall.com';
export const Cards = new Map(); // nome inglese (fronte) -> dati ridotti

// ------------------------------------------------------------------------------------------------ IndexedDB
let dbp = null;
function db() {
  if (dbp) return dbp;
  dbp = new Promise((res, rej) => {
    if (!('indexedDB' in self)) { rej(new Error('no idb')); return; }
    const r = indexedDB.open('mtgtester', 1);
    r.onupgradeneeded = () => { r.result.createObjectStore('cards', { keyPath: 'name' }); };
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  }).catch(() => null);
  return dbp;
}
async function idbAll() {
  const d = await db(); if (!d) return [];
  return new Promise(res => {
    const out = [];
    const req = d.transaction('cards').objectStore('cards').openCursor();
    req.onsuccess = () => { const c = req.result; if (c) { out.push(c.value); c.continue(); } else res(out); };
    req.onerror = () => res(out);
  });
}
async function idbPut(list) {
  const d = await db(); if (!d || !list.length) return;
  await new Promise(res => {
    const tx = d.transaction('cards', 'readwrite');
    const st = tx.objectStore('cards');
    for (const c of list) st.put(c);
    tx.oncomplete = res; tx.onerror = res; tx.onabort = res;
  });
}
export async function clearCache() {
  const d = await db(); if (!d) return;
  await new Promise(res => { const tx = d.transaction('cards', 'readwrite'); tx.objectStore('cards').clear(); tx.oncomplete = res; tx.onerror = res; });
  Cards.clear();
}

// ------------------------------------------------------------------------------------------------ richieste a Scryfall (max ~9 al secondo)
let lastCall = 0;
async function api(path, opts = {}) {
  const wait = lastCall + 110 - Date.now();
  lastCall = Date.now() + Math.max(0, wait);
  if (wait > 0) await new Promise(r => setTimeout(r, wait));
  for (let tries = 0; tries < 3; tries++) {
    const r = await fetch(API + path, { ...opts, headers: { Accept: 'application/json', ...(opts.body ? { 'Content-Type': 'application/json' } : {}) } });
    if (r.status === 429) { await new Promise(res => setTimeout(res, 1000 * (tries + 1))); continue; }
    if (r.status === 404) return null;
    if (!r.ok) throw new Error('Scryfall: errore ' + r.status);
    return r.json();
  }
  throw new Error('Scryfall: troppe richieste, riprova tra poco.');
}

export const frontName = sc => (sc.card_faces && sc.card_faces.length && !sc.oracle_text ? sc.card_faces[0].name : sc.name);
const imgs = o => (o && o.image_uris ? { normal: o.image_uris.normal, small: o.image_uris.small } : undefined);

/** Riduce i dati Scryfall a ciò che serve */
export function reduce(sc) {
  const faces = sc.card_faces ? sc.card_faces.map(f => ({
    name: f.name, mana_cost: f.mana_cost, type_line: f.type_line, oracle_text: f.oracle_text, power: f.power, toughness: f.toughness,
    loyalty: f.loyalty, colors: f.colors, image_uris: imgs(f), printed_name: f.printed_name, printed_text: f.printed_text, printed_type_line: f.printed_type_line,
  })) : undefined;
  const L = sc.legalities || {};
  return {
    name: frontName(sc), full: sc.name, mana_cost: sc.mana_cost, type_line: sc.type_line, oracle_text: sc.oracle_text,
    power: sc.power, toughness: sc.toughness, loyalty: sc.loyalty, colors: sc.colors, color_identity: sc.color_identity, cmc: sc.cmc,
    legalities: { standard: L.standard, pioneer: L.pioneer, modern: L.modern, commander: L.commander, legacy: L.legacy, pauper: L.pauper },
    card_faces: faces, image_uris: imgs(sc) || (faces && faces[0].image_uris), set: sc.set, collector_number: sc.collector_number, rarity: sc.rarity,
    printed_name: sc.lang === 'it' ? sc.printed_name : undefined, printed_text: sc.lang === 'it' ? sc.printed_text : undefined,
    printed_type_line: sc.lang === 'it' ? sc.printed_type_line : undefined, lang: sc.lang,
  };
}
/** Unisce i testi italiani di una stampa italiana alla carta inglese */
function mergeIt(base, it) {
  const out = { ...base, itDone: true };
  if (!it) return out;
  out.printed_name = it.printed_name || (it.card_faces && it.card_faces[0].printed_name) || out.printed_name;
  out.printed_text = it.printed_text || out.printed_text;
  out.printed_type_line = it.printed_type_line || out.printed_type_line;
  const im = imgs(it) || (it.card_faces && imgs(it.card_faces[0]));
  if (im) { out.img = im.normal; out.imgSmall = im.small; }
  if (out.card_faces && it.card_faces) out.card_faces = out.card_faces.map((f, i) => ({ ...f, printed_name: it.card_faces[i]?.printed_name, printed_text: it.card_faces[i]?.printed_text, printed_type_line: it.card_faces[i]?.printed_type_line }));
  return out;
}

function store(c) {
  Cards.set(c.name, c);
  try { registerCard(c); } catch (e) { console.warn('Carta non registrata', c.name, e); }
}

// ------------------------------------------------------------------------------------------------ caricamento
export async function initData() {
  const all = await idbAll();
  for (const c of all) { try { store(c); } catch (_) { /* carta illeggibile */ } }
  return all.length;
}

/** Garantisce che le carte siano in memoria (le scarica se mancano). Restituisce i nomi non trovati. */
export async function ensureCards(names, onProgress = () => {}) {
  const want = [...new Set(names)].filter(n => n && !Cards.has(n));
  const missing = [];
  const got = [];
  for (let i = 0; i < want.length; i += 75) {
    onProgress(`Scarico le carte (${Math.min(i + 75, want.length)}/${want.length})…`, i / Math.max(1, want.length));
    const batch = want.slice(i, i + 75);
    let r;
    try { r = await api('/cards/collection', { method: 'POST', body: JSON.stringify({ identifiers: batch.map(name => ({ name })) }) }); }
    catch (e) {
      // piano B: una richiesta per carta
      r = { data: [], not_found: [] };
      for (const [k, name] of batch.entries()) {
        onProgress(`Scarico le carte (${i + k + 1}/${want.length})…`, (i + k) / Math.max(1, want.length));
        const sc = await api('/cards/named?exact=' + encodeURIComponent(name));
        if (sc) r.data.push(sc); else r.not_found.push({ name });
      }
    }
    for (const sc of r?.data || []) {
      const c = reduce(sc);
      // il nome richiesto può essere quello del primo lato
      const asked = batch.find(n => n.toLowerCase() === c.name.toLowerCase() || n.toLowerCase() === c.full.toLowerCase()) || c.name;
      c.name = c.name === asked ? c.name : c.name;
      got.push(c);
      store(c);
      if (asked !== c.name) Cards.set(asked, c);
    }
    for (const nf of r?.not_found || []) missing.push(nf.name);
  }
  if (got.length) { await idbPut(got); italianLater(got.map(c => c.name)); }
  return missing;
}

// i testi italiani arrivano in sottofondo, a gruppi
const itQueue = new Set();
let itRunning = false;
export const itListeners = new Set();
function italianLater(names) {
  for (const n of names) { const c = Cards.get(n); if (c && !c.itDone) itQueue.add(n); }
  if (!itRunning) runItalian();
}
async function runItalian() {
  itRunning = true;
  try {
    while (itQueue.size) {
      const batch = [...itQueue].slice(0, 12);
      batch.forEach(n => itQueue.delete(n));
      const q = 'lang:it (' + batch.map(n => `!"${(Cards.get(n)?.full || n).replace(/"/g, '')}"`).join(' or ') + ')';
      let res = [];
      try {
        let page = await api('/cards/search?unique=cards&include_multilingual=true&q=' + encodeURIComponent(q));
        res = page?.data || [];
      } catch (_) { res = []; }
      const upd = [];
      for (const n of batch) {
        const c = Cards.get(n); if (!c) continue;
        const it = res.find(sc => frontName(sc) === c.name || sc.name === c.full);
        const m = mergeIt(c, it);
        store(m);
        upd.push(m);
      }
      await idbPut(upd);
      itListeners.forEach(f => { try { f(); } catch (_) { /* */ } });
    }
  } finally { itRunning = false; }
}
export function resumeItalian() { italianLater([...Cards.keys()]); }

// ------------------------------------------------------------------------------------------------ ricerca
export const FILTERS = {
  type: [['creature', 'Creatura'], ['instant', 'Istantaneo'], ['sorcery', 'Stregoneria'], ['enchantment', 'Incantesimo'], ['artifact', 'Artefatto'],
    ['planeswalker', 'Planeswalker'], ['land', 'Terra'], ['legendary', 'Leggendario']],
  color: [['w', 'Bianco'], ['u', 'Blu'], ['b', 'Nero'], ['r', 'Rosso'], ['g', 'Verde'], ['c', 'Incolore'], ['m', 'Multicolore']],
  mv: [['0', '0'], ['1', '1'], ['2', '2'], ['3', '3'], ['4', '4'], ['5', '5'], ['6', '6'], ['7', '7+']],
  rarity: [['common', 'Comune'], ['uncommon', 'Non comune'], ['rare', 'Rara'], ['mythic', 'Mitica']],
  format: [['standard', 'Standard'], ['pioneer', 'Pioneer'], ['modern', 'Modern'], ['commander', 'Commander']],
};

function filterQuery(f) {
  const parts = [];
  if (f.type?.length) parts.push('(' + f.type.map(t => 't:' + t).join(' or ') + ')');
  if (f.color?.length) {
    const cs = f.color.filter(c => 'wubrg'.includes(c));
    const or = [];
    if (cs.length) or.push('c:' + cs.join(''));
    if (f.color.includes('c')) or.push('c:c');
    if (f.color.includes('m')) or.push('c:m');
    if (cs.length && !f.color.includes('c') && !f.color.includes('m')) parts.push('c<=' + cs.join('') + ' -c:c');
    else parts.push('(' + or.join(' or ') + ')');
  }
  if (f.mv?.length) parts.push('(' + f.mv.map(v => (v === '7' ? 'mv>=7' : 'mv=' + v)).join(' or ') + ')');
  if (f.rarity?.length) parts.push('(' + f.rarity.map(r => 'r:' + r).join(' or ') + ')');
  if (f.format) parts.push('f:' + f.format);
  if (f.identity) parts.push('id<=' + (f.identity || 'c'));
  if (f.text) parts.push('o:"' + f.text.replace(/"/g, '') + '"');
  return parts.join(' ');
}

/** Ricerca: nome (italiano o inglese), codice set + numero, filtri. Restituisce carte ridotte. */
export async function searchCards(text, f = {}) {
  text = (text || '').trim();
  const set = text.match(/^([a-z0-9]{2,6})\s*[\s/#-]\s*(\d+[a-z★]?)$/i);
  if (set) {
    const [code, num] = [set[1].toLowerCase(), set[2]];
    const it = await api(`/cards/${code}/${encodeURIComponent(num)}/it`).catch(() => null);
    const en = await api(`/cards/${code}/${encodeURIComponent(num)}`).catch(() => null);
    if (!en && !it) return [];
    const base = reduce(en || it);
    return [mergeIt(base, it)];
  }
  const fq = filterQuery(f);
  if (!text && !fq) return [];
  const words = text ? text.split(/\s+/).map(w => (/[:<>=]/.test(w) ? w : w)).join(' ') : '';
  const q = [words, fq].filter(Boolean).join(' ');
  const [en, it] = await Promise.all([
    api('/cards/search?unique=cards&order=edhrec&q=' + encodeURIComponent(q)).catch(() => null),
    text ? api('/cards/search?unique=cards&order=edhrec&include_multilingual=true&q=' + encodeURIComponent('lang:it ' + q)).catch(() => null) : Promise.resolve(null),
  ]);
  const map = new Map();
  for (const sc of it?.data || []) {
    const c = reduce(sc);
    const known = Cards.get(c.name);
    map.set(c.name, known ? { ...known } : mergeIt({ ...c, printed_name: undefined, printed_text: undefined }, sc));
  }
  for (const sc of en?.data || []) {
    const c = reduce(sc);
    if (map.has(c.name)) { const m = map.get(c.name); Object.assign(m, { ...c, printed_name: m.printed_name, printed_text: m.printed_text, printed_type_line: m.printed_type_line, img: m.img, imgSmall: m.imgSmall, itDone: m.itDone, lang: 'en' }); continue; }
    map.set(c.name, Cards.get(c.name) || c);
  }
  return [...map.values()].slice(0, 120);
}

/** Aggiunge in archivio una carta vista nei risultati (così è disponibile anche offline) */
export async function remember(c) {
  if (Cards.has(c.name) && Cards.get(c.name).itDone) return;
  store(c);
  await idbPut([c]);
  if (!c.itDone) italianLater([c.name]);
}

// ------------------------------------------------------------------------------------------------ accesso
export const card = name => Cards.get(name) || null;
export const defByName = name => DEFS.get(name) || null;
export function nameIt(name) { const d = DEFS.get(name); if (d) return d.nameIt || d.name; const c = Cards.get(name); return c?.printed_name || name; }
export function imageOf(name, big = false) {
  const c = Cards.get(name);
  if (!c) return null;
  if (big) return c.img || c.image_uris?.normal || null;
  return c.imgSmall || c.image_uris?.small || null;
}
export function previewDef(c) { try { return compileCard(c); } catch (_) { return null; } }
