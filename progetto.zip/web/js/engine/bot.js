// Avversario virtuale. Livelli: easy (gioca per divertirsi), medium (gioca bene ma con calma),
// hard (competitivo, neutralizza spesso, non calcola sequenze), nightmare (simula le giocate e gli attacchi).
import {
  defOf, stats, isCreature, isLand, isType, legalActions, actionInfo, targetOptions, matches, respond, run,
  blockOptions, availableMana, colorsAvailable, canPay, attackersFor, cname,
} from './game.js';

export const LEVELS = ['easy', 'medium', 'hard', 'nightmare'];
const lv = l => LEVELS.indexOf(l);

// casualità del bot separata da quella della partita (così il bot facile non altera i mazzi)
let seed = 12345;
const rand = () => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; };
export function seedBot(s) { seed = s & 0x7fffffff || 1; }

// ------------------------------------------------------------------------------------------------ valutazioni
const KW_VAL = { flying: 1.5, deathtouch: 1.5, lifelink: 1, 'first strike': 1, 'double strike': 2.5, trample: 0.6, vigilance: 0.5,
  haste: 0.3, hexproof: 1, indestructible: 2.5, menace: 0.8, reach: 0.4, unblockable: 1.5, defender: -1.5, cantblock: -0.5, cantattack: -2 };

export function permValue(G, o) {
  const d = defOf(o);
  if (isCreature(G, o)) {
    const st = stats(G, o);
    let v = Math.max(0, st.p) * 1.5 + Math.max(0, st.t) * 0.9 + 0.5;
    for (const [k, on] of Object.entries(st.kw)) if (on && KW_VAL[k]) v += KW_VAL[k] * (k === 'double strike' ? Math.max(1, st.p) / 2 : 1);
    v += (d.triggers.length + d.abilities.filter(a => !a.isMana).length + d.statics.length) * 0.8;
    if (o.token) v -= 0.3;
    if (st.kw.cantattack) v *= 0.4;
    return v;
  }
  if (d.types.includes('planeswalker')) return 3 + o.c.loyalty * 1.2;
  if (isLand(o)) return 1.2;
  if (d.abilities.some(a => a.isMana)) return 1.8;
  return 1 + (d.cmc || 1) * 0.8;
}
function cardValue(G, d) {
  if (d.types.includes('land')) return 1.5;
  return 1 + (d.cmc || 0) * 0.7 + (d.types.includes('creature') ? (d.power || 0) * 0.4 : 0.5);
}

/** Valutazione della posizione dal punto di vista di p */
export function evaluate(G, p) {
  const me = G.players[p], op = G.players[1 - p];
  if (G.over) return G.over.winner === p ? 10000 : G.over.winner == null ? 0 : -10000;
  const lifeV = l => (l <= 0 ? -60 : l <= 5 ? l * 2.2 : l <= 10 ? 11 + (l - 5) * 1.3 : 17.5 + (l - 10) * 0.6);
  let v = lifeV(me.life) - lifeV(op.life) * 1.1;
  for (const id of G.bf) {
    const o = G.objs[id];
    const val = permValue(G, o);
    v += o.ctrl === p ? val : -val;
  }
  v += (me.hand.length - op.hand.length) * 1.1;
  const cmd = Math.max(0, ...Object.values(me.cmdDmg));
  v -= cmd * 0.5;
  return v;
}

// ------------------------------------------------------------------------------------------------ intenzioni degli effetti
function intentOf(effects, i) {
  let harm = 0, help = 0, kind = null;
  const uses = r => r && r.r === 'tgt' && r.i === i;
  for (const e of effects) {
    const refs = [e.to, e.what, e.who, e.of, e.a, e.b, e.src].flat().filter(Boolean);
    if (!refs.some(uses)) continue;
    switch (e.e) {
      case 'damage': harm += 2; kind = kind || 'damage'; break;
      case 'bite': if (uses(e.src)) { help++; kind = kind || 'biter'; } else { harm += 2; kind = 'damage'; } break;
      case 'fight': if (uses(e.a)) { help++; } else { harm += 2; kind = 'damage'; } break;
      case 'destroy': case 'exile': harm += 3; kind = 'kill'; break;
      case 'bounce': case 'tuck': harm += 2; kind = 'bounce'; break;
      case 'tap': case 'frost': harm++; kind = kind || 'tap'; break;
      case 'pump': { const neg = (typeof e.t === 'number' && e.t < 0) || e.t === '-X'; if (neg) { harm += 2; kind = 'shrink'; } else if (e.kws?.includes('cantblock')) { harm++; kind = 'cantblock'; } else { help++; kind = kind || 'pump'; } break; }
      case 'counters': if (e.kind === 'm1') { harm++; kind = 'shrink'; } else { help++; kind = kind || 'grow'; } break;
      case 'draw': case 'gain': help++; kind = kind || 'gift'; break;
      case 'discard': case 'lose': case 'mill': case 'edict': harm++; kind = kind || 'hurt'; break;
      case 'regrow': help++; kind = 'regrow'; break;
      case 'counter': harm += 3; kind = 'counter'; break;
      case 'untap': help++; break;
      case 'attach': help++; kind = 'equip'; break;
      case 'gainPow': break;
    }
  }
  return { harm: harm > help, kind };
}

function refObj(G, r) { return r.id !== undefined ? G.objs[r.id] : null; }

/** Sceglie i bersagli migliori; null se l'azione non conviene */
function chooseTargets(G, p, specs, effects, level, opts = {}) {
  const out = [];
  const taken = new Set();
  for (let i = 0; i < specs.length; i++) {
    const { spec, options } = specs[i];
    const avail = options.filter(r => !taken.has(JSON.stringify(r)));
    const intent = intentOf(effects, i);
    const n = spec.count || 1;
    let scored;
    if (intent.kind === 'counter') {
      scored = avail.map(r => { const it = G.stack.find(s => s.sid === r.sid); return { r, s: it && it.ctrl !== p ? spellThreat(G, it) : -99 }; });
    } else if (intent.harm) {
      const dmg = damageOf(G, effects, i, opts.x);
      scored = avail.map(r => {
        if (r.p !== undefined) return { r, s: r.p === p ? -50 : (intent.kind === 'damage' || intent.kind === 'hurt' ? faceScore(G, p, dmg, level) : -5) };
        const o = refObj(G, r);
        if (!o) return { r, s: -50 };
        if (o.zone !== 'bf') return { r, s: o.owner === p ? -20 : 1 };
        const mine = o.ctrl === p;
        const val = permValue(G, o);
        let s = mine ? -val - 10 : val;
        if (!mine && isCreature(G, o)) {
          const st = stats(G, o);
          const left = st.t - o.dmg;
          if (intent.kind === 'damage') s = dmg >= left && !st.kw.indestructible ? val + 2 : -3 + (dmg / Math.max(1, left)) * 0.5;
          if (intent.kind === 'shrink') { const k = shrinkOf(effects, i); s = k >= left ? val + 2 : -2; }
          if (intent.kind === 'kill' && st.kw.indestructible && effects.some(e => e.e === 'destroy')) s = -5;
          if (intent.kind === 'bounce') s = o.token ? val + 3 : (defOf(o).cmc || 1) * 1.2;
          if (intent.kind === 'tap' || intent.kind === 'cantblock') s = st.p + (o.tapped ? -10 : 0);
        }
        if (!mine && isLand(o) && intent.kind !== 'bounce') s = 0.5;
        return { r, s };
      });
    } else {
      scored = avail.map(r => {
        if (r.p !== undefined) return { r, s: r.p === p ? 5 : -10 };
        const o = refObj(G, r);
        if (!o) return { r, s: -50 };
        if (o.zone !== 'bf') return { r, s: o.owner === p ? cardValue(G, defOf(o)) : -10 };
        const mine = o.ctrl === p;
        let s = mine ? permValue(G, o) : -permValue(G, o) - 5;
        if (mine && intent.kind === 'pump' && opts.combat) s += combatPumpGain(G, o);
        if (mine && intent.kind === 'equip' && o.tapped) s -= 1;
        if (mine && intent.kind === 'biter') s = stats(G, o).p * 2 + stats(G, o).t;
        return { r, s };
      });
    }
    scored.sort((a, b) => b.s - a.s);
    if (level === 'easy' && scored.length > 1 && rand() < 0.3) scored.sort(() => rand() - 0.5);
    const pick = scored.filter(x => x.s > (spec.upTo ? 0 : -999)).slice(0, n);
    if (!spec.upTo && !pick.length) return null;
    if (!spec.upTo && pick[0].s < (opts.minScore ?? 0.5) && !opts.forced) return null;
    for (const x of pick) taken.add(JSON.stringify(x.r));
    out.push(pick.map(x => x.r));
  }
  return out;
}
function damageOf(G, effects, i, x) {
  for (const e of effects) if (e.e === 'damage' && e.to.some(r => r.r === 'tgt' && r.i === i)) return e.n === 'X' ? (x || 0) : typeof e.n === 'number' ? e.n : 2;
  for (const e of effects) if ((e.e === 'bite' || e.e === 'fight')) return 3;
  return 2;
}
function shrinkOf(effects, i) {
  for (const e of effects) if (e.e === 'pump' && e.what?.r === 'tgt' && e.what.i === i && typeof e.t === 'number') return -e.t;
  for (const e of effects) if (e.e === 'counters' && e.kind === 'm1') return e.n || 1;
  return 0;
}
function faceScore(G, p, dmg, level) {
  const op = G.players[1 - p];
  if (dmg >= op.life) return 100;
  return lv(level) <= 0 ? 2 : 0.6 + dmg * 0.25;
}
function combatPumpGain(G, o) {
  const C = G.combat;
  if (!C) return 0;
  return C.attackers.some(a => a.id === o.id) || C.blocks.some(b => b.b === o.id) ? 4 : -2;
}
function spellThreat(G, it) {
  const o = G.objs[it.src];
  if (!o) return 0;
  const d = defOf(o);
  let v = (d.cmc || 1) * 1.1;
  if (d.types.includes('creature')) v += (d.power || 0) * 0.4;
  if (it.effects.some(e => e.e === 'destroy' || e.e === 'exile') && it.targets.flat().some(r => r.id && G.objs[r.id]?.ctrl !== it.ctrl)) v += 3;
  if (it.effects.some(e => e.e === 'damage') && it.targets.flat().some(r => r.p !== undefined && r.p !== it.ctrl)) v += 1;
  if (it.effects.some(e => e.e === 'destroy' && e.what.r === 'all')) v += 5;
  if (it.kind === 'ability') v *= 0.6;
  return v;
}

// ------------------------------------------------------------------------------------------------ costruzione delle azioni
function spellInfo(G, p, a) {
  const o = G.objs[a.id];
  const d = defOf(o);
  if (a.t === 'cast') {
    if (d.spell?.modes) return { effects: null, modes: d.spell.modes };
    if (d.auraTarget) {
      const harmful = d.statics.some(s => s.kind === 'attached' && (s.p < 0 || s.t < 0 || s.kws.includes('cantattack') || s.kws.includes('nountap'))) || d.triggers.some(t => t.effects.some(e => e.e === 'tap'));
      return { effects: [{ e: harmful ? 'destroy' : 'attach', what: { r: 'tgt', i: 0 }, to: { r: 'tgt', i: 0 } }] };
    }
    return { effects: d.spell?.effects || [] };
  }
  if (a.t === 'act') return { effects: d.abilities[a.ai].effects };
  return { effects: [] };
}

/** Completa un'azione (bersagli, X, modalità). null = non conviene */
function buildAction(G, p, a, level, opts = {}) {
  const info = actionInfo(G, p, a);
  const o = G.objs[a.id];
  const d = defOf(o);
  const full = { ...a };
  if (a.t === 'land') return full;
  const si = spellInfo(G, p, a);
  if (info.xMax || (d.cost.X && a.t === 'cast')) {
    full.x = info.xMax;
    if (a.t === 'cast' && d.cost.X && info.xMax <= 0) return null;
  }
  if (info.sac) {
    const cands = info.sac.options.filter(id => id !== a.id || d.abilities[a.ai]?.cost?.sacSelf).map(id => G.objs[id]).sort((x, y) => permValue(G, x) - permValue(G, y));
    if (cands.length < info.sac.n) return null;
    full.sac = cands.slice(0, info.sac.n).map(x => x.id);
    if (permValue(G, cands[0]) > 3 && !opts.forced) return null;
  }
  if (info.modes) {
    let best = null;
    for (const m of info.modes) {
      if (!m.ok) continue;
      const mode = d.spell.modes[m.i];
      const tg = chooseTargets(G, p, m.specs, mode.effects, level, { ...opts, x: full.x });
      if (!tg && m.specs.length) continue;
      const score = effectScore(G, p, mode.effects, tg || [], level, opts);
      if (score > (best?.score ?? 0.4)) best = { score, mode: m.i, targets: tg || [] };
    }
    if (!best) return null;
    full.mode = best.mode; full.targets = best.targets; full.score = best.score;
    return full;
  }
  if (!si.effects.length && a.t === 'cast' && !isPermanentSpell(d)) return null;
  if (info.specs.length) {
    const tg = chooseTargets(G, p, info.specs, si.effects, level, { ...opts, x: full.x });
    if (!tg) return null;
    full.targets = tg;
  } else full.targets = [];
  full.score = isPermanentSpell(d) && a.t === 'cast' ? 1 + (d.cmc || 0) : effectScore(G, p, si.effects, full.targets, level, opts);
  return full;
}
const isPermanentSpell = d => !d.types.includes('instant') && !d.types.includes('sorcery');

function effectScore(G, p, effects, targets, level, opts) {
  let s = 0;
  const mine = G.bf.filter(id => G.objs[id].ctrl === p && isCreature(G, G.objs[id]));
  const theirs = G.bf.filter(id => G.objs[id].ctrl !== p && isCreature(G, G.objs[id]));
  const sum = ids => ids.reduce((a, id) => a + permValue(G, G.objs[id]), 0);
  for (const e of effects) {
    switch (e.e) {
      case 'draw': s += (typeof e.n === 'number' ? e.n : 2) * (e.who?.r === 'eachOpp' ? -1 : 1.2); break;
      case 'gain': s += (G.players[p].life < 8 ? 0.6 : 0.2) * (typeof e.n === 'number' ? e.n : 3); break;
      case 'token': s += (typeof e.n === 'number' ? e.n : 2) * (e.named ? 1 : (e.p || 1) + 0.5); break;
      case 'search': s += e.to === 'bf' ? 2.5 : 2; break;
      case 'counters': s += 1; break;
      case 'mana': s += opts.ritual ? 1 : -1; break;
      case 'destroy': case 'exile': case 'bounce': case 'damage': case 'pump':
        if (e.what?.r === 'tgt' || e.to?.some?.(r => r.r === 'tgt')) {
          const idx = e.what?.r === 'tgt' ? e.what.i : e.to.find(r => r.r === 'tgt').i;
          const objs = (targets[idx] || []).filter(r => r.id !== undefined).map(r => G.objs[r.id]).filter(o => o && o.zone === 'bf');
          const ppl = (targets[idx] || []).filter(r => r.p !== undefined);
          for (const o of objs) s += o.ctrl === p ? (e.e === 'pump' ? 1 : -permValue(G, o)) : (e.e === 'pump' ? 0.5 : e.e === 'bounce' ? (defOf(o).cmc || 1) * 0.8 + (o.token ? 3 : 0) : permValue(G, o) + 1);
          for (const r of ppl) s += r.p === p ? -3 : 1.5;
        } else if (e.what?.r === 'all' || e.to?.some?.(r => r.r === 'all')) {
          const sweep = (e.e === 'destroy' || e.e === 'exile' || e.e === 'bounce' || e.e === 'damage' || (e.e === 'pump' && (e.t < 0)));
          if (sweep) {
            const f = e.what?.filter || e.to?.find(r => r.r === 'all')?.filter;
            const hitMine = mine.filter(id => matches(G, G.objs[id], f, p)), hitTheirs = theirs.filter(id => matches(G, G.objs[id], f, p));
            s += sum(hitTheirs) - sum(hitMine) * 1.1 - 2;
          } else s += e.e === 'pump' ? (opts.combat ? 3 : 0.2) : 0;
        } else s += 2;
        break;
      case 'edict': s += theirs.length ? 2.5 : -1; break;
      case 'discard': s += e.who?.r === 'you' ? -0.8 : 1.2; break;
      case 'lose': s += e.who?.r === 'you' ? -0.3 : 1; break;
      case 'counter': s += 3; break;
      case 'regrow': s += 2; break;
      default: s += 0.5;
    }
  }
  void targets; void level;
  return s;
}

// ------------------------------------------------------------------------------------------------ decisione principale
export function botAnswer(G, level = 'medium') {
  const P = G.pending;
  if (!P) return null;
  const p = P.player;
  switch (P.type) {
    case 'mulligan': return mulligan(G, p, level);
    case 'choose': return chooseCards(G, p, P, level);
    case 'yesno': return yesno(G, p, P, level);
    case 'targets': {
      const tr = P.specs;
      const effects = G.stack.length >= 0 ? (findTrigEffects(G, P) || []) : [];
      const tg = chooseTargets(G, p, tr, effects, level, { forced: true, minScore: -999 });
      return { targets: tg || tr.map(s => (s.options.length && !s.spec.upTo ? [s.options[0]] : [])) };
    }
    case 'attack': return { attacks: lv(level) >= 3 && !G.sim ? attackSearch(G, p, P) : attackHeuristic(G, p, P, level) };
    case 'block': return { blocks: blockHeuristic(G, p, P, level) };
    case 'priority': return priority(G, p, P, level);
  }
  return null;
}
function findTrigEffects(G, P) {
  const o = G.objs[P.src];
  if (!o) return null;
  const d = defOf(o);
  const tr = d.triggers.find(t => t.text === P.text);
  return tr ? tr.effects : null;
}

function mulligan(G, p, level) {
  const P = G.players[p];
  const lands = P.hand.filter(id => isLand(G.objs[id])).length;
  if (level === 'easy' || P.mulls >= 2) return { keep: true };
  const n = P.hand.length;
  if (n >= 7 && (lands < 2 || lands > 5)) return { keep: false };
  if (n < 7 && P.mulls === 1 && (lands < 1 || lands > 5)) return { keep: false };
  return { keep: true };
}

function chooseCards(G, p, P, level) {
  const objs = P.cards.map(id => G.objs[id]);
  const me = G.players[p];
  const landsOut = G.bf.filter(id => G.objs[id].ctrl === p && isLand(G.objs[id])).length;
  const landsHand = me.hand.filter(id => isLand(G.objs[id])).length;
  const worst = list => [...list].sort((a, b) => keepScore(a) - keepScore(b));
  function keepScore(o) {
    const d = defOf(o);
    if (d.types.includes('land')) return landsOut + landsHand >= 6 ? 0 : 5 - (landsOut + landsHand) * 0.5;
    const castableSoon = (d.cmc || 0) <= landsOut + 1;
    return cardValue(G, d) + (castableSoon ? 2 : 0) - Math.max(0, (d.cmc || 0) - landsOut - 2);
  }
  switch (P.purpose) {
    case 'bottom': case 'discard': case 'sacrifice': {
      const sorted = P.purpose === 'sacrifice' ? [...objs].sort((a, b) => permValue(G, a) - permValue(G, b)) : worst(objs);
      return { ids: sorted.slice(0, P.min).map(o => o.id) };
    }
    case 'search': {
      const scored = objs.map(o => {
        const d = defOf(o);
        let s = cardValue(G, d);
        if (d.types.includes('land')) {
          const have = colorsAvailable(G, p);
          const gives = d.subtypes.map(st => ({ Plains: 'W', Island: 'U', Swamp: 'B', Mountain: 'R', Forest: 'G' }[st])).filter(Boolean);
          s = gives.filter(c => !have.has(c)).length * 3 + gives.length + (d.etb?.tapped ? -1 : 0);
          const need = new Set();
          for (const id of me.hand) for (const pip of defOf(G.objs[id]).cost.pips) for (const c of pip.any || [pip.c]) need.add(c);
          s += gives.filter(c => need.has(c)).length * 2;
        } else if ((d.cmc || 0) > landsOut + 2) s -= 2;
        return { o, s };
      }).sort((a, b) => b.s - a.s);
      return { ids: scored.slice(0, P.max).map(x => x.o.id) };
    }
    case 'scry': case 'surveil': {
      const away = objs.filter(o => {
        const d = defOf(o);
        if (d.types.includes('land')) return landsOut + landsHand >= 5;
        return (d.cmc || 0) > landsOut + 3 || (landsOut + landsHand < 3 && rand() < 0.3);
      });
      return { ids: away.map(o => o.id) };
    }
  }
  return { ids: objs.slice(0, P.min).map(o => o.id) };
}

function yesno(G, p, P, level) {
  const me = G.players[p];
  switch (P.purpose) {
    case 'shock': {
      const lands = G.bf.filter(id => G.objs[id].ctrl === p && isLand(G.objs[id])).length + 1;
      const useful = me.hand.some(id => { const d = defOf(G.objs[id]); return !d.types.includes('land') && (d.cmc || 0) === lands; });
      return { yes: me.life > 6 && useful };
    }
    case 'payUnless': return { yes: true };
    case 'may': return { yes: P.effect !== 'discard' || me.hand.length > 3 };
  }
  void level;
  return { yes: true };
}

// ------------------------------------------------------------------------------------------------ priorità
function priority(G, p, P, level) {
  const acts = P.actions;
  const L = lv(level);
  const top = G.stack[G.stack.length - 1];
  const myTurn = G.active === p;
  const main = myTurn && (G.step === 'main1' || G.step === 'main2') && !G.stack.length;

  // 1) risposta a una magia avversaria
  if (top) {
    if (top.ctrl === p) return { pass: true };
    const threat = spellThreat(G, top);
    const counterNeed = [99, 4.5, 2.4, 1.8][L];
    const counters = acts.filter(a => a.t === 'cast' && spellInfo(G, p, a).effects?.some(e => e.e === 'counter') || (a.t === 'cast' && defOf(G.objs[a.id]).spell?.modes?.some(m => m.effects.some(e => e.e === 'counter'))));
    if (counters.length && threat >= counterNeed && (L >= 2 || rand() < 0.6)) {
      for (const a of counters) {
        const full = buildAction(G, p, a, level, { minScore: counterNeed });
        if (full && full.targets?.flat().some(r => r.sid === top.sid)) return clean(full);
      }
    }
    // difesa: se una magia sta per uccidere una nostra creatura importante, risposta con un pompaggio (Difficile+)
    return { pass: true };
  }

  // 2) fase principale propria
  if (main) {
    const land = chooseLand(G, p, acts.filter(a => a.t === 'land'));
    if (land) return land;
    if (L >= 3 && !G.sim) {
      const best = simulateBest(G, p, acts, level);
      if (best) return best;
      return { pass: true };
    }
    const cands = [];
    for (const a of acts) {
      if (a.t === 'land') continue;
      const d = defOf(G.objs[a.id]);
      const isInstant = a.t === 'cast' && (d.types.includes('instant') || d.kw.flash) && !isPermanentSpell(d);
      // gli istantanei si tengono per il turno avversario (Difficile), tranne rimozioni utili
      const full = buildAction(G, p, a, level);
      if (!full) continue;
      let s = full.score ?? 1;
      const effs = spellInfo(G, p, a).effects || [];
      if (effs.some(e => e.e === 'counter')) continue;
      if (a.t === 'cast' && isPermanentSpell(d)) s = 3 + (d.cmc || 0) * 1.2 + (d.types.includes('creature') && G.step === 'main1' ? 1 : 0);
      if (isInstant && L >= 2 && effs.some(e => e.e === 'draw') && !effs.some(e => e.e === 'damage' || e.e === 'destroy')) s -= 3;
      if (isInstant && effs.every(e => e.e === 'pump' && e.what?.r === 'tgt')) continue;
      if (a.t === 'act') {
        const ab = d.abilities[a.ai];
        if (ab.cost.loyalty !== undefined) s += 2;
        else if (ab.effects.every(e => e.e === 'pump') && ab.targets?.length === 0) continue; // potenziamenti: solo in combattimento
        else if (ab.cost.sacSelf && !ab.effects.some(e => e.e === 'draw' || e.e === 'search')) { if (s < 3) continue; }
        else if (ab.effects.some(e => e.e === 'mana')) continue;
      }
      if (effs.some(e => e.e === 'mana') && a.t === 'cast') {
        // rituali: solo se dopo si può lanciare qualcosa di grosso
        continue;
      }
      if (s <= 0.4) continue;
      cands.push({ full, s });
    }
    if (!cands.length) return { pass: true };
    cands.sort((a, b) => b.s - a.s);
    let pick = cands[0];
    if (L === 0) {
      if (rand() < 0.15) return { pass: true };
      pick = cands[Math.floor(rand() * Math.min(3, cands.length))];
    }
    return clean(pick.full);
  }

  // 3) momenti a velocità istantaneo
  if (L === 0 && rand() < 0.6) return { pass: true };
  const inCombat = G.combat && (G.step === 'block' || G.step === 'attack');
  for (const a of acts) {
    if (a.t === 'land') continue;
    const d = defOf(G.objs[a.id]);
    const effs = spellInfo(G, p, a).effects || [];
    if (effs.some(e => e.e === 'counter') || effs.some(e => e.e === 'mana')) continue;
    if (a.t === 'act' && d.abilities[a.ai].effects.some(e => e.e === 'mana')) continue;
    // trucchi di combattimento dopo i bloccanti
    if (inCombat && G.step === 'block') {
      const full = buildAction(G, p, a, level, { combat: true });
      if (full && combatTrickWorth(G, p, a, full)) return clean(full);
      continue;
    }
    // rimozione delle creature attaccanti (Medio+), pesca e lampo nel finale avversario (Difficile+)
    if (!myTurn && G.step === 'attack' && G.combat?.attackers.length && L >= 1) {
      const full = buildAction(G, p, a, level, { minScore: 3 });
      if (full && effs.some(e => ['destroy', 'exile', 'damage', 'bounce'].includes(e.e)) && full.targets?.flat().some(r => G.combat.attackers.some(x => x.id === r.id))) return clean(full);
      continue;
    }
    if (!myTurn && G.step === 'end') {
      const full = buildAction(G, p, a, level, { minScore: L >= 2 ? 2 : 3.5 });
      if (!full) continue;
      if (a.t === 'cast' && (d.kw.flash || effs.some(e => e.e === 'draw' || e.e === 'token'))) return clean(full);
      if (a.t === 'act' && d.abilities[a.ai].effects.some(e => e.e === 'draw')) return clean(full);
      if (L >= 2 && effs.some(e => ['destroy', 'exile'].includes(e.e))) return clean(full);
    }
  }
  return { pass: true };
}
const clean = a => { const { score, ...rest } = a; void score; return rest; };

function chooseLand(G, p, lands) {
  if (!lands.length) return null;
  const me = G.players[p];
  const have = colorsAvailable(G, p);
  const need = new Set();
  for (const id of me.hand) for (const pip of defOf(G.objs[id]).cost.pips) for (const c of pip.any || [pip.c]) need.add(c);
  const mana = availableMana(G, p);
  const cheapest = Math.min(99, ...me.hand.map(id => defOf(G.objs[id])).filter(d => !d.types.includes('land')).map(d => d.cmc || 0));
  const scored = lands.map(a => {
    const d = defOf(G.objs[a.id]);
    const gives = new Set();
    for (const ab of d.abilities) if (ab.isMana) for (const e of ab.effects) if (e.e === 'mana') for (const b of e.bundles) for (const c of b) gives.add(c);
    let s = [...gives].filter(c => need.has(c) && !have.has(c)).length * 3 + [...gives].filter(c => need.has(c)).length;
    const otherLands = G.bf.filter(id => G.objs[id].ctrl === p && isLand(G.objs[id])).length;
    const entersTapped = d.etb?.tapped || (d.etb?.unlessCtrl && !G.bf.some(id => G.objs[id].ctrl === p && defOf(G.objs[id]).subtypes.some(st => d.etb.unlessCtrl.includes(st.toLowerCase())))) || (d.etb?.fast && otherLands > 2);
    if (entersTapped) s += cheapest > mana + 1 ? 1 : -2;
    if (d.etb?.shock) s -= 0.5;
    return { a, s };
  }).sort((x, y) => y.s - x.s);
  return { t: 'land', id: scored[0].a.id };
}

function combatTrickWorth(G, p, a, full) {
  const C = G.combat;
  if (!C) return false;
  const tgt = full.targets?.flat().find(r => r.id !== undefined);
  if (!tgt) return false;
  const o = G.objs[tgt.id];
  const effs = spellInfo(G, p, a).effects || [];
  if (o.ctrl !== p) return effs.some(e => ['destroy', 'exile', 'damage'].includes(e.e)) && (C.attackers.some(x => x.id === o.id) || C.blocks.some(b => b.b === o.id));
  // la creatura è bloccata/bloccante e il pompaggio cambia l'esito?
  const pump = effs.find(e => e.e === 'pump');
  if (!pump) return false;
  const pt = typeof pump.t === 'number' ? pump.t : 0, pp = typeof pump.p === 'number' ? pump.p : 0;
  const st = stats(G, o);
  const asAtt = C.attackers.find(x => x.id === o.id);
  const enemies = asAtt ? C.blocks.filter(b => b.a === o.id).map(b => G.objs[b.b]) : C.blocks.filter(b => b.b === o.id).map(b => G.objs[b.a]);
  if (!enemies.length) return asAtt && !asAtt.blocked && pp >= 2 && G.players[1 - p].life <= st.p + pp;
  const inc = enemies.reduce((s, e) => s + stats(G, e).p, 0);
  const diesNow = inc >= st.t - o.dmg, diesAfter = inc >= st.t + pt - o.dmg;
  const killsNow = enemies.some(e => st.p >= stats(G, e).t - e.dmg), killsAfter = enemies.some(e => st.p + pp >= stats(G, e).t - e.dmg);
  return (diesNow && !diesAfter) || (!killsNow && killsAfter);
}

// ------------------------------------------------------------------------------------------------ combattimento
function canBlockSim(G, b, a) {
  const bs = stats(G, b), as = stats(G, a);
  if (bs.kw.cantblock || b.tapped) return false;
  if (as.kw.unblockable) return false;
  if (as.kw.flying && !bs.kw.flying && !bs.kw.reach) return false;
  if (bs.kw.blockflyonly && !as.kw.flying) return false;
  const ev = Object.keys(as.kw).find(k => /^evade\d$/.test(k));
  if (ev && bs.p <= +ev.slice(5)) return false;
  return true;
}
function kills(G, x, y) { // x uccide y in un combattimento uno contro uno?
  const xs = stats(G, x), ys = stats(G, y);
  if (xs.p <= 0) return false;
  if (ys.kw.indestructible) return false;
  return xs.kw.deathtouch || xs.p >= ys.t - y.dmg;
}

function attackHeuristic(G, p, P, level) {
  const L = lv(level);
  const opp = G.players[1 - p];
  const me = G.players[p];
  const atk = P.options.map(id => G.objs[id]);
  const blockers = G.bf.map(id => G.objs[id]).filter(o => o.ctrl !== p && isCreature(G, o) && !o.tapped && !stats(G, o).kw.cantblock);
  const out = [];
  // attacco totale se letale
  const evasive = a => !blockers.some(b => canBlockSim(G, b, a));
  const totalEvasive = atk.filter(evasive).reduce((s, a) => s + stats(G, a).p, 0);
  const sortedPow = atk.filter(a => !evasive(a)).map(a => stats(G, a).p).sort((x, y) => y - x);
  const absorbed = sortedPow.slice(0, blockers.length).reduce((s, x) => s + x, 0);
  const potential = totalEvasive + sortedPow.reduce((s, x) => s + x, 0) - absorbed;
  if (L >= 1 && potential >= opp.life) return atk.map(a => ({ id: a.id, tgt: { p: 1 - p } }));
  // quanto può farci l'avversario al turno dopo
  const oppAttackers = G.bf.map(id => G.objs[id]).filter(o => o.ctrl !== p && isCreature(G, o) && !stats(G, o).kw.defender);
  const oppPower = oppAttackers.reduce((s, o) => s + Math.max(0, stats(G, o).p), 0);
  let keepBack = [];
  for (const a of atk) {
    const st = stats(G, a);
    if (st.p <= 0) continue;
    const able = blockers.filter(b => canBlockSim(G, b, a));
    const killers = able.filter(b => kills(G, b, a));
    const safe = !killers.length;
    const trade = killers.filter(b => kills(G, a, b));
    const bad = killers.filter(b => !kills(G, a, b));
    let go;
    if (L === 0) go = safe || (bad.length === 0 && rand() < 0.6) || rand() < 0.15;
    else if (safe) go = true;
    else if (bad.length) go = false;
    else go = trade.every(b => permValue(G, b) >= permValue(G, a) * (L >= 2 ? 0.9 : 1.1));
    if (go) out.push(a); else keepBack.push(a);
  }
  // difesa: se l'avversario può colpire letalmente, si tengono indietro bloccanti
  if (L >= 1) {
    const vigil = out.filter(a => stats(G, a).kw.vigilance);
    let defenders = [...keepBack, ...vigil];
    const defPower = () => defenders.reduce((s, d) => s + Math.max(stats(G, d).t, 1), 0);
    while (out.length && oppPower - defPower() * 0.8 >= me.life) {
      const sorted = out.filter(a => !stats(G, a).kw.vigilance).sort((x, y) => stats(G, y).t - stats(G, x).t);
      if (!sorted.length) break;
      const a = sorted[0];
      out.splice(out.indexOf(a), 1);
      defenders.push(a);
    }
  }
  const pws = P.targets.filter(t => t.id !== undefined);
  return out.map(a => {
    let tgt = { p: 1 - p };
    if (pws.length && L >= 1 && evasive(a) && opp.life > 8) tgt = pws[0];
    return { id: a.id, tgt };
  });
}

function blockHeuristic(G, p, P, level) {
  const L = lv(level);
  const me = G.players[p];
  const opts = P.options; // { bloccante: [attaccanti] }
  const used = new Set();
  const blocks = [];
  const C = G.combat;
  const atkObjs = C.attackers.map(a => G.objs[a.id]).filter(Boolean);
  atkObjs.sort((x, y) => stats(G, y).p - stats(G, x).p);
  const canB = (bid, aid) => opts[bid] && opts[bid].includes(aid) && !used.has(bid);
  const dmgOf = a => (C.attackers.find(x => x.id === a.id)?.tgt?.p === p ? Math.max(0, stats(G, a).p) * (stats(G, a).kw['double strike'] ? 2 : 1) : 0);
  for (const a of atkObjs) {
    const as = stats(G, a);
    if (as.kw.menace) continue;
    const cands = Object.keys(opts).map(Number).filter(bid => canB(bid, a.id)).map(id => G.objs[id]);
    // blocco perfetto: uccide e sopravvive
    let pick = cands.filter(b => kills(G, b, a) && !kills(G, a, b)).sort((x, y) => permValue(G, x) - permValue(G, y))[0];
    if (!pick && L >= 1) pick = cands.filter(b => !kills(G, a, b) && !as.kw.trample).sort((x, y) => permValue(G, x) - permValue(G, y))[0];
    if (!pick && L >= 1) pick = cands.filter(b => kills(G, b, a) && permValue(G, b) <= permValue(G, a) * (L >= 2 ? 1.05 : 0.9)).sort((x, y) => permValue(G, x) - permValue(G, y))[0];
    if (!pick && L === 0 && rand() < 0.35) pick = cands[Math.floor(rand() * cands.length)];
    if (pick) { used.add(pick.id); blocks.push({ b: pick.id, a: a.id }); }
  }
  // blocco doppio (Difficile+): due creature insieme uccidono un attaccante grosso
  if (L >= 2) {
    for (const a of atkObjs) {
      if (blocks.some(b => b.a === a.id)) continue;
      const free = Object.keys(opts).map(Number).filter(bid => canB(bid, a.id)).map(id => G.objs[id]);
      if (free.length < 2) continue;
      const pair = free.sort((x, y) => stats(G, y).p - stats(G, x).p).slice(0, 2);
      const sumP = pair.reduce((s, b) => s + stats(G, b).p, 0);
      const as = stats(G, a);
      if (sumP >= as.t && !as.kw.indestructible && permValue(G, a) > Math.min(...pair.map(b => permValue(G, b))) * 1.3) {
        for (const b of pair) { used.add(b.id); blocks.push({ b: b.id, a: a.id }); }
      }
    }
  }
  // emergenza: il danno in arrivo è letale -> blocchi di sacrificio
  const incoming = () => atkObjs.filter(a => !blocks.some(b => b.a === a.id)).reduce((s, a) => s + dmgOf(a), 0)
    + atkObjs.filter(a => stats(G, a).kw.trample && blocks.some(b => b.a === a.id)).reduce((s, a) => s + Math.max(0, stats(G, a).p - blocks.filter(b => b.a === a.id).reduce((t, b) => t + stats(G, G.objs[b.b]).t, 0)), 0);
  let guard = 0;
  while (incoming() >= me.life && guard++ < 10) {
    const open = atkObjs.filter(a => !blocks.some(b => b.a === a.id) && dmgOf(a) > 0).sort((x, y) => dmgOf(y) - dmgOf(x));
    let done = false;
    for (const a of open) {
      const need = stats(G, a).kw.menace ? 2 : 1;
      const cands = Object.keys(opts).map(Number).filter(bid => canB(bid, a.id)).map(id => G.objs[id]).sort((x, y) => permValue(G, x) - permValue(G, y));
      if (cands.length >= need) { for (const b of cands.slice(0, need)) { used.add(b.id); blocks.push({ b: b.id, a: a.id }); } done = true; break; }
    }
    if (!done) break;
  }
  return blocks;
}

// ------------------------------------------------------------------------------------------------ Incubo: simulazione
function cloneForSim(G) {
  const C = structuredClone({ ...G, log: [] });
  C.sim = true;
  return C;
}
/** Porta avanti la simulazione finché p non ha di nuovo la priorità a pila vuota (o finisce il turno) */
function simUntil(C, p, stopAtStep = null, maxSteps = 60) {
  let n = 0;
  run(C, 20000);
  while (C.pending && !C.over && n++ < maxSteps) {
    const P = C.pending;
    if (P.type === 'priority' && P.player === p && !C.stack.length && (!stopAtStep || C.step === stopAtStep)) return C;
    if (stopAtStep && C.step === stopAtStep && P.type === 'priority' && !C.stack.length) return C;
    let ans;
    if (P.type === 'priority') ans = P.player === p ? { pass: true } : { pass: true };
    else ans = botAnswer(C, 'hard');
    respond(C, ans);
  }
  return C;
}

function simulateBest(G, p, acts, level) {
  const base = evaluate(G, p);
  let best = null;
  const tried = new Set();
  for (const a of acts) {
    const d = defOf(G.objs[a.id]);
    const key = a.t + ':' + G.objs[a.id].key + ':' + (a.ai ?? '');
    if (tried.has(key)) continue;
    tried.add(key);
    const variants = [];
    const full = buildAction(G, p, a, 'hard', {});
    if (full) variants.push(full);
    if (a.t === 'act' && d.abilities[a.ai].effects.every(e => e.e === 'pump' || e.e === 'mana')) continue;
    for (const v of variants) {
      const effs = spellInfo(G, p, a).effects || [];
      if (effs.some(e => e.e === 'counter')) continue;
      const C = cloneForSim(G);
      respond(C, clean(v));
      simUntil(C, p);
      let score = evaluate(C, p);
      // gli istantanei valgono di più se tenuti per il turno avversario
      if (a.t === 'cast' && (d.types.includes('instant') || d.kw.flash) && !effs.some(e => ['destroy', 'exile'].includes(e.e))) score -= 1.2;
      if (a.t === 'cast' && effs.some(e => e.e === 'mana')) score -= 0.5;
      if (score > base + 0.3 && (!best || score > best.score)) best = { score, action: clean(v) };
    }
  }
  void level;
  return best ? best.action : null;
}

/** Incubo: prova le combinazioni di attaccanti e simula la risposta dell'avversario */
function attackSearch(G, p, P) {
  const ids = P.options;
  const heur = attackHeuristic(G, p, P, 'hard');
  const subsets = [];
  if (ids.length <= 6) {
    for (let m = 0; m < 1 << ids.length; m++) subsets.push(ids.filter((_, i) => m & (1 << i)));
  } else {
    subsets.push(heur.map(a => a.id), [], ids);
    for (let k = 0; k < 20; k++) subsets.push(ids.filter(() => rand() < 0.5));
  }
  let best = null;
  for (const sub of subsets) {
    const C = cloneForSim(G);
    respond(C, { attacks: sub.map(id => ({ id, tgt: { p: 1 - p } })) });
    simUntil(C, p, 'main2');
    let score = evaluate(C, p);
    // rischio del contrattacco
    const me = C.players[p];
    const oppPower = C.bf.map(id => C.objs[id]).filter(o => o.ctrl !== p && isCreature(C, o) && !stats(C, o).kw.defender).reduce((s, o) => s + Math.max(0, stats(C, o).p), 0);
    const myDef = C.bf.map(id => C.objs[id]).filter(o => o.ctrl === p && isCreature(C, o)).length;
    const danger = oppPower - myDef * 2;
    if (danger >= me.life) score -= 40;
    else if (danger >= me.life - 3) score -= 6;
    if (!best || score > best.score + 0.01) best = { score, sub };
  }
  return (best?.sub || []).map(id => ({ id, tgt: { p: 1 - p } }));
}

export { buildAction, chooseTargets };
void cname; void isType; void canPay; void attackersFor; void targetOptions;
