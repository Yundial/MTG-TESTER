// Motore delle regole di Magic: turni, priorità, pila, combattimento, azioni di stato, Commander.
// Lo stato della partita (G) è un oggetto di soli dati: si può copiare con structuredClone (serve al bot Incubo).
import { compileCard, tokenDef } from './cards.js';
import { planPayment, totalMana, producibleColors } from './mana.js';

export const DEFS = new Map();
export function registerCard(sc) {
  const def = compileCard(sc);
  DEFS.set(def.name, def);
  if (sc.name && sc.name !== def.name) DEFS.set(sc.name, def);
  return def;
}
export const defOf = o => DEFS.get(o.key);
export const cname = o => { const d = defOf(o); return d ? (d.nameIt || d.name) : '?'; };

export const STEPS = ['untap', 'upkeep', 'draw', 'main1', 'bcombat', 'attack', 'block', 'fsdamage', 'damage', 'ecombat', 'main2', 'end', 'cleanup'];
export const STEP_IT = { untap: 'Stap', upkeep: 'Mantenimento', draw: 'Acquisizione', main1: 'Prima fase principale', bcombat: 'Inizio combattimento',
  attack: 'Dichiarazione attaccanti', block: 'Dichiarazione bloccanti', fsdamage: 'Danno (attacco improvviso)', damage: 'Danno da combattimento',
  ecombat: 'Fine combattimento', main2: 'Seconda fase principale', end: 'Finale', cleanup: 'Cancellazione' };
const COLOR_ORDER = ['W', 'U', 'B', 'R', 'G'];
const emptyPool = () => ({ W: 0, U: 0, B: 0, R: 0, G: 0, C: 0 });

// ------------------------------------------------------------------------------------------------ utilità
function rnd(G) {
  G.seed = (G.seed + 0x6D2B79F5) | 0;
  let t = G.seed;
  t = Math.imul(t ^ (t >>> 15), t | 1);
  t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
}
function shuffle(G, arr) {
  for (let i = arr.length - 1; i > 0; i--) { const j = Math.floor(rnd(G) * (i + 1)); [arr[i], arr[j]] = [arr[j], arr[i]]; }
}
// "Tu lancia" -> "Tu lanci": verbi alla seconda persona per il giocatore umano
const TU = { gioca: 'giochi', lancia: 'lanci', attiva: 'attivi', attacca: 'attacchi', blocca: 'blocchi', paga: 'paghi', pesca: 'peschi', scarta: 'scarti',
  guadagna: 'guadagni', perde: 'perdi', crea: 'crei', sacrifica: 'sacrifichi', cerca: 'cerchi', macina: 'macini', profetizza: 'profetizzi',
  sorveglia: 'sorvegli', tiene: 'tieni', fa: 'fai', vince: 'vinci', 'non blocca': 'non blocchi' };
function tu(text) {
  return text.replace(/^Tu (non blocca|\w+)/, (m, v) => 'Tu ' + (TU[v] || v)).replace(/ a Tu\b/g, ' a te').replace(/^Inizia Tu\./, 'Inizi tu.');
}
export function log(G, text, p = null) {
  if (G.sim) return;
  text = tu(text);
  G.log.push({ text, p, turn: G.turn });
  if (G.log.length > 400) G.log.splice(0, G.log.length - 400);
}
const opp = (G, p) => 1 - p;

function newObj(G, key, owner, zone) {
  const o = { id: G.nextId++, key, owner, ctrl: owner, zone, tapped: false, sick: true, dmg: 0, dt: false,
    c: { p1: 0, m1: 0, loyalty: 0 }, att: null, temp: [], zcc: 0, cmd: false, token: false, frost: 0, ts: 0, used: {}, pwUsed: false };
  G.objs[o.id] = o;
  return o;
}

export const isType = (o, t) => !!defOf(o)?.types.includes(t);
export const isCreature = (G, o) => isType(o, 'creature');
export const isLand = o => isType(o, 'land');
export const isPermanentCard = o => { const d = defOf(o); return d && !d.types.includes('instant') && !d.types.includes('sorcery'); };

/** Forza, costituzione e abilità attuali (con segnalini, effetti statici, Aure, Equipaggiamenti e modifiche temporanee) */
export function stats(G, o, shallow = false) {
  const d = defOf(o);
  let p = d.power ?? 0, t = d.toughness ?? 0;
  const kw = { ...d.kw };
  p += o.c.p1 - o.c.m1; t += o.c.p1 - o.c.m1;
  if (o.zone === 'bf' && !shallow) {
    for (const id of G.bf) {
      const s = G.objs[id];
      const sd = defOf(s);
      if (!sd.statics.length) continue;
      for (const st of sd.statics) {
        if (st.kind === 'anthem') {
          if (!isCreature(G, o)) continue;
          if (!matches(G, o, st.filter, s.ctrl, s.id, true)) continue;
        } else if (st.kind === 'attached') {
          if (s.att !== o.id) continue;
        } else continue;
        p += st.p; t += st.t;
        for (const k of st.kws) kw[k] = true;
      }
    }
  }
  for (const m of o.temp) { p += m.p; t += m.t; for (const k of m.kws) kw[k] = true; }
  return { p, t, kw };
}
export const hasKw = (G, o, k) => !!stats(G, o).kw[k];
export const power = (G, o) => stats(G, o).p;
export const toughness = (G, o) => stats(G, o).t;

/** Il permanente/carta corrisponde al filtro? (ctrlP = chi controlla l'abilità, srcId = la fonte) */
export function matches(G, o, f, ctrlP, srcId = null, shallow = false) {
  if (!f) return true;
  const d = defOf(o);
  if (!d) return false;
  if (f.types.length && !f.types.some(t => d.types.includes(t))) return false;
  if (f.subtypes.length && !f.subtypes.some(s => d.subtypes.some(x => x.toLowerCase() === s))) return false;
  if (f.permanent && !isPermanentCard(o)) return false;
  if (f.supers && !f.supers.every(s => d.supertypes.includes(s))) return false;
  if (f.non.some(t => d.types.includes(t) || d.supertypes.includes(t))) return false;
  if (f.nonsub.some(s => d.subtypes.some(x => x.toLowerCase() === s))) return false;
  if (f.colors.length && !f.colors.some(c => d.colors.includes(c))) return false;
  if (f.noncolors.some(c => d.colors.includes(c))) return false;
  if (f.colorless && d.colors.length) return false;
  if (f.multicolor && d.colors.length < 2) return false;
  const who = o.zone === 'bf' || o.zone === 'stack' ? o.ctrl : o.owner;
  if (f.ctrl === 'you' && who !== ctrlP) return false;
  if (f.ctrl === 'opp' && who === ctrlP) return false;
  if (f.other && o.id === srcId) return false;
  if (f.token && !o.token) return false;
  if (f.nontoken && o.token) return false;
  if (f.tapped && !o.tapped) return false;
  if (f.untapped && o.tapped) return false;
  if (f.mvMax != null && (d.cmc ?? 0) > f.mvMax) return false;
  if (f.mvMin != null && (d.cmc ?? 0) < f.mvMin) return false;
  if (f.attacking || f.blocking || f.combat) {
    const C = G.combat;
    const att = !!C?.attackers.some(a => a.id === o.id);
    const blk = !!C?.blocks.some(b => b.b === o.id);
    if (f.attacking && !att) return false;
    if (f.blocking && !blk) return false;
    if (f.combat && !att && !blk) return false;
  }
  if (f.kws.length || f.nokws.length || f.powMax != null || f.powMin != null || f.touMax != null || f.touMin != null) {
    const st = o.zone === 'bf' ? stats(G, o, shallow) : { p: d.power ?? 0, t: d.toughness ?? 0, kw: d.kw };
    if (f.kws.some(k => !st.kw[k])) return false;
    if (f.nokws.some(k => st.kw[k])) return false;
    if (f.powMax != null && st.p > f.powMax) return false;
    if (f.powMin != null && st.p < f.powMin) return false;
    if (f.touMax != null && st.t > f.touMax) return false;
    if (f.touMin != null && st.t < f.touMin) return false;
  }
  return true;
}

export function commanderIdentity(G, p) {
  const id = G.players[p].commanderId;
  if (!id) return [];
  return defOf(G.objs[id]).identity || [];
}
const H = { defOf, isCreature, hasKw, commanderIdentity };
export const manaHelpers = H;

// ------------------------------------------------------------------------------------------------ creazione della partita
/**
 * cfg = { format: 'constructed'|'commander', seed, first: 0|1|null,
 *         players: [{ name, deck: [nomi], commander: nome|null, bot: null|'easy'|'medium'|'hard'|'nightmare' }] }
 */
export function createGame(cfg) {
  const G = {
    seed: cfg.seed ?? ((Math.random() * 2 ** 31) | 0), format: cfg.format || 'constructed', turn: 0, active: 0, step: 'setup',
    objs: {}, nextId: 1, bf: [], stack: [], nextSid: 1, players: [], tasks: [], pending: null, trig: [], log: [],
    over: null, combat: null, links: {}, ts: 0, startPlayer: 0, stopAll: false, actions: 0, sim: false,
  };
  cfg.players.forEach((pc, i) => {
    const P = { i, name: pc.name, bot: pc.bot ?? null, life: G.format === 'commander' ? 40 : 20, library: [], hand: [], gy: [], exile: [], command: [],
      pool: emptyPool(), landsPlayed: 0, cmdTax: 0, cmdDmg: {}, mulls: 0, drewEmpty: false, lost: false, commanderId: null };
    G.players.push(P);
    if (pc.commander && DEFS.has(pc.commander)) {
      const o = newObj(G, DEFS.get(pc.commander).name, i, 'command');
      o.cmd = true; P.command.push(o.id); P.commanderId = o.id;
    }
    for (const name of pc.deck) {
      if (!DEFS.has(name)) continue;
      const o = newObj(G, DEFS.get(name).name, i, 'library');
      P.library.push(o.id);
    }
    shuffle(G, P.library);
  });
  G.active = cfg.first ?? (rnd(G) < 0.5 ? 0 : 1);
  G.startPlayer = G.active;
  log(G, `Inizia ${G.players[G.active].name}.`);
  for (const P of G.players) drawN(G, P.i, 7, true);
  G.tasks.push({ t: 'mull', p: G.active }, { t: 'mull', p: 1 - G.active }, { t: 'firstTurn' });
  return G;
}

// ------------------------------------------------------------------------------------------------ zone
function zoneArr(G, o) {
  const P = G.players[o.owner];
  switch (o.zone) {
    case 'bf': return G.bf;
    case 'library': return P.library;
    case 'hand': return P.hand;
    case 'gy': return P.gy;
    case 'exile': return P.exile;
    case 'command': return P.command;
    default: return null;
  }
}

/** Sposta un oggetto in un'altra zona. Restituisce le "ultime informazioni note" se lasciava il campo. */
export function moveTo(G, id, dest, opt = {}) {
  const o = G.objs[id];
  if (!o) return null;
  const from = o.zone;
  if (from === dest && dest !== 'library') return null;
  const origDest = dest;
  // il comandante torna nella zona di comando
  if (o.cmd && ['gy', 'exile', 'hand', 'library'].includes(dest)) {
    if (from !== 'command') log(G, `${cname(o)} torna nella zona di comando.`, o.owner);
    dest = 'command';
    if (from === 'command') return null;
  }
  const wasBf = from === 'bf';
  let lki = null;
  if (wasBf) {
    const st = stats(G, o);
    lki = { p: st.p, t: st.t, ctrl: o.ctrl, id: o.id, key: o.key, token: o.token, att: o.att, kw: st.kw };
  }
  const arr = zoneArr(G, o);
  if (arr) { const i = arr.indexOf(id); if (i >= 0) arr.splice(i, 1); }
  if (from === 'stack') { const i = G.stack.findIndex(s => s.kind === 'spell' && s.src === id); if (i >= 0) G.stack.splice(i, 1); }
  if (wasBf) {
    o.tapped = false; o.dmg = 0; o.dt = false; o.c = { p1: 0, m1: 0, loyalty: 0 }; o.temp = []; o.att = null; o.frost = 0; o.used = {}; o.pwUsed = false;
    o.ctrl = o.owner;
    if (G.combat) {
      G.combat.attackers = G.combat.attackers.filter(a => a.id !== id);
      G.combat.blocks = G.combat.blocks.filter(b => b.b !== id);
    }
    // gli Equipaggiamenti restano sul campo, sganciati
    for (const bid of G.bf) { const b = G.objs[bid]; if (b.att === id && isType(b, 'artifact')) b.att = null; }
  }
  o.zone = dest;
  o.zcc++;
  if (o.token && dest !== 'bf') o.zone = 'gone';
  else {
    const P = G.players[o.owner];
    if (dest === 'bf') G.bf.push(id);
    else if (dest === 'library') { if (opt.bottom) P.library.push(id); else P.library.unshift(id); }
    else if (dest === 'hand') P.hand.push(id);
    else if (dest === 'gy') P.gy.push(id);
    else if (dest === 'exile') P.exile.push(id);
    else if (dest === 'command') P.command.push(id);
  }
  if (wasBf) {
    // "finché X resta sul campo"
    const link = G.links[id];
    if (link && link.auto) {
      delete G.links[id];
      for (const lid of link.ids) {
        const l = G.objs[lid];
        if (l && l.zone === 'exile' && l.zcc === link.zcc[lid]) enterBf(G, lid, l.owner);
      }
    }
    fire(G, 'ltb', { obj: o, lki });
    if (origDest === 'gy' && defOf(o).types.includes('creature')) fire(G, 'dies', { obj: o, lki });
  }
  return lki;
}

/** Un permanente entra sul campo di battaglia */
export function enterBf(G, id, ctrl, opt = {}) {
  const o = G.objs[id];
  const d = defOf(o);
  moveTo(G, id, 'bf');
  if (o.zone !== 'bf') return;
  o.ctrl = ctrl; o.sick = true; o.ts = ++G.ts; o.tapped = false;
  const e = d.etb || {};
  let tapped = !!opt.tapped || !!e.tapped;
  if (e.unlessCtrl) {
    const has = G.bf.some(x => x !== id && G.objs[x].ctrl === ctrl && defOf(G.objs[x]).subtypes.some(s => e.unlessCtrl.includes(s.toLowerCase())));
    if (!has) tapped = true;
  }
  const otherLands = G.bf.filter(x => x !== id && G.objs[x].ctrl === ctrl && isLand(G.objs[x])).length;
  if (e.fast && otherLands > 2) tapped = true;
  if (e.slow && otherLands < 2) tapped = true;
  if (e.shock && !opt.shockPaid) tapped = true;
  o.tapped = tapped;
  if (e.counters) o.c.p1 += e.counters;
  if (d.types.includes('planeswalker')) o.c.loyalty = d.loyalty || 0;
  if (opt.attachTo) o.att = opt.attachTo;
  fire(G, 'etb', { obj: o });
}

export function drawN(G, p, n, setup = false) {
  const P = G.players[p];
  for (let i = 0; i < n; i++) {
    if (!P.library.length) { if (!setup) P.drewEmpty = true; return; }
    const id = P.library[0];
    moveTo(G, id, 'hand');
    if (!setup) fire(G, 'draw', { p });
  }
}

function gainLife(G, p, n) {
  if (n <= 0) return;
  G.players[p].life += n;
  fire(G, 'gainLife', { p, n });
}

// ------------------------------------------------------------------------------------------------ inneschi
function fire(G, ev, data) {
  const add = (o, ab, extra = {}) => {
    const d = defOf(o);
    G.trig.push({ ab, src: o.id, srcZcc: o.zcc, key: o.key, ctrl: extra.ctrl ?? o.ctrl, name: d.nameIt || d.name, ...extra });
  };
  const own = (o, on, extra) => { const d = defOf(o); if (!d) return; for (const ab of d.triggers) if (ab.on.includes(on)) add(o, ab, extra); };
  const each = (fn) => { for (const id of [...G.bf]) fn(G.objs[id]); };
  switch (ev) {
    case 'etb': {
      const o = data.obj;
      own(o, 'etb');
      each(s => {
        for (const ab of defOf(s).triggers) if (ab.on.includes('enters') && matches(G, o, ab.filter, s.ctrl, s.id)) add(s, ab, { trigObj: o.id, trigZcc: o.zcc });
      });
      break;
    }
    case 'dies': {
      const o = data.obj, lki = data.lki;
      const d = defOf(o);
      for (const ab of d.triggers) if (ab.on.includes('dies')) add(o, ab, { ctrl: lki.ctrl, lki });
      each(s => {
        for (const ab of defOf(s).triggers) if (ab.on.includes('dies2')) {
          const fake = { ...o, zone: 'bf', ctrl: lki.ctrl };
          if (matches(G, fake, ab.filter, s.ctrl, s.id, true)) add(s, ab, { trigObj: o.id, trigPlayer: lki.ctrl });
        }
      });
      break;
    }
    case 'ltb': {
      const o = data.obj;
      for (const ab of defOf(o).triggers) if (ab.on.includes('ltb')) add(o, ab, { ctrl: data.lki.ctrl, lki: data.lki });
      break;
    }
    case 'attacks': own(data.obj, 'attacks'); each(s => { if (s.ctrl === data.obj.ctrl) for (const ab of defOf(s).triggers) if (ab.on.includes('allyAttacks')) add(s, ab, { trigObj: data.obj.id, trigZcc: data.obj.zcc }); }); break;
    case 'blocks': own(data.obj, 'blocks'); break;
    case 'cdp': own(data.obj, 'cdp', { trigPlayer: data.p }); break;
    case 'step': each(s => { if (s.ctrl === G.active) own(s, data.on); if (data.on === 'endstep') own(s, 'eachEndstep'); }); break;
    case 'cast': each(s => {
      if (s.ctrl !== data.p) return;
      for (const ab of defOf(s).triggers) if (ab.on.includes('cast') && (!ab.filter || matches(G, data.obj, { ...ab.filter, ctrl: null }, data.p))) add(s, ab);
    }); break;
    case 'gainLife': each(s => { if (s.ctrl === data.p) own(s, 'gainLife'); }); break;
    case 'draw': each(s => {
      if (s.ctrl === data.p) own(s, 'drawYou');
      else own(s, 'drawOpp', { trigPlayer: data.p });
    }); break;
  }
}

// ------------------------------------------------------------------------------------------------ bersagli
function canTarget(G, p, o) {
  if (o.zone !== 'bf') return true;
  const st = stats(G, o);
  if (st.kw.shroud) return false;
  if (st.kw.hexproof && o.ctrl !== p) return false;
  return true;
}

/** Possibili bersagli per una specifica (players: {p}, oggetti: {id, zcc}, magie: {sid}) */
export function targetOptions(G, p, spec, srcId = null) {
  const out = [];
  const bfObjs = G.bf.map(id => G.objs[id]);
  const players = [0, 1].filter(i => !G.players[i].lost);
  switch (spec.kind) {
    case 'any':
      for (const i of players) out.push({ p: i });
      for (const o of bfObjs) if ((isCreature(G, o) || (!spec.noPw && isType(o, 'planeswalker'))) && canTarget(G, p, o) && !(spec.other && o.id === srcId)) out.push({ id: o.id, zcc: o.zcc });
      break;
    case 'player': for (const i of players) out.push({ p: i }); break;
    case 'opp': for (const i of players) if (i !== p) out.push({ p: i }); break;
    case 'playerpw':
      for (const i of players) if (!spec.opp || i !== p) out.push({ p: i });
      for (const o of bfObjs) if (isType(o, 'planeswalker') && (!spec.opp || o.ctrl !== p) && canTarget(G, p, o)) out.push({ id: o.id, zcc: o.zcc });
      break;
    case 'obj':
      for (const o of bfObjs) if (matches(G, o, spec.filter, p, srcId) && canTarget(G, p, o) && !(spec.other && o.id === srcId)) out.push({ id: o.id, zcc: o.zcc });
      break;
    case 'spell':
      for (const s of G.stack) {
        if (s.kind !== 'spell' || s.src === srcId) continue;
        if (!spec.filter || matches(G, G.objs[s.src], { ...spec.filter, ctrl: spec.filter.ctrl }, p)) out.push({ sid: s.sid });
      }
      break;
    case 'card':
      for (const i of [0, 1]) {
        if (spec.filter.ctrl === 'you' && i !== p) continue;
        if (spec.filter.ctrl === 'opp' && i === p) continue;
        for (const id of G.players[i].gy) if (matches(G, G.objs[id], { ...spec.filter, ctrl: null }, p)) out.push({ id, zcc: G.objs[id].zcc });
      }
      break;
  }
  return out;
}
const sameRef = (a, b) => (a.p !== undefined ? a.p === b.p : a.sid !== undefined ? a.sid === b.sid : a.id === b.id && a.zcc === b.zcc);

function targetStillLegal(G, item, spec, r) {
  if (r.p !== undefined) return !G.players[r.p].lost;
  if (r.sid !== undefined) return G.stack.some(s => s.sid === r.sid);
  const o = G.objs[r.id];
  if (!o || o.zcc !== r.zcc) return false;
  return targetOptions(G, item.ctrl, spec, item.src).some(x => sameRef(x, r));
}

// ------------------------------------------------------------------------------------------------ azioni possibili
const isMain = G => G.step === 'main1' || G.step === 'main2';
function sorceryOk(G, p) { return G.active === p && isMain(G) && !G.stack.length; }

function cmdTax(G, o) { return o.cmd ? G.players[o.owner].cmdTax * 2 : 0; }
/** Riduzioni di costo (es. "Le magie Goblin che lanci costano {1} in meno") */
function reduction(G, p, o) {
  let n = 0;
  for (const id of G.bf) {
    const s = G.objs[id];
    if (s.ctrl !== p) continue;
    for (const st of defOf(s).statics) if (st.kind === 'reduce' && matches(G, o, { ...st.filter, ctrl: null }, p)) n += st.n;
  }
  return n;
}
const extraCost = (G, p, o) => cmdTax(G, o) - reduction(G, p, o);

function spellSpecs(d) {
  if (d.spell?.modes) return null;
  if (d.auraTarget) return [d.auraTarget];
  return d.spell?.targets || [];
}
function specsOk(G, p, specs, srcId) {
  return specs.every(s => s.upTo || targetOptions(G, p, s, srcId).length >= 1);
}

function abilityCostOk(G, p, o, ab) {
  const c = ab.cost;
  if (c.tap && (o.tapped || (isCreature(G, o) && o.sick && !hasKw(G, o, 'haste')))) return false;
  if (c.life && G.players[p].life < c.life) return false;
  if (c.discard) return false;
  if (c.sac && G.bf.filter(id => G.objs[id].ctrl === p && matches(G, G.objs[id], c.sac, p, o.id)).length < (c.sacN || 1)) return false;
  if (c.loyalty !== undefined) {
    if (o.pwUsed || !sorceryOk(G, p)) return false;
    if (typeof c.loyalty === 'number' && c.loyalty < 0 && o.c.loyalty < -c.loyalty) return false;
  }
  if (c.mana && !planPayment(G, p, c.mana, { exclude: c.tap ? o.id : null }, H)) return false;
  return true;
}

export function legalActions(G, p) {
  const P = G.players[p];
  const acts = [];
  if (G.over) return acts;
  const sorc = sorceryOk(G, p);
  const seenNames = new Set();
  if (sorc && P.landsPlayed < 1) {
    for (const id of P.hand) { const o = G.objs[id]; if (isLand(o) && !seenNames.has('L' + o.key)) { seenNames.add('L' + o.key); acts.push({ t: 'land', id }); } }
  }
  for (const id of [...P.hand, ...P.command]) {
    const o = G.objs[id]; const d = defOf(o);
    if (!d || isLand(o)) continue;
    const fast = d.types.includes('instant') || d.kw.flash;
    if (!fast && !sorc) continue;
    if (!castable(G, p, o)) continue;
    acts.push({ t: 'cast', id });
  }
  for (const id of G.bf) {
    const o = G.objs[id];
    if (o.ctrl !== p) continue;
    defOf(o).abilities.forEach((ab, ai) => {
      if (ab.isMana) return;
      if (ab.sorcery && !sorc) return;
      if (ab.once && o.used[ai]) return;
      if (!abilityCostOk(G, p, o, ab)) return;
      if (!specsOk(G, p, ab.targets || [], o.id)) return;
      acts.push({ t: 'act', id, ai });
    });
  }
  return acts;
}

function castable(G, p, o) {
  const d = defOf(o);
  if (d.spell?.modes) {
    if (!d.spell.modes.some(m => specsOk(G, p, m.targets, o.id))) return false;
  } else if (!specsOk(G, p, spellSpecs(d), o.id)) return false;
  return !!planPayment(G, p, d.cost, { extra: extraCost(G, p, o) }, H);
}

/** Cosa serve per completare un'azione: modalità, bersagli, X, sacrifici */
export function actionInfo(G, p, a) {
  const o = G.objs[a.id];
  const d = defOf(o);
  const info = { modes: null, specs: [], xMax: 0, sac: null, cost: '', label: '' };
  if (a.t === 'cast') {
    if (d.spell?.modes) {
      info.modes = d.spell.modes.map((m, i) => ({ i, text: m.textShown || m.text, ok: specsOk(G, p, m.targets, o.id),
        specs: m.targets.map(s => ({ spec: s, options: targetOptions(G, p, s, o.id) })) }));
    }
    info.specs = (spellSpecs(d) || []).map(s => ({ spec: s, options: targetOptions(G, p, s, o.id) }));
    if (d.cost.X) {
      const avail = totalMana(G, p, H) - (d.cost.generic + d.cost.pips.length + extraCost(G, p, o));
      info.xMax = Math.max(0, Math.floor(avail / d.cost.X));
      while (info.xMax > 0 && !planPayment(G, p, d.cost, { x: info.xMax, extra: extraCost(G, p, o) }, H)) info.xMax--;
    }
    info.cost = d.manaCost + (cmdTax(G, o) ? ` +${cmdTax(G, o)}` : '');
    info.label = 'Lancia';
  } else if (a.t === 'act') {
    const ab = d.abilities[a.ai];
    info.specs = (ab.targets || []).map(s => ({ spec: s, options: targetOptions(G, p, s, o.id) }));
    if (ab.cost.sac) info.sac = { n: ab.cost.sacN || 1, options: G.bf.filter(id => G.objs[id].ctrl === p && matches(G, G.objs[id], ab.cost.sac, p, o.id)) };
    if (ab.cost.loyalty === 'X') info.xMax = o.c.loyalty;
    if (ab.cost.mana?.X) {
      const avail = totalMana(G, p, H, ab.cost.tap ? o.id : null) - (ab.cost.mana.generic + ab.cost.mana.pips.length);
      info.xMax = Math.max(0, avail);
    }
    info.label = ab.equip ? 'Equipaggia' : 'Attiva';
    info.text = ab.text;
  } else if (a.t === 'land') info.label = 'Gioca terra';
  return info;
}

// ------------------------------------------------------------------------------------------------ pagamento
function payMana(G, p, cost, opt) {
  const plan = planPayment(G, p, cost, opt, H);
  if (!plan) return false;
  const P = G.players[p];
  for (const [c, n] of Object.entries(plan.fromPool)) P.pool[c] -= n;
  for (const u of plan.uses) {
    const s = G.objs[u.id];
    const ab = defOf(s).abilities[u.ai];
    if (ab.cost.tap) s.tapped = true;
    if (u.pain) { P.life -= u.pain; }
    if (ab.cost.sacSelf) moveTo(G, s.id, 'gy', { cause: 'sac' });
  }
  for (const c of plan.left || []) P.pool[c] = (P.pool[c] || 0) + 1;
  if (plan.life) P.life -= plan.life;
  return true;
}

function wardTax(G, p, targets) {
  let tax = 0;
  for (const list of targets || []) for (const r of list || []) {
    if (r.id === undefined) continue;
    const o = G.objs[r.id];
    if (o && o.zone === 'bf' && o.ctrl !== p) tax += defOf(o).ward || 0;
  }
  return tax;
}

function checkChosen(G, p, specs, chosen, srcId) {
  chosen = chosen || [];
  for (let i = 0; i < specs.length; i++) {
    const spec = specs[i];
    const list = chosen[i] || [];
    if (!spec.upTo && list.length < 1) return false;
    if (list.length > (spec.count || 1)) return false;
    const opts = targetOptions(G, p, spec, srcId);
    for (const r of list) if (!opts.some(x => sameRef(x, r))) return false;
  }
  return true;
}

/** Esegue un'azione completa: { t:'land'|'cast'|'act', id, ai?, mode?, x?, targets?: [[ref]], sac?: [id] } */
export function performAction(G, p, a) {
  const P = G.players[p];
  const o = G.objs[a.id];
  if (!o) return false;
  const d = defOf(o);
  if (a.t === 'land') {
    if (!legalActions(G, p).some(x => x.t === 'land' && G.objs[x.id].key === o.key) || !P.hand.includes(o.id)) return false;
    P.landsPlayed++;
    log(G, `${P.name} gioca ${cname(o)}.`, p);
    if (d.etb?.shock) { G.tasks.unshift({ t: 'shock', id: o.id, p }); return true; }
    enterBf(G, o.id, p);
    return true;
  }
  if (a.t === 'cast') {
    if (!legalActions(G, p).some(x => x.t === 'cast' && x.id === o.id)) return false;
    let effects, specs;
    if (d.spell?.modes) {
      const m = d.spell.modes[a.mode ?? 0];
      if (!m) return false;
      effects = m.effects; specs = m.targets;
    } else {
      effects = d.spell?.effects || [];
      specs = spellSpecs(d) || [];
    }
    if (!checkChosen(G, p, specs, a.targets, o.id)) return false;
    const x = Math.max(0, a.x | 0);
    const tax = extraCost(G, p, o);
    if (!payMana(G, p, d.cost, { x, extra: tax + wardTax(G, p, a.targets) })) return false;
    const fromCmd = o.zone === 'command';
    moveTo(G, o.id, 'stack');
    o.zone = 'stack'; o.ctrl = p;
    if (fromCmd) { P.command = P.command.filter(i => i !== o.id); P.cmdTax++; }
    const item = { sid: G.nextSid++, kind: 'spell', src: o.id, srcZcc: o.zcc, key: o.key, ctrl: p, effects, specs, targets: a.targets || [], x, name: cname(o), mode: a.mode };
    G.stack.push(item);
    log(G, `${P.name} lancia ${cname(o)}${x ? ` (X=${x})` : ''}${describeTargets(G, item)}.`, p);
    fire(G, 'cast', { obj: o, p });
    return true;
  }
  if (a.t === 'act') {
    const ab = d.abilities[a.ai];
    if (!ab || !legalActions(G, p).some(x => x.t === 'act' && x.id === o.id && x.ai === a.ai)) return false;
    const specs = ab.targets || [];
    if (!checkChosen(G, p, specs, a.targets, o.id)) return false;
    const c = ab.cost;
    let x = Math.max(0, a.x | 0);
    if (c.sac) {
      const need = c.sacN || 1;
      const chosen = (a.sac || []).filter(id => G.objs[id]?.zone === 'bf' && G.objs[id].ctrl === p && matches(G, G.objs[id], c.sac, p, o.id));
      if (chosen.length < need) return false;
      a.sac = chosen.slice(0, need);
    }
    if (c.mana && !payMana(G, p, c.mana, { x, exclude: c.tap ? o.id : null, extra: wardTax(G, p, a.targets) })) return false;
    if (c.tap) o.tapped = true;
    if (c.life) P.life -= c.life;
    if (c.loyalty !== undefined) {
      if (c.loyalty === 'X') { o.c.loyalty -= x; } else o.c.loyalty += c.loyalty;
      o.pwUsed = true;
    }
    if (ab.once) o.used[a.ai] = true;
    let lki = null;
    for (const sid of a.sac || []) { const r = moveTo(G, sid, 'gy', { cause: 'sac' }); if (sid === o.id) lki = r; }
    if (c.sacSelf) lki = moveTo(G, o.id, 'gy', { cause: 'sac' });
    const item = { sid: G.nextSid++, kind: 'ability', src: o.id, srcZcc: o.zcc, key: o.key, ctrl: p, effects: ab.effects, specs, targets: a.targets || [], x, name: cname(o), lki, text: ab.text };
    G.stack.push(item);
    log(G, `${P.name} attiva ${cname(o)}${describeTargets(G, item)}.`, p);
    return true;
  }
  return false;
}

export function refName(G, r) {
  if (r.p !== undefined) return G.players[r.p].name;
  if (r.sid !== undefined) { const s = G.stack.find(x => x.sid === r.sid); return s ? s.name : 'magia'; }
  const o = G.objs[r.id];
  return o ? cname(o) : '?';
}
function describeTargets(G, item) {
  const all = (item.targets || []).flat();
  if (!all.length) return '';
  return ' su ' + all.map(r => refName(G, r)).join(', ');
}

// ------------------------------------------------------------------------------------------------ esecuzione
const DONE = true, KEEP = false;

export function run(G, limit = 200000) {
  let n = 0;
  while (!G.over && !G.pending) {
    if (++n > limit) { G.over = { winner: null, reason: 'Partita interrotta (troppe azioni).' }; break; }
    if (!G.tasks.length) { nextStep(G); continue; }
    const t = G.tasks[0];
    const r = HANDLERS[t.t](G, t);
    if (r === DONE) { const i = G.tasks.indexOf(t); if (i >= 0) G.tasks.splice(i, 1); }
  }
  return G;
}

/** Risposta alla decisione in attesa (G.pending) */
export function respond(G, ans) {
  if (!G.pending) return G;
  const t = G.tasks[0];
  G.pending = null;
  t.ans = ans;
  return run(G);
}

function nextStep(G) {
  const i = STEPS.indexOf(G.step);
  let next = STEPS[i + 1];
  if (!next) { beginTurn(G, false); return; }
  if (G.skipCombat && ['attack', 'block', 'fsdamage', 'damage', 'ecombat'].includes(next)) { G.step = next; return; }
  G.tasks.push({ t: 'step', s: next });
}

function beginTurn(G, first) {
  for (const P of G.players) P.pool = emptyPool();
  if (!first) G.active = 1 - G.active;
  G.turn++;
  G.actions = 0;
  G.skipCombat = false;
  G.combat = null;
  const P = G.players[G.active];
  P.landsPlayed = 0;
  log(G, `— Turno ${G.turn}: ${P.name} —`);
  if (G.turn > 80) { G.over = { winner: null, reason: 'Pareggio: limite di turni raggiunto.' }; return; }
  G.step = 'untap';
  G.tasks.push({ t: 'step', s: 'untap' });
}

function canAttackAtAll(G, p) {
  return G.bf.some(id => attackerOk(G, G.objs[id], p));
}
function attackerOk(G, o, p) {
  if (o.ctrl !== p || !isCreature(G, o) || o.tapped) return false;
  const st = stats(G, o);
  if (st.kw.defender || st.kw.cantattack) return false;
  if (o.sick && !st.kw.haste) return false;
  return true;
}

function stepTask(s) { return { t: 'step', s }; }
const prio = G => ({ t: 'prio', passes: 0, p: G.active });

const HANDLERS = {
  firstTurn(G) { beginTurn(G, true); return DONE; },

  mull(G, t) {
    const P = G.players[t.p];
    const free = G.format === 'commander' ? 1 : 0;
    if (P.mulls >= 6) t.ans = { keep: true };
    if (!t.ans) { G.pending = { type: 'mulligan', player: t.p, bottom: Math.max(0, P.mulls - free), mulls: P.mulls }; return KEEP; }
    const a = t.ans; t.ans = null;
    if (a.keep) {
      const n = Math.max(0, P.mulls - free);
      if (n > 0) G.tasks.splice(G.tasks.indexOf(t) + 1, 0, { t: 'bottom', p: t.p, n });
      log(G, `${P.name} tiene ${P.hand.length - n} carte.`, t.p);
      return DONE;
    }
    P.mulls++;
    log(G, `${P.name} fa mulligan.`, t.p);
    for (const id of [...P.hand]) moveTo(G, id, 'library');
    shuffle(G, P.library);
    drawN(G, t.p, 7, true);
    return KEEP;
  },

  bottom(G, t) {
    const P = G.players[t.p];
    if (!t.ans) { G.pending = { type: 'choose', player: t.p, title: `Metti in fondo al grimorio ${t.n} cart${t.n === 1 ? 'a' : 'e'}`, cards: [...P.hand], min: t.n, max: t.n, purpose: 'bottom' }; return KEEP; }
    for (const id of t.ans.ids.slice(0, t.n)) moveTo(G, id, 'library', { bottom: true });
    return DONE;
  },

  shock(G, t) {
    const P = G.players[t.p];
    if (P.life <= 2) t.ans = { yes: false };
    if (!t.ans) { G.pending = { type: 'yesno', player: t.p, title: `Paghi 2 punti vita per far entrare ${cname(G.objs[t.id])} STAPPATA?`, card: G.objs[t.id].key, purpose: 'shock' }; return KEEP; }
    if (t.ans.yes) { P.life -= 2; log(G, `${P.name} paga 2 punti vita.`, t.p); }
    enterBf(G, t.id, t.p, { shockPaid: t.ans.yes });
    return DONE;
  },

  step(G, t) {
    G.step = t.s;
    const A = G.players[G.active];
    const i = G.tasks.indexOf(t);
    const after = [];
    switch (t.s) {
      case 'untap':
        for (const id of G.bf) {
          const o = G.objs[id];
          if (o.ctrl !== G.active) continue;
          o.sick = false; o.used = {}; o.pwUsed = false;
          if (o.frost > 0) { o.frost--; continue; }
          if (stats(G, o).kw.nountap) continue;
          o.tapped = false;
        }
        break;
      case 'upkeep': fire(G, 'step', { on: 'upkeep' }); after.push(prio(G)); break;
      case 'draw':
        if (!(G.turn === 1)) drawN(G, G.active, 1);
        after.push(prio(G)); break;
      case 'main1': fire(G, 'step', { on: 'main1' }); after.push(prio(G)); break;
      case 'bcombat':
        if (!canAttackAtAll(G, G.active)) { G.skipCombat = true; break; }
        G.combat = { attackers: [], blocks: [], declared: false };
        fire(G, 'step', { on: 'combat' });
        after.push(prio(G)); break;
      case 'attack': after.push({ t: 'declareAtt' }, prio(G)); break;
      case 'block':
        if (!G.combat?.attackers.length) break;
        after.push({ t: 'declareBlk' }, prio(G)); break;
      case 'fsdamage':
        if (!G.combat?.attackers.length) break;
        if (!combatHasFirstStrike(G)) break;
        after.push({ t: 'combatDmg', first: true }, prio(G)); break;
      case 'damage':
        if (!G.combat?.attackers.length) break;
        after.push({ t: 'combatDmg', first: false }, prio(G)); break;
      case 'ecombat': G.combat = null; break;
      case 'main2': after.push(prio(G)); break;
      case 'end': fire(G, 'step', { on: 'endstep' }); after.push(prio(G)); break;
      case 'cleanup': after.push({ t: 'cleanup' }); break;
    }
    after.push({ t: 'endOfStep' });
    G.tasks.splice(i, 1, ...after);
    void A;
    return KEEP;
  },

  endOfStep(G) {
    for (const P of G.players) P.pool = emptyPool();
    return DONE;
  },

  cleanup(G, t) {
    const P = G.players[G.active];
    const noMax = G.bf.some(id => G.objs[id].ctrl === G.active && defOf(G.objs[id]).statics.some(s => s.kind === 'nomax'));
    const extra = noMax ? 0 : P.hand.length - 7;
    if (extra > 0) {
      if (!t.ans) { G.pending = { type: 'choose', player: G.active, title: `Scarta ${extra} cart${extra === 1 ? 'a' : 'e'} (massimo 7 in mano)`, cards: [...P.hand], min: extra, max: extra, purpose: 'discard' }; return KEEP; }
      for (const id of t.ans.ids.slice(0, extra)) { moveTo(G, id, 'gy'); log(G, `${P.name} scarta ${cname(G.objs[id])}.`, G.active); }
      t.ans = null;
    }
    for (const id of G.bf) { const o = G.objs[id]; o.dmg = 0; o.dt = false; o.temp = []; }
    return DONE;
  },

  prio(G, t) {
    sba(G);
    if (G.over) return DONE;
    if (G.trig.length) { G.tasks.unshift({ t: 'putTrig' }); return KEEP; }
    if (t.ans === undefined || t.ans === null) {
      const acts = legalActions(G, t.p);
      if (autoPass(G, t.p, acts)) t.ans = { pass: true };
      else { G.pending = { type: 'priority', player: t.p, actions: acts }; return KEEP; }
    }
    const ans = t.ans; t.ans = null;
    if (!ans.pass && ++G.actions > 300) ans.pass = true;
    if (ans.pass) {
      t.passes++;
      if (t.passes >= 2) {
        if (!G.stack.length) return DONE;
        G.tasks.splice(G.tasks.indexOf(t), 1, { t: 'resolve' }, prio(G));
        return KEEP;
      }
      t.p = 1 - t.p;
      return KEEP;
    }
    const ok = performAction(G, t.p, ans);
    if (!ok) { if (G.players[t.p].bot) { t.passes++; t.p = 1 - t.p; } return KEEP; }
    t.passes = 0;
    return KEEP;
  },

  putTrig(G, t) {
    if (!t.queue) {
      const a = G.trig.filter(x => x.ctrl === G.active), b = G.trig.filter(x => x.ctrl !== G.active);
      t.queue = [...a, ...b];
      G.trig = [];
    }
    while (t.queue.length) {
      const tr = t.queue[0];
      const specs = tr.ab.targets || [];
      let targets = [];
      if (specs.length) {
        if (!t.ans) {
          const opts = specs.map(s => targetOptions(G, tr.ctrl, s, tr.src));
          if (specs.some((s, i) => !s.upTo && !opts[i].length)) { t.queue.shift(); continue; }
          // un solo bersaglio possibile: scelta automatica
          if (opts.every((o, i) => o.length === 1 && !specs[i].upTo && (specs[i].count || 1) === 1)) targets = opts.map(o => [o[0]]);
          else {
            G.pending = { type: 'targets', player: tr.ctrl, title: `${tr.name}: scegli i bersagli`, text: tr.ab.text, card: tr.key, src: tr.src,
              specs: specs.map((s, i) => ({ spec: s, options: opts[i] })) };
            return KEEP;
          }
        } else {
          targets = t.ans.targets || []; t.ans = null;
          if (!checkChosen(G, tr.ctrl, specs, targets, tr.src)) {
            // scelta non valida: si prende la prima disponibile
            targets = specs.map(s => { const o = targetOptions(G, tr.ctrl, s, tr.src); return o.length && !s.upTo ? [o[0]] : []; });
          }
        }
      }
      G.stack.push({ sid: G.nextSid++, kind: 'ability', src: tr.src, srcZcc: tr.srcZcc, key: tr.key, ctrl: tr.ctrl, effects: tr.ab.effects,
        specs, targets, x: 0, name: tr.name, lki: tr.lki, trigObj: tr.trigObj, trigZcc: tr.trigZcc, trigPlayer: tr.trigPlayer, text: tr.ab.text, trig: true });
      log(G, `Si innesca ${tr.name}${describeTargets(G, { targets })}.`, tr.ctrl);
      t.queue.shift();
    }
    return DONE;
  },

  resolve(G, t) {
    const it = G.stack.pop();
    if (!it) return DONE;
    const i = G.tasks.indexOf(t);
    // controllo dei bersagli
    const valid = (it.targets || []).map((list, k) => (list || []).filter(r => targetStillLegal(G, it, it.specs[k], r)));
    const hadTargets = (it.targets || []).some(l => l && l.length);
    const allGone = hadTargets && valid.every(l => !l.length);
    const src = G.objs[it.src];
    if (allGone) {
      log(G, `${it.name} non ha più bersagli validi e non ha effetto.`, it.ctrl);
      if (it.kind === 'spell' && src.zone === 'stack') moveTo(G, it.src, 'gy');
      return DONE;
    }
    if (it.kind === 'spell' && isPermanentCard(src)) {
      if (src.zone !== 'stack') return DONE;
      const d = defOf(src);
      if (d.auraTarget) {
        const tgt = valid[0]?.[0];
        if (!tgt) { moveTo(G, src.id, 'gy'); return DONE; }
        enterBf(G, src.id, it.ctrl, { attachTo: tgt.id });
      } else enterBf(G, src.id, it.ctrl);
      log(G, `${cname(src)} entra sul campo di battaglia.`, it.ctrl);
      return DONE;
    }
    const ctx = { sid: it.sid, ctrl: it.ctrl, src: it.src, srcZcc: it.srcZcc, key: it.key, targets: valid, x: it.x, lki: it.lki,
      trigObj: it.trigObj, trigZcc: it.trigZcc, trigPlayer: it.trigPlayer, spell: it.kind === 'spell', name: it.name, lk: {}, last: 0 };
    const effs = it.effects.map(e => ({ t: 'eff', e, ctx }));
    G.tasks.splice(i, 1, ...effs, { t: 'finish', ctx });
    return KEEP;
  },

  finish(G, t) {
    const { ctx } = t;
    const o = G.objs[ctx.src];
    if (ctx.spell && o.zone === 'stack') moveTo(G, o.id, 'gy');
    return DONE;
  },

  eff(G, t) {
    const { e, ctx } = t;
    if (e.may && t.may === undefined) {
      const P = G.players[ctx.ctrl];
      if (!t.ans) { G.pending = { type: 'yesno', player: ctx.ctrl, title: `${ctx.name}: vuoi applicare l'effetto?`, text: describeEffect(G, e, ctx), card: ctx.key, purpose: 'may', effect: e.e }; return KEEP; }
      t.may = !!t.ans.yes; t.ans = null;
      void P;
      if (!t.may) return DONE;
    }
    const fn = EFFECTS[e.e];
    if (!fn) return DONE;
    return fn(G, t, e, ctx) === KEEP ? KEEP : DONE;
  },

  declareAtt(G, t) {
    const p = G.active;
    const opts = G.bf.filter(id => attackerOk(G, G.objs[id], p));
    if (!opts.length) { G.combat = { attackers: [], blocks: [], declared: true }; return DONE; }
    const pws = G.bf.filter(id => G.objs[id].ctrl !== p && isType(G.objs[id], 'planeswalker'));
    if (!t.ans) { G.pending = { type: 'attack', player: p, options: opts, targets: [{ p: 1 - p }, ...pws.map(id => ({ id }))] }; return KEEP; }
    const list = (t.ans.attacks || []).filter(a => opts.includes(a.id));
    G.combat = { attackers: [], blocks: [], declared: true };
    for (const a of list) {
      const o = G.objs[a.id];
      const tgt = a.tgt && a.tgt.id && pws.includes(a.tgt.id) ? { id: a.tgt.id } : { p: 1 - p };
      G.combat.attackers.push({ id: a.id, tgt, blocked: false });
      if (!stats(G, o).kw.vigilance) o.tapped = true;
    }
    if (list.length) {
      log(G, `${G.players[p].name} attacca con ${list.map(a => cname(G.objs[a.id])).join(', ')}.`, p);
      for (const a of G.combat.attackers) fire(G, 'attacks', { obj: G.objs[a.id] });
    }
    return DONE;
  },

  declareBlk(G, t) {
    const p = 1 - G.active;
    const C = G.combat;
    const options = blockOptions(G, p);
    if (!Object.keys(options).length) return DONE;
    if (!t.ans) { G.pending = { type: 'block', player: p, attackers: C.attackers.map(a => a.id), options }; return KEEP; }
    let blocks = (t.ans.blocks || []).filter(b => options[b.b] && options[b.b].includes(b.a));
    // un bloccante blocca una sola creatura
    const seen = new Set(); blocks = blocks.filter(b => !seen.has(b.b) && seen.add(b.b));
    // Minacciare: servono almeno due bloccanti
    for (const a of C.attackers) {
      const n = blocks.filter(b => b.a === a.id).length;
      if (n === 1 && stats(G, G.objs[a.id]).kw.menace) blocks = blocks.filter(b => b.a !== a.id);
    }
    C.blocks = blocks;
    for (const a of C.attackers) a.blocked = blocks.some(b => b.a === a.id);
    if (blocks.length) {
      log(G, `${G.players[p].name} blocca: ${blocks.map(b => `${cname(G.objs[b.b])} → ${cname(G.objs[b.a])}`).join(', ')}.`, p);
      for (const b of blocks) fire(G, 'blocks', { obj: G.objs[b.b] });
    } else log(G, `${G.players[p].name} non blocca.`, p);
    return DONE;
  },

  combatDmg(G, t) { combatDamage(G, t.first); return DONE; },
};

export function blockOptions(G, p) {
  const C = G.combat;
  const out = {};
  if (!C) return out;
  for (const id of G.bf) {
    const b = G.objs[id];
    if (b.ctrl !== p || !isCreature(G, b) || b.tapped) continue;
    const bs = stats(G, b);
    if (bs.kw.cantblock) continue;
    const can = [];
    for (const a of C.attackers) {
      const ao = G.objs[a.id];
      if (!ao || ao.zone !== 'bf') continue;
      const as = stats(G, ao);
      if (as.kw.unblockable) continue;
      if (as.kw.flying && !bs.kw.flying && !bs.kw.reach) continue;
      if (bs.kw.blockflyonly && !as.kw.flying) continue;
      const ev = Object.keys(as.kw).find(k => /^evade\d$/.test(k));
      if (ev && bs.p <= +ev.slice(5)) continue;
      can.push(a.id);
    }
    if (can.length) out[id] = can;
  }
  return out;
}

function combatHasFirstStrike(G) {
  const C = G.combat;
  const ids = [...C.attackers.map(a => a.id), ...C.blocks.map(b => b.b)];
  return ids.some(id => { const o = G.objs[id]; if (!o || o.zone !== 'bf') return false; const k = stats(G, o).kw; return k['first strike'] || k['double strike']; });
}

function dealsIn(G, o, first) {
  const k = stats(G, o).kw;
  const fs = k['first strike'], ds = k['double strike'];
  return first ? (fs || ds) : (!fs || ds);
}

/** Danno da combattimento (passo dell'attacco improvviso o normale) */
function combatDamage(G, first) {
  const C = G.combat;
  const hits = [];
  for (const a of C.attackers) {
    const o = G.objs[a.id];
    if (!o || o.zone !== 'bf' || !isCreature(G, o) || !dealsIn(G, o, first)) continue;
    const st = stats(G, o);
    let dmg = st.p;
    if (dmg <= 0) continue;
    const pwTarget = a.tgt.id !== undefined && G.objs[a.tgt.id]?.zone === 'bf' ? { id: a.tgt.id } : null;
    const defender = pwTarget || { p: a.tgt.p ?? 1 - G.active };
    if (!a.blocked) { hits.push({ src: o.id, to: defender, n: dmg }); continue; }
    const blockers = C.blocks.filter(b => b.a === a.id).map(b => G.objs[b.b]).filter(b => b && b.zone === 'bf');
    if (!blockers.length) { if (st.kw.trample) hits.push({ src: o.id, to: defender, n: dmg }); continue; }
    blockers.forEach((b, i) => {
      if (dmg <= 0) return;
      const bt = stats(G, b).t - b.dmg;
      const lethal = st.kw.deathtouch ? Math.min(1, Math.max(bt, 0)) || (bt > 0 ? 1 : 0) : Math.max(bt, 0);
      const last = i === blockers.length - 1;
      let n = last && !st.kw.trample ? dmg : Math.min(dmg, Math.max(lethal, 0));
      if (n <= 0 && last && !st.kw.trample) n = dmg;
      if (n > 0) { hits.push({ src: o.id, to: { id: b.id }, n }); dmg -= n; }
    });
    if (dmg > 0 && st.kw.trample) hits.push({ src: o.id, to: defender, n: dmg });
  }
  for (const bl of C.blocks) {
    const b = G.objs[bl.b], a = G.objs[bl.a];
    if (!b || b.zone !== 'bf' || !a || a.zone !== 'bf' || !dealsIn(G, b, first)) continue;
    const n = stats(G, b).p;
    if (n > 0) hits.push({ src: b.id, to: { id: a.id }, n });
  }
  for (const h of hits) dealDamage(G, h.src, h.to, h.n, true);
}

/** Infligge danno: a un giocatore ({p}) o a un permanente ({id}) */
export function dealDamage(G, srcId, to, n, combat = false, lkiSrc = null) {
  if (n <= 0) return;
  const src = G.objs[srcId];
  const srcOnBf = src && src.zone === 'bf';
  const kw = srcOnBf ? stats(G, src).kw : (lkiSrc?.kw || defOf(src)?.kw || {});
  const ctrl = srcOnBf ? src.ctrl : (lkiSrc?.ctrl ?? src?.ctrl ?? 0);
  if (to.p !== undefined) {
    const P = G.players[to.p];
    P.life -= n;
    if (combat && src?.cmd) P.cmdDmg[srcId] = (P.cmdDmg[srcId] || 0) + n;
    log(G, `${src ? cname(src) : 'Fonte'} infligge ${n} danni a ${P.name}.`, ctrl);
    if (combat && src) fire(G, 'cdp', { obj: src, p: to.p });
  } else {
    const o = G.objs[to.id];
    if (!o || o.zone !== 'bf') return;
    if (isType(o, 'planeswalker') && !isCreature(G, o)) o.c.loyalty -= n;
    else { o.dmg += n; if (kw.deathtouch) o.dt = true; }
    log(G, `${src ? cname(src) : 'Fonte'} infligge ${n} danni a ${cname(o)}.`, ctrl);
  }
  if (kw.lifelink) gainLife(G, ctrl, n);
}

// ------------------------------------------------------------------------------------------------ azioni di stato
export function sba(G) {
  let changed = true, any = false, guard = 0;
  while (changed && guard++ < 50) {
    changed = false;
    for (const P of G.players) {
      if (P.lost) continue;
      const cmd = Math.max(0, ...Object.values(P.cmdDmg));
      if (P.life <= 0 || P.drewEmpty || cmd >= 21) {
        P.lost = true;
        P.lostReason = P.life <= 0 ? 'punti vita a zero' : P.drewEmpty ? 'grimorio vuoto' : '21 danni da un comandante';
        changed = any = true;
      }
    }
    const lost = G.players.filter(P => P.lost);
    if (lost.length) {
      const winner = lost.length === 2 ? null : G.players.find(P => !P.lost).i;
      G.over = { winner, reason: lost.map(P => `${P.name}: ${P.lostReason}`).join('; ') };
      log(G, winner == null ? 'Pareggio.' : `${G.players[winner].name} vince la partita!`);
      return true;
    }
    for (const id of [...G.bf]) {
      const o = G.objs[id];
      if (o.zone !== 'bf') continue;
      const d = defOf(o);
      if (o.c.p1 && o.c.m1) { const k = Math.min(o.c.p1, o.c.m1); o.c.p1 -= k; o.c.m1 -= k; }
      if (isCreature(G, o)) {
        const st = stats(G, o);
        if (st.t <= 0) { log(G, `${cname(o)} muore.`, o.ctrl); moveTo(G, id, 'gy', { cause: 'dies' }); changed = any = true; continue; }
        if ((o.dmg >= st.t || (o.dt && o.dmg > 0)) && !st.kw.indestructible) { log(G, `${cname(o)} è distrutta.`, o.ctrl); moveTo(G, id, 'gy', { cause: 'dies' }); changed = any = true; continue; }
      }
      if (d.types.includes('planeswalker') && !isCreature(G, o) && o.c.loyalty <= 0) { log(G, `${cname(o)} non ha più fedeltà.`, o.ctrl); moveTo(G, id, 'gy'); changed = any = true; continue; }
      if (d.subtypes.includes('Aura')) {
        const t = o.att != null ? G.objs[o.att] : null;
        if (!t || t.zone !== 'bf' || (d.enchant && !matches(G, t, d.enchant, o.ctrl))) { moveTo(G, id, 'gy'); changed = any = true; continue; }
      }
      if (d.subtypes.includes('Equipment') && o.att != null) {
        const t = G.objs[o.att];
        if (!t || t.zone !== 'bf' || !isCreature(G, t) || t.ctrl !== o.ctrl) o.att = null;
      }
    }
    // regola delle leggende
    const seen = {};
    for (const id of G.bf) {
      const o = G.objs[id]; const d = defOf(o);
      if (!d.supertypes.includes('legendary')) continue;
      const k = o.ctrl + '|' + d.name;
      if (seen[k] != null) {
        const other = G.objs[seen[k]];
        const lose = other.ts < o.ts ? other : o;
        log(G, `Regola delle leggende: ${cname(lose)} va al cimitero.`, o.ctrl);
        moveTo(G, lose.id, 'gy');
        changed = any = true;
        break;
      }
      seen[k] = id;
    }
  }
  return any;
}

// ------------------------------------------------------------------------------------------------ passaggio automatico della priorità
function autoPass(G, p, acts) {
  if (!acts.length) return true;
  const P = G.players[p];
  if (P.bot) return false;
  if (G.stopAll) return false;
  const top = G.stack[G.stack.length - 1];
  if (top) return top.ctrl === p;
  const my = G.active === p;
  if (my && isMain(G)) return false;
  const fast = acts.filter(a => a.t !== 'land');
  if (!fast.length) return true;
  if (!my && (G.step === 'end' || (G.step === 'attack' && G.combat?.attackers.length) || (G.step === 'block' && G.combat?.attackers.length))) return false;
  if (my && G.step === 'block' && G.combat?.attackers.length) return false;
  return true;
}

// ------------------------------------------------------------------------------------------------ effetti
function amount(G, ctx, n, e) {
  if (n === 'X' || n === '-X') {
    let v = ctx.x || 0;
    if (e && e.xExpr) v = countExpr(G, ctx, e.xExpr);
    return n === '-X' ? -v : v;
  }
  if (n === 'that') return ctx.lastAmount || 0;
  return n || 0;
}
function countExpr(G, ctx, x) {
  if (x.count) return G.bf.filter(id => matches(G, G.objs[id], x.count, ctx.ctrl, ctx.src)).length;
  if (x.selfPower) { const o = G.objs[ctx.src]; return o?.zone === 'bf' ? power(G, o) : (ctx.lki?.p || 0); }
  if (x.hand) return G.players[ctx.ctrl].hand.length;
  if (x.gy) return G.players[ctx.ctrl].gy.filter(id => matches(G, G.objs[id], { ...x.gy, ctrl: null }, ctx.ctrl)).length;
  return 0;
}

/** Riferimento -> lista di {p} o {id} */
function resolveRef(G, ctx, r) {
  switch (r.r) {
    case 'self': return [{ id: ctx.src }];
    case 'you': return [{ p: ctx.ctrl }];
    case 'eachOpp': return [{ p: 1 - ctx.ctrl }];
    case 'eachPlayer': return [{ p: G.active }, { p: 1 - G.active }];
    case 'tgt': return (ctx.targets[r.i] || []).map(x => (x.p !== undefined ? { p: x.p } : x.sid !== undefined ? { sid: x.sid } : { id: x.id }));
    case 'ctrlOf': {
      return resolveRef(G, ctx, r.of).map(x => {
        if (x.p !== undefined) return x;
        const lk = ctx.lk[x.id];
        const o = G.objs[x.id];
        return { p: lk ? lk.ctrl : o.zone === 'bf' ? o.ctrl : o.owner };
      });
    }
    case 'trig': return ctx.trigObj ? [{ id: ctx.trigObj }] : [];
    case 'trigPlayer': return ctx.trigPlayer !== undefined ? [{ p: ctx.trigPlayer }] : [{ p: 1 - ctx.ctrl }];
    case 'attached': { const o = G.objs[ctx.src]; return o?.att ? [{ id: o.att }] : []; }
    case 'all': return G.bf.filter(id => matches(G, G.objs[id], r.filter, ctx.ctrl, ctx.src)).map(id => ({ id }));
    default: return [];
  }
}
const objsOf = (G, ctx, r) => resolveRef(G, ctx, r).filter(x => x.id !== undefined).map(x => G.objs[x.id]).filter(Boolean);
const bfObjsOf = (G, ctx, r) => objsOf(G, ctx, r).filter(o => o.zone === 'bf');
const playersOf = (G, ctx, r) => resolveRef(G, ctx, r).filter(x => x.p !== undefined).map(x => x.p);

function remember(G, ctx, o) {
  if (o.zone === 'bf') ctx.lk[o.id] = { p: power(G, o), ctrl: o.ctrl };
}

export function describeEffect(G, e, ctx) {
  const map = { draw: 'pescare', search: 'cercare nel grimorio', regrow: 'riprendere una carta dal cimitero', token: 'creare pedine', damage: 'infliggere danni',
    destroy: 'distruggere', exile: 'esiliare', counters: 'mettere segnalini', gain: 'guadagnare punti vita', discard: 'scartare', sacYou: 'sacrificare un permanente', pump: 'potenziare' };
  return map[e.e] ? `Effetto: ${map[e.e]}.` : '';
}

const EFFECTS = {
  damage(G, t, e, ctx) {
    const n = amount(G, ctx, e.n, e);
    ctx.lastAmount = n;
    let srcId = ctx.src;
    if (e.src.r !== 'self') { const s = objsOf(G, ctx, e.src)[0]; if (s) srcId = s.id; else if (e.src.r === 'tgt') return; }
    for (const r of e.to) for (const x of resolveRef(G, ctx, r)) {
      if (x.id !== undefined) { const o = G.objs[x.id]; if (!o || o.zone !== 'bf') continue; }
      dealDamage(G, srcId, x, n, false, srcId === ctx.src ? ctx.lki : null);
    }
  },
  bite(G, t, e, ctx) {
    const s = e.src.r === 'self' ? G.objs[ctx.src] : objsOf(G, ctx, e.src)[0];
    if (!s) return;
    const pw = s.zone === 'bf' ? power(G, s) : (s.id === ctx.src && ctx.lki ? ctx.lki.p : 0);
    if (pw <= 0) return;
    for (const x of resolveRef(G, ctx, e.to)) {
      if (x.id !== undefined && G.objs[x.id]?.zone !== 'bf') continue;
      dealDamage(G, s.id, x, pw, false, s.id === ctx.src ? ctx.lki : null);
    }
  },
  fight(G, t, e, ctx) {
    const a = bfObjsOf(G, ctx, e.a)[0], b = bfObjsOf(G, ctx, e.b)[0];
    if (!a || !b) return;
    const pa = power(G, a), pb = power(G, b);
    dealDamage(G, a.id, { id: b.id }, pa);
    dealDamage(G, b.id, { id: a.id }, pb);
  },
  draw(G, t, e, ctx) {
    const n = amount(G, ctx, e.n, e);
    for (const p of playersOf(G, ctx, e.who)) { drawN(G, p, n); log(G, `${G.players[p].name} pesca ${n} cart${n === 1 ? 'a' : 'e'}.`, p); }
  },
  discard(G, t, e, ctx) {
    if (!t.list) { t.list = playersOf(G, ctx, e.who); t.k = 0; }
    while (t.k < t.list.length) {
      const p = t.list[t.k];
      const P = G.players[p];
      const n = Math.min(amount(G, ctx, e.n, e), P.hand.length);
      if (n <= 0) { t.k++; continue; }
      let ids;
      if (e.random) { ids = []; const h = [...P.hand]; for (let i = 0; i < n; i++) ids.push(h.splice(Math.floor(rnd(G) * h.length), 1)[0]); }
      else if (n >= P.hand.length) ids = [...P.hand];
      else {
        if (!t.ans) { G.pending = { type: 'choose', player: p, title: `Scarta ${n} cart${n === 1 ? 'a' : 'e'}`, cards: [...P.hand], min: n, max: n, purpose: 'discard' }; return KEEP; }
        ids = t.ans.ids.filter(id => P.hand.includes(id)).slice(0, n);
        while (ids.length < n) ids.push(P.hand.find(x => !ids.includes(x)));
        t.ans = null;
      }
      for (const id of ids) { moveTo(G, id, 'gy'); log(G, `${P.name} scarta ${cname(G.objs[id])}.`, p); }
      t.k++;
    }
  },
  mill(G, t, e, ctx) {
    const n = amount(G, ctx, e.n, e);
    for (const p of playersOf(G, ctx, e.who)) { const P = G.players[p]; for (let i = 0; i < n && P.library.length; i++) moveTo(G, P.library[0], 'gy'); log(G, `${P.name} macina ${n} carte.`, p); }
  },
  scry(G, t, e, ctx) { return lookTop(G, t, e, ctx, 'scry'); },
  surveil(G, t, e, ctx) { return lookTop(G, t, e, ctx, 'surveil'); },
  gain(G, t, e, ctx) { const n = amount(G, ctx, e.n, e); for (const p of playersOf(G, ctx, e.who)) { gainLife(G, p, n); log(G, `${G.players[p].name} guadagna ${n} punti vita.`, p); } },
  lose(G, t, e, ctx) { const n = amount(G, ctx, e.n, e); for (const p of playersOf(G, ctx, e.who)) { G.players[p].life -= n; log(G, `${G.players[p].name} perde ${n} punti vita.`, p); } },
  gainPow(G, t, e, ctx) {
    for (const x of resolveRef(G, ctx, e.of)) {
      if (x.id === undefined) continue;
      const lk = ctx.lk[x.id]; const o = G.objs[x.id];
      const pw = lk ? lk.p : (o.zone === 'bf' ? power(G, o) : 0);
      const who = e.you ? ctx.ctrl : (lk ? lk.ctrl : o.ctrl);
      if (pw > 0) { gainLife(G, who, pw); log(G, `${G.players[who].name} guadagna ${pw} punti vita.`, who); }
    }
  },
  pathRamp(G, t, e, ctx) {
    for (const x of resolveRef(G, ctx, e.of)) {
      if (x.id === undefined) continue;
      const lk = ctx.lk[x.id];
      const p = lk ? lk.ctrl : G.objs[x.id].owner;
      const P = G.players[p];
      const land = P.library.find(id => { const d = defOf(G.objs[id]); return d.supertypes.includes('basic') && d.types.includes('land'); });
      if (land) { enterBf(G, land, p, { tapped: true }); shuffle(G, P.library); log(G, `${P.name} cerca ${cname(G.objs[land])}.`, p); }
    }
  },
  destroy(G, t, e, ctx) {
    for (const o of bfObjsOf(G, ctx, e.what)) {
      if (stats(G, o).kw.indestructible) continue;
      remember(G, ctx, o);
      log(G, `${cname(o)} è distrutta.`, o.ctrl);
      moveTo(G, o.id, 'gy', { cause: 'dies' });
    }
  },
  exile(G, t, e, ctx) {
    const list = objsOf(G, ctx, e.what).filter(o => o.zone === 'bf' || o.zone === 'gy');
    const src = G.objs[ctx.src];
    for (const o of list) {
      remember(G, ctx, o);
      log(G, `${cname(o)} viene esiliata.`, o.ctrl);
      moveTo(G, o.id, 'exile');
      if (!ctx.spell && src && src.zone === 'bf' && o.zone === 'exile') {
        const L = (G.links[src.id] ||= { ids: [], zcc: {}, auto: !!e.until });
        L.ids.push(o.id); L.zcc[o.id] = o.zcc; if (e.until) L.auto = true;
      } else if (e.until && o.zone === 'exile') {
        // la fonte ha già lasciato il campo: la carta torna subito
        enterBf(G, o.id, o.owner);
      }
    }
  },
  returnLinked(G, t, e, ctx) {
    const L = G.links[ctx.src];
    if (!L) return;
    delete G.links[ctx.src];
    for (const id of L.ids) { const o = G.objs[id]; if (o && o.zone === 'exile' && o.zcc === L.zcc[id]) { enterBf(G, id, o.owner); log(G, `${cname(o)} ritorna sul campo.`, o.owner); } }
  },
  bounce(G, t, e, ctx) {
    for (const o of bfObjsOf(G, ctx, e.what)) { remember(G, ctx, o); log(G, `${cname(o)} torna in mano.`, o.owner); moveTo(G, o.id, 'hand'); }
  },
  tuck(G, t, e, ctx) {
    for (const o of bfObjsOf(G, ctx, e.what)) { remember(G, ctx, o); moveTo(G, o.id, 'library', { bottom: !e.top }); }
  },
  regrow(G, t, e, ctx) {
    for (const o of objsOf(G, ctx, e.what)) {
      if (o.zone !== 'gy') continue;
      if (e.to === 'hand') { moveTo(G, o.id, 'hand'); log(G, `${cname(o)} torna in mano.`, o.owner); }
      else { enterBf(G, o.id, ctx.ctrl, { tapped: e.tapped }); log(G, `${cname(o)} ritorna sul campo.`, ctx.ctrl); }
    }
  },
  pump(G, t, e, ctx) {
    const v = x => (typeof x === 'number' ? x : amount(G, ctx, x, e));
    for (const o of bfObjsOf(G, ctx, e.what)) o.temp.push({ p: v(e.p), t: v(e.t), kws: e.kws || [] });
  },
  counters(G, t, e, ctx) {
    const n = amount(G, ctx, e.n, e);
    for (const o of bfObjsOf(G, ctx, e.what)) {
      if (e.kind === 'p1') o.c.p1 += n; else if (e.kind === 'm1') o.c.m1 += n; else o.c.loyalty += n;
    }
  },
  tap(G, t, e, ctx) { for (const o of bfObjsOf(G, ctx, e.what)) o.tapped = true; },
  untap(G, t, e, ctx) { for (const o of bfObjsOf(G, ctx, e.what)) o.tapped = false; },
  frost(G, t, e, ctx) { for (const o of bfObjsOf(G, ctx, e.what)) o.frost = 1; },
  edict(G, t, e, ctx) {
    if (!t.list) { t.list = playersOf(G, ctx, e.who); t.k = 0; }
    while (t.k < t.list.length) {
      const p = t.list[t.k];
      const cands = G.bf.filter(id => G.objs[id].ctrl === p && matches(G, G.objs[id], e.filter, p));
      const n = Math.min(e.n || 1, cands.length);
      if (!n) { t.k++; continue; }
      let ids = cands;
      if (cands.length > n) {
        if (!t.ans) { G.pending = { type: 'choose', player: p, title: `Sacrifica ${n === 1 ? 'un permanente' : n + ' permanenti'}`, cards: cands, min: n, max: n, purpose: 'sacrifice' }; return KEEP; }
        ids = t.ans.ids.filter(id => cands.includes(id)).slice(0, n);
        if (ids.length < n) ids = cands.slice(0, n);
        t.ans = null;
      }
      for (const id of ids) { log(G, `${G.players[p].name} sacrifica ${cname(G.objs[id])}.`, p); moveTo(G, id, 'gy', { cause: 'dies' }); }
      t.k++;
    }
  },
  sacSelf(G, t, e, ctx) { const o = G.objs[ctx.src]; if (o && o.zone === 'bf' && o.zcc === ctx.srcZcc) moveTo(G, o.id, 'gy', { cause: 'dies' }); },
  sacYou(G, t, e, ctx) {
    const p = ctx.ctrl;
    const cands = G.bf.filter(id => G.objs[id].ctrl === p && matches(G, G.objs[id], e.filter, p, ctx.src));
    if (!cands.length) return;
    let id = cands[0];
    if (cands.length > 1) {
      if (!t.ans) { G.pending = { type: 'choose', player: p, title: 'Sacrifica un permanente', cards: cands, min: 1, max: 1, purpose: 'sacrifice' }; return KEEP; }
      id = cands.includes(t.ans.ids[0]) ? t.ans.ids[0] : cands[0];
      t.ans = null;
    }
    log(G, `${G.players[p].name} sacrifica ${cname(G.objs[id])}.`, p);
    moveTo(G, id, 'gy', { cause: 'dies' });
  },
  token(G, t, e, ctx) {
    const n = e.n === 'that' ? (ctx.lastAmount || 0) : amount(G, ctx, e.n, e);
    const desc = { ...e };
    if (desc.p === 'X') desc.p = amount(G, ctx, 'X', e);
    if (desc.t === 'X') desc.t = amount(G, ctx, 'X', e);
    delete desc.e; delete desc.n; delete desc.may; delete desc.xExpr; delete desc.tapped;
    const key = 'tok:' + JSON.stringify(desc);
    if (!DEFS.has(key)) { const d = tokenDef(desc); d.key = key; DEFS.set(key, d); }
    for (let i = 0; i < n; i++) {
      const o = newObj(G, key, ctx.ctrl, 'none');
      o.token = true;
      enterBf(G, o.id, ctx.ctrl, { tapped: e.tapped });
    }
    if (n > 0) log(G, `${G.players[ctx.ctrl].name} crea ${n} pedin${n === 1 ? 'a' : 'e'} ${DEFS.get(key).nameIt}.`, ctx.ctrl);
  },
  counter(G, t, e, ctx) {
    for (const x of resolveRef(G, ctx, e.what)) {
      if (x.sid === undefined) continue;
      const item = G.stack.find(s => s.sid === x.sid);
      if (!item) continue;
      if (e.unless) {
        const n = e.unless === 'X' ? ctx.x : e.unless;
        const canPay = !!planPayment(G, item.ctrl, { generic: n, X: 0, pips: [] }, {}, H);
        if (canPay) {
          if (!t.ans) { G.pending = { type: 'yesno', player: item.ctrl, title: `Paghi {${n}} per non far neutralizzare ${item.name}?`, card: item.key, purpose: 'payUnless', amount: n }; return KEEP; }
          const yes = t.ans.yes; t.ans = null;
          if (yes && payMana(G, item.ctrl, { generic: n, X: 0, pips: [] }, {})) { log(G, `${G.players[item.ctrl].name} paga ${n}.`, item.ctrl); continue; }
        }
      }
      G.stack.splice(G.stack.indexOf(item), 1);
      log(G, `${item.name} viene neutralizzata.`, ctx.ctrl);
      if (item.kind === 'spell') { const o = G.objs[item.src]; if (o.zone === 'stack') moveTo(G, o.id, 'gy'); }
    }
  },
  search(G, t, e, ctx) {
    const P = G.players[ctx.ctrl];
    const cands = P.library.filter(id => matches(G, G.objs[id], { ...e.filter, ctrl: null }, ctx.ctrl));
    let ids = [];
    if (cands.length) {
      if (!t.ans) {
        G.pending = { type: 'choose', player: ctx.ctrl, title: e.cultivate ? 'Cerca fino a 2 terre base (la prima va sul campo, la seconda in mano)' : `Cerca ${e.n === 1 ? 'una carta' : 'fino a ' + e.n + ' carte'} nel grimorio`,
          cards: cands, min: 0, max: e.n, purpose: 'search', dest: e.to, cultivate: !!e.cultivate };
        return KEEP;
      }
      ids = (t.ans.ids || []).filter(id => cands.includes(id)).slice(0, e.n);
      t.ans = null;
    }
    ids.forEach((id, i) => {
      const o = G.objs[id];
      if (e.cultivate) { if (i === 0) enterBf(G, id, ctx.ctrl, { tapped: true }); else moveTo(G, id, 'hand'); }
      else if (e.to === 'bf') enterBf(G, id, ctx.ctrl, { tapped: e.tapped });
      else moveTo(G, id, 'hand');
      log(G, `${P.name} cerca ${e.to === 'hand' && !e.cultivate ? 'una carta' : cname(o)}.`, ctx.ctrl);
    });
    shuffle(G, P.library);
  },
  mana(G, t, e, ctx) {
    const P = G.players[ctx.ctrl];
    const b = e.bundles[0];
    for (let sym of b) {
      if (sym === '*' || /^\*\d$/.test(sym) || sym === 'ID') {
        const want = neededColor(G, ctx.ctrl, sym === 'ID' ? commanderIdentity(G, ctx.ctrl) : COLOR_ORDER);
        const k = /^\*\d$/.test(sym) ? +sym[1] : 1;
        P.pool[want] = (P.pool[want] || 0) + k;
      } else P.pool[sym] = (P.pool[sym] || 0) + 1;
    }
  },
  attach(G, t, e, ctx) {
    const src = G.objs[ctx.src];
    const tgt = bfObjsOf(G, ctx, e.to)[0];
    if (!src || src.zone !== 'bf' || !tgt) return;
    src.att = tgt.id;
    log(G, `${cname(src)} viene assegnato a ${cname(tgt)}.`, ctx.ctrl);
  },
};

function neededColor(G, p, allowed) {
  const counts = {};
  for (const id of G.players[p].hand) for (const pip of defOf(G.objs[id]).cost.pips) for (const c of pip.any || [pip.c]) counts[c] = (counts[c] || 0) + 1;
  const list = allowed.length ? allowed : COLOR_ORDER;
  return [...list].sort((a, b) => (counts[b] || 0) - (counts[a] || 0))[0] || 'C';
}

function lookTop(G, t, e, ctx, kind) {
  const P = G.players[ctx.ctrl];
  const n = Math.min(amount(G, ctx, e.n, e), P.library.length);
  if (!n) return;
  const top = P.library.slice(0, n);
  if (!t.ans) {
    G.pending = { type: 'choose', player: ctx.ctrl, title: kind === 'scry' ? `Profetizza ${n}: scegli le carte da mettere IN FONDO` : `Sorveglia ${n}: scegli le carte da mettere nel CIMITERO`,
      cards: top, min: 0, max: n, purpose: kind };
    return KEEP;
  }
  const away = (t.ans.ids || []).filter(id => top.includes(id));
  t.ans = null;
  for (const id of away) {
    if (kind === 'scry') moveTo(G, id, 'library', { bottom: true });
    else moveTo(G, id, 'gy');
  }
  log(G, `${P.name} ${kind === 'scry' ? 'profetizza' : 'sorveglia'} ${n}.`, ctx.ctrl);
}

// ------------------------------------------------------------------------------------------------ informazioni per interfaccia e bot
export function availableMana(G, p) { return totalMana(G, p, H); }
export function colorsAvailable(G, p) { return producibleColors(G, p, H); }
export function canPay(G, p, cost, opt = {}) { return !!planPayment(G, p, cost, opt, H); }
export function attackersFor(G, p) { return G.bf.filter(id => attackerOk(G, G.objs[id], p)); }
export { cmdTax, spellSpecs, checkChosen, sameRef };
/** Solo per i test: crea una carta in una zona */
export function addCard(G, name, p, zone = 'hand') {
  const o = newObj(G, DEFS.get(name).name, p, zone);
  if (zone === 'bf') { o.zone = 'none'; enterBf(G, o.id, p); o.sick = false; G.trig = []; }
  else if (zone !== 'command') G.players[p][zone === 'library' ? 'library' : zone].push(o.id);
  return o;
}
/** Dopo aver ricaricato una partita salvata: ricrea le definizioni delle pedine */
export function restoreTokens(G) {
  for (const o of Object.values(G.objs)) {
    if (o.key.startsWith('tok:') && !DEFS.has(o.key)) { const d = tokenDef(JSON.parse(o.key.slice(4))); d.key = o.key; DEFS.set(o.key, d); }
  }
}
