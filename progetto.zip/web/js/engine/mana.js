// Pagamento automatico dei costi di mana: sceglie quali terre e fonti tappare.

/** Fonti di mana di un giocatore: una voce per permanente, con le alternative che può produrre */
export function manaSources(G, p, exclude = null, helpers) {
  const { defOf, isCreature, commanderIdentity } = helpers;
  const out = [];
  for (const id of G.bf) {
    const o = G.objs[id];
    if (o.ctrl !== p || id === exclude) continue;
    const d = defOf(o);
    const opts = [];
    d.abilities.forEach((ab, ai) => {
      if (!ab.isMana) return;
      const c = ab.cost;
      if (c.mana && (c.mana.generic || c.mana.pips.length)) return; // filtri: non usati in automatico
      if (c.sac || c.discard) return;
      if (c.tap && (o.tapped || (isCreature(G, o) && o.sick && !hasHaste(G, o, helpers)))) return;
      const pain = ab.effects.filter(e => e.e === 'damage' || e.e === 'lose').reduce((s, e) => s + (e.n || 1), 0) + (c.life || 0);
      for (const eff of ab.effects) {
        if (eff.e !== 'mana') continue;
        for (const b of eff.bundles) {
          let bundle = b;
          if (b.length === 1 && b[0] === 'ID') {
            const idn = commanderIdentity(G, p);
            if (!idn.length) continue;
            for (const c2 of idn) opts.push({ ai, bundle: [c2], pain, sac: !!c.sacSelf });
            continue;
          }
          if (b.length === 1 && /^\*\d$/.test(b[0])) bundle = Array(+b[0][1]).fill('*1');
          opts.push({ ai, bundle, pain, sac: !!c.sacSelf, tap: !!c.tap });
        }
      }
    });
    if (opts.length) out.push({ id, opts });
  }
  return out;
}
function hasHaste(G, o, helpers) { return helpers.hasKw(G, o, 'haste'); }

const fits = (sym, pip) => {
  if (sym === '*') return pip !== 'C';
  if (sym === '*1') return pip !== 'C';
  return sym === pip;
};

/**
 * Prepara il pagamento di un costo. Restituisce { uses:[{id, ai, bundle, color}], fromPool:{}, life } oppure null.
 * cost = { generic, X, pips }, x = valore di X, extra = mana generico in più (tasse).
 */
export function planPayment(G, p, cost, { x = 0, extra = 0, exclude = null } = {}, helpers) {
  const P = G.players[p];
  const pool = { ...P.pool };
  const fromPool = { W: 0, U: 0, B: 0, R: 0, G: 0, C: 0 };
  let generic = Math.max(0, cost.generic + x * cost.X + extra);
  const pips = [];
  let life = 0;
  for (const pip of cost.pips) {
    if (pip.or2) { pips.push({ c: pip.c, or2: true }); continue; }
    pips.push(pip.any ? { any: pip.any } : { c: pip.c, phy: pip.phy });
  }
  // 1) mana già nella riserva
  const rest = [];
  for (const pip of pips) {
    const opts = pip.any || [pip.c];
    const k = opts.find(c => pool[c] > 0);
    if (k) { pool[k]--; fromPool[k]++; } else rest.push(pip);
  }
  // 2) fonti
  const sources = manaSources(G, p, exclude, helpers);
  const flex = s => new Set(s.opts.flatMap(o => o.bundle)).size + (s.opts.some(o => o.bundle.includes('*')) ? 5 : 0);
  sources.sort((a, b) => flex(a) - flex(b) || (a.opts[0].sac - b.opts[0].sac));
  const used = new Set();
  const uses = [];
  const temp = [];
  const candFor = pip => sources.filter(s => !used.has(s.id) && s.opts.some(o => o.bundle.some(sym => (pip.any || [pip.c]).some(c => fits(sym, c)))));
  rest.sort((a, b) => candFor(a).length - candFor(b).length);

  function assign(i) {
    if (i >= rest.length) return true;
    const pip = rest[i];
    const want = pip.any || [pip.c];
    // mana avanzato da fonti che producono più di un mana
    const ti = temp.findIndex(sym => want.some(c => fits(sym, c)));
    if (ti >= 0) {
      const sym = temp.splice(ti, 1)[0];
      if (assign(i + 1)) return true;
      temp.splice(ti, 0, sym);
    }
    for (const s of sources) {
      if (used.has(s.id)) continue;
      const opts = [...s.opts].sort((a, b) => a.pain - b.pain);
      for (const o of opts) {
        const si = o.bundle.findIndex(sym => want.some(c => fits(sym, c)));
        if (si < 0) continue;
        used.add(s.id);
        const extraSyms = o.bundle.filter((_, j) => j !== si);
        temp.push(...extraSyms);
        const color = o.bundle[si].startsWith('*') ? want.find(c => c !== 'C') : o.bundle[si];
        uses.push({ id: s.id, ai: o.ai, bundle: o.bundle, color, pain: o.pain, sac: o.sac });
        if (assign(i + 1)) return true;
        uses.pop();
        temp.splice(temp.length - extraSyms.length, extraSyms.length);
        used.delete(s.id);
      }
    }
    // mana phyrexiano: si paga con 2 punti vita
    if (pip.phy && P.life - life > 2) { life += 2; if (assign(i + 1)) return true; life -= 2; }
    if (pip.or2) { generic += 2; if (assign(i + 1)) return true; generic -= 2; }
    return false;
  }
  if (!assign(0)) return null;
  // 3) generico: prima la riserva e gli avanzi, poi le fonti meno utili
  for (const c of Object.keys(pool)) { while (generic > 0 && pool[c] > 0) { pool[c]--; fromPool[c]++; generic--; } }
  while (generic > 0 && temp.length) { temp.pop(); generic--; }
  const spare = [...temp];
  if (generic > 0) {
    const free = sources.filter(s => !used.has(s.id)).map(s => {
      const best = [...s.opts].sort((a, b) => (a.pain - b.pain) || (b.bundle.length - a.bundle.length) || (a.bundle.includes('C') ? -1 : 1))[0];
      return { s, o: best };
    });
    // si tengono per ultime le fonti più flessibili e quelle che si sacrificano
    free.sort((a, b) => (a.o.sac - b.o.sac) || (a.o.pain - b.o.pain) || (flex(a.s) - flex(b.s)) || (b.o.bundle.length - a.o.bundle.length));
    for (const { s, o } of free) {
      if (generic <= 0) break;
      uses.push({ id: s.id, ai: o.ai, bundle: o.bundle, color: o.bundle[0].startsWith('*') ? 'C' : o.bundle[0], pain: o.pain, sac: o.sac });
      generic -= o.bundle.length;
    }
    if (generic > 0) return null;
  }
  // mana prodotto in più (es. Sol Ring per un costo di 1): resta nella riserva
  const left = spare.map(sym => (sym.startsWith('*') ? 'C' : sym));
  for (let i = 0; i < -generic; i++) {
    const last = uses[uses.length - 1];
    left.push(last && !last.bundle[0].startsWith('*') ? last.bundle[0] : 'C');
  }
  return { uses, fromPool, life, left };
}

/** Quanto mana potrebbe produrre in totale (per la scelta di X) */
export function totalMana(G, p, helpers, exclude = null) {
  const pool = Object.values(G.players[p].pool).reduce((a, b) => a + b, 0);
  return pool + manaSources(G, p, exclude, helpers).reduce((s, src) => s + Math.max(...src.opts.map(o => o.bundle.length)), 0);
}

/** Colori che potrebbe produrre */
export function producibleColors(G, p, helpers) {
  const set = new Set();
  for (const s of manaSources(G, p, null, helpers)) for (const o of s.opts) for (const c of o.bundle) {
    if (c.startsWith('*')) ['W', 'U', 'B', 'R', 'G'].forEach(x => set.add(x)); else set.add(c);
  }
  for (const [c, n] of Object.entries(G.players[p].pool)) if (n > 0) set.add(c);
  return set;
}
