// Lettura delle carte: dal testo oracle inglese (Scryfall) alle abilità che il motore sa eseguire.
// Ogni riga che non viene capita è segnalata come "non supportata": la carta resta giocabile con il resto.

export const COLORS = ['W', 'U', 'B', 'R', 'G'];
const NUMW = { a: 1, an: 1, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10, x: 'X' };
export function numOf(w) {
  if (w == null) return null;
  w = String(w).toLowerCase().trim();
  if (/^\d+$/.test(w)) return +w;
  return w in NUMW ? NUMW[w] : null;
}

export const KEYWORDS = ['flying', 'first strike', 'double strike', 'deathtouch', 'haste', 'hexproof', 'indestructible',
  'lifelink', 'menace', 'reach', 'trample', 'vigilance', 'defender', 'flash', 'prowess', 'shroud'];
export const KW_IT = {
  flying: 'Volare', 'first strike': 'Attacco improvviso', 'double strike': 'Doppio attacco', deathtouch: 'Tocco letale',
  haste: 'Rapidità', hexproof: 'Anti-malocchio', indestructible: 'Indistruttibile', lifelink: 'Legame vitale',
  menace: 'Minacciare', reach: 'Raggiungere', trample: 'Travolgere', vigilance: 'Cautela', defender: 'Difensore',
  flash: 'Lampo', prowess: 'Prodezza', shroud: 'Velo', unblockable: 'Non bloccabile', cantblock: 'Non può bloccare',
};
// parole chiave conosciute ma non simulate (la carta funziona senza)
const KW_KNOWN = /^(protection from .+|cycling|basic landcycling|.*cycling \{|kicker|multikicker|flashback|evoke|echo|persist|undying|suspend|cascade|convoke|delve|crew|mutate|madness|morph|megamorph|disguise|ninjutsu|landwalk|islandwalk|swampwalk|forestwalk|mountainwalk|plainswalk|fear|intimidate|shadow|horsemanship|exalted|wither|infect|toxic|afflict|annihilator|bushido|bloodthirst|battle cry|dash|emerge|escape|embalm|eternalize|entwine|exploit|extort|fabricate|fading|vanishing|flanking|graft|haunt|hideaway|improvise|jump-start|level up|living weapon|myriad|offspring|outlast|partner|companion|phasing|provoke|rampage|rebound|reconfigure|riot|scavenge|soulbond|spectacle|splice|split second|storm|sunburst|surge|training|transfigure|transmute|tribute|undaunted|unearth|unleash|affinity|amplify|aftermath|ascend|assist|aura swap|backup|bargain|blitz|boast|buyback|casualty|champion|changeling|cipher|cleave|conspire|craft|daybound|nightbound|decayed|demonstrate|devour|disturb|double team|encore|enlist|equip|foretell|for mirrodin!|forecast|freerunning|gift|harmonize|impending|incubate|ingest|investigate|job select|lifelink|max speed|miracle|mobilize|modular|more than meets the eye|plot|prototype|ravenous|read ahead|recover|reinforce|renown|replicate|retrace|ripple|saddle|skulk|solved|space sculptor|specialize|spree|squad|start your engines!|station|sunburst|totem armor|umbra armor|vigilance|ward|web-slinging|warp|tiered|exhaust)\b/;

const COLOR_WORD = { white: 'W', blue: 'U', black: 'B', red: 'R', green: 'G' };
const CARD_TYPES = ['creature', 'artifact', 'enchantment', 'land', 'planeswalker', 'instant', 'sorcery', 'battle', 'kindred', 'tribal'];
const SUPERTYPES = ['legendary', 'basic', 'snow', 'world'];
const SUBTYPES = new Set(('goblin elf zombie human soldier angel dragon vampire wizard warrior knight merfolk beast spirit elemental faerie ' +
  'sliver cat dog bird drake sphinx demon dinosaur pirate cleric rogue shaman druid giant insect spider wolf werewolf horror skeleton ' +
  'ally squirrel rat treefolk golem construct thopter servo artificer assassin warlock berserker monk ninja samurai snake fungus ' +
  'saproling hydra wurm ooze kor minotaur orc ogre troll hound elk bear horse fish kraken leviathan serpent octopus crab bat phoenix ' +
  'devil imp eldrazi phyrexian myr halfling dwarf gnome kithkin satyr centaur nymph god avatar illusion shapeshifter mutant noble ' +
  'peasant citizen scout archer mercenary rebel advisor pilot gorgon lizard salamander frog turtle ape monkey boar ox goat cyclops ' +
  'forest island swamp mountain plains gate equipment treasure food clue blood vehicle aura saga rabbit raccoon otter mouse ' +
  'elk zubera homunculus specter wraith shade nightmare hag witch mystic detective coward bringer hellion gargoyle juggernaut').split(' '));
const PLURAL = { elves: 'elf', dwarves: 'dwarf', wolves: 'wolf', werewolves: 'werewolf', mice: 'mouse', fungi: 'fungus',
  sphinxes: 'sphinx', foxes: 'fox', octopuses: 'octopus', allies: 'ally', faeries: 'faerie', zombies: 'zombie', pixies: 'pixie',
  thieves: 'thief', leeches: 'leech', switches: 'switch' };

function singular(w) {
  if (PLURAL[w]) return PLURAL[w];
  if (w.endsWith('ies') && !SUBTYPES.has(w)) return w.slice(0, -3) + 'y';
  if (w.endsWith('s') && !w.endsWith('ss') && !SUBTYPES.has(w)) return w.slice(0, -1);
  return w;
}

// ------------------------------------------------------------------------------------------------ costi
/** "{2}{R}{R}" -> { generic, X, pips:[{c:'R'} | {any:['R','G']} | {c:'B', phy:true}] } */
export function parseCost(str) {
  const c = { generic: 0, X: 0, pips: [] };
  for (const m of String(str || '').matchAll(/\{([^}]+)\}/g)) {
    const s = m[1].toUpperCase();
    if (/^\d+$/.test(s)) c.generic += +s;
    else if (s === 'X') c.X++;
    else if (s.length === 1 && 'WUBRGC'.includes(s)) c.pips.push({ c: s });
    else if (/^[WUBRG]\/P$/.test(s)) c.pips.push({ c: s[0], phy: true });
    else if (/^[WUBRG]\/[WUBRG]$/.test(s)) c.pips.push({ any: [s[0], s[2]] });
    else if (/^2\/[WUBRG]$/.test(s)) c.pips.push({ c: s[2], or2: true });
    else if (/^C\/[WUBRG]$/.test(s)) c.pips.push({ any: ['C', s[2]] });
    else if (s === 'S') c.generic++;
  }
  return c;
}
export function costMV(c) { return c.generic + c.pips.length; }

// ------------------------------------------------------------------------------------------------ filtri (es. "nonland permanent an opponent controls")
/** Descrive un insieme di permanenti o carte. Restituisce null se la frase non è capita. */
export function pfilter(src, def) {
  let s = ' ' + src.trim() + ' ';
  const f = { types: [], subtypes: [], non: [], nonsub: [], colors: [], noncolors: [], kws: [], nokws: [], ctrl: null };
  const take = (re, fn) => { const m = s.match(re); if (m) { s = s.replace(re, ' '); fn(m); } return !!m; };
  take(/ (?:that )?(?:you control|you own) $/, () => { f.ctrl = 'you'; });
  take(/ (?:an opponent controls|your opponents control|you don't control|target opponent controls|defending player controls) $/, () => { f.ctrl = 'opp'; });
  take(/ (?:that player|its controller) controls $/, () => { f.ctrl = 'that'; });
  take(/ with (mana value|power|toughness) (\d+) or (less|greater) $/, m => {
    const k = m[1] === 'mana value' ? 'mv' : m[1] === 'power' ? 'pow' : 'tou';
    f[k + (m[3] === 'less' ? 'Max' : 'Min')] = +m[2];
  });
  take(/ with (?:a )?(mana value|power|toughness) less than or equal to ~'s power $/, () => { f.powLeSelf = true; });
  take(/ without (flying|reach|defender|haste|trample|vigilance|deathtouch|lifelink) $/, m => f.nokws.push(m[1]));
  take(/ with (flying|reach|defender|haste|trample|vigilance|deathtouch|lifelink|first strike|menace) $/, m => f.kws.push(m[1]));
  take(/ (?:from|in) (your|a|an opponent's) graveyard $/, m => { f.zone = 'gy'; if (m[1] === 'your') f.ctrl = 'you'; else if (m[1] !== 'a') f.ctrl = 'opp'; });
  const words = s.trim().split(/\s+/).filter(Boolean);
  let nouns = 0;
  for (let w of words) {
    w = w.replace(/,$/, '');
    if (w === 'or' || w === 'and' || w === 'and/or' || w === '') continue;
    if (w === 'other' || w === 'another') { f.other = true; continue; }
    if (w === 'tapped') { f.tapped = true; continue; }
    if (w === 'untapped') { f.untapped = true; continue; }
    if (w === 'attacking') { f.attacking = true; continue; }
    if (w === 'blocking') { f.blocking = true; continue; }
    if (w === 'token' || w === 'tokens') { f.token = true; if (!f.types.length) f.types.push('creature'); nouns++; continue; }
    if (w === 'nontoken') { f.nontoken = true; continue; }
    if (w === 'colorless') { f.colorless = true; continue; }
    if (w === 'multicolored') { f.multicolor = true; continue; }
    if (COLOR_WORD[w]) { f.colors.push(COLOR_WORD[w]); continue; }
    let m = w.match(/^non-?(\w+)$/);
    if (m) {
      const t = singular(m[1]);
      if (COLOR_WORD[t]) f.noncolors.push(COLOR_WORD[t]);
      else if (CARD_TYPES.includes(t) || SUPERTYPES.includes(t)) f.non.push(t);
      else if (SUBTYPES.has(t)) f.nonsub.push(t);
      else return null;
      continue;
    }
    if (SUPERTYPES.includes(w)) { (f.supers ||= []).push(w); continue; }
    const t = singular(w);
    if (CARD_TYPES.includes(t)) { f.types.push(t === 'tribal' ? 'kindred' : t); nouns++; continue; }
    if (t === 'permanent') { f.permanent = true; nouns++; continue; }
    if (t === 'card') { f.card = true; nouns++; continue; }
    if (t === 'spell') { f.spell = true; nouns++; continue; }
    if (SUBTYPES.has(t) || (def && def.subtypes.map(x => x.toLowerCase()).includes(t))) { f.subtypes.push(t); nouns++; continue; }
    return null;
  }
  if (!nouns) return null;
  // "attacking or blocking creature": basta una delle due
  if (f.attacking && f.blocking) { f.combat = true; delete f.attacking; delete f.blocking; }
  return f;
}

/** Conta: "the number of Goblins you control" e simili */
function parseCount(s, def) {
  let m = s.match(/^the number of (.+?) (you control|on the battlefield)$/);
  if (m) { const f = pfilter(m[1], def); if (f) { if (m[2] === 'you control') f.ctrl = 'you'; return { count: f }; } }
  if (/^~'s power$/.test(s)) return { selfPower: true };
  if (/^the number of cards in your hand$/.test(s)) return { hand: true };
  m = s.match(/^the number of (\w+) cards? in your graveyard$/);
  if (m) { const f = pfilter(m[1] + ' card', def); if (f) return { gy: f }; }
  if (s === 'the number of cards in your graveyard') return { gy: { types: [], subtypes: [], non: [], nonsub: [], colors: [], noncolors: [], kws: [], nokws: [], card: true } };
  return null;
}

// ------------------------------------------------------------------------------------------------ riferimenti (bersagli, "it", "each opponent"...)
function parseKwList(s) {
  const out = [];
  for (let p of s.split(/,\s*(?:and\s+)?|\s+and\s+/)) {
    p = p.trim();
    if (!p) continue;
    if (KEYWORDS.includes(p)) out.push(p);
    else if (p === "can't be blocked" || p === 'cannot be blocked') out.push('unblockable');
    else if (/^protection from/.test(p)) out.push('hexproof');
    else if (/walk$/.test(p)) continue;
    else return null;
  }
  return out.length ? out : null;
}

function targetSpec(phrase, ctx) {
  let s = phrase.trim();
  let count = 1, upTo = false;
  let m = s.match(/^up to (one|two|three|four|five|\d+) (?:other )?target (.+)$/);
  if (m) { count = numOf(m[1]); upTo = true; s = (phrase.includes('other target') ? 'other ' : '') + 'target ' + m[2]; }
  m = s.match(/^(one|two|three|four|\d+) target (.+)$/);
  if (m) { count = numOf(m[1]); s = 'target ' + m[2]; }
  let other = false;
  m = s.match(/^(?:another|other) target (.+)$/);
  if (m) { other = true; s = 'target ' + m[1]; }
  if (s === 'any target' || s === 'any other target') return { kind: 'any', count, upTo, other };
  m = s.match(/^target (.+)$/);
  if (!m) return null;
  const rest = m[1];
  if (rest === 'player') return { kind: 'player', count, upTo };
  if (rest === 'opponent') return { kind: 'opp', count, upTo };
  if (rest === 'player or planeswalker' || rest === 'opponent or planeswalker') return { kind: 'playerpw', opp: rest.startsWith('opp'), count, upTo };
  if (rest === 'creature or player') return { kind: 'any', count, upTo, noPw: true };
  m = rest.match(/^(.*?)\s*spell$/);
  if (m) {
    if (!m[1]) return { kind: 'spell', filter: null, count, upTo };
    const f = pfilter(m[1].replace(/ or /g, ' or ') + ' spell', ctx.def);
    if (!f) return null;
    f.spell = false;
    return { kind: 'spell', filter: f, count, upTo };
  }
  const f = pfilter(rest, ctx.def);
  if (!f) return null;
  if (f.zone === 'gy' || (f.card && !f.permanent)) return { kind: 'card', filter: f, count, upTo };
  if (!f.types.length && !f.permanent && !f.subtypes.length) return null;
  return { kind: 'obj', filter: f, count, upTo, other };
}

/** Converte una frase in un riferimento a oggetti o giocatori */
function ref(phrase, ctx) {
  const s = phrase.trim().replace(/^the /, '');
  if (s === '~' || s === 'itself') return { r: 'self' };
  if (s === 'you' || s === 'yourself') return { r: 'you' };
  if (s === 'each opponent' || s === 'your opponents' || s === 'defending player' || s === 'the defending player') return { r: 'eachOpp' };
  if (s === 'each player') return { r: 'eachPlayer' };
  if (s === 'that player' || s === 'they' || s === 'that opponent' || s === 'its controller' || s === 'their controller' || s === "that creature's controller") {
    if (ctx.lastPlayer) return ctx.lastPlayer;
    if (ctx.last && ctx.last.r === 'tgt') return { r: 'ctrlOf', of: ctx.last };
    if (ctx.trigPlayer) return { r: 'trigPlayer' };
    return { r: 'eachOpp' };
  }
  if (s === 'it' || s === 'that creature' || s === 'that permanent' || s === 'that card' || s === 'them' || s === 'those creatures' || s === 'that token') {
    return ctx.last || { r: 'self' };
  }
  if (s === 'enchanted creature' || s === 'equipped creature' || s === 'enchanted permanent') return { r: 'attached' };
  if (s === "the player or planeswalker it's attacking") return { r: 'eachOpp' };
  let m = s.match(/^(?:each|all) (.+)$/);
  if (m) {
    if (m[1] === 'opponent') return { r: 'eachOpp' };
    if (m[1] === 'player') return { r: 'eachPlayer' };
    const f = pfilter(m[1], ctx.def);
    if (!f) return null;
    return { r: 'all', filter: f };
  }
  m = s.match(/^(.+) (you control|your opponents control|you don't control)$/);
  if (m && !/target/.test(m[1])) { const f = pfilter(m[1] + ' ' + m[2], ctx.def); if (f) return { r: 'all', filter: f }; }
  if (/target|any target/.test(s)) {
    const spec = targetSpec(s, ctx);
    if (!spec) return null;
    ctx.targets.push(spec);
    const r = { r: 'tgt', i: ctx.targets.length - 1 };
    if (['player', 'opp'].includes(spec.kind)) ctx.lastPlayer = r; else ctx.last = r;
    return r;
  }
  return null;
}

// ------------------------------------------------------------------------------------------------ effetti
const N = '(a|an|one|two|three|four|five|six|seven|eight|nine|ten|x|\\d+|that many)';

function tokenDesc(s, ctx) {
  // "two 1/1 white Soldier creature tokens with flying"
  let m = s.match(new RegExp('^' + N + ' (tapped )?(.+?) tokens?(?: with (.+))?$'));
  if (!m) return null;
  const n = m[1] === 'that many' ? 'that' : numOf(m[1]);
  const tapped = !!m[2];
  let body = m[3]; const withKw = m[4];
  const named = { treasure: 'Treasure', food: 'Food', clue: 'Clue', blood: 'Blood', map: 'Map' };
  if (named[body]) return { n, tapped, named: named[body] };
  m = body.match(/^(\d+|x)\/(\d+|x) (.+?) ((?:[a-z]+ )*?)(artifact creature|enchantment creature|creature)$/);
  if (!m) return null;
  const words = m[3].split(' ');
  const colors = []; const subs = [];
  for (const w of [...words, ...m[4].trim().split(' ').filter(Boolean)]) {
    if (COLOR_WORD[w]) colors.push(COLOR_WORD[w]);
    else if (w === 'colorless' || w === 'and') continue;
    else subs.push(w.charAt(0).toUpperCase() + w.slice(1));
  }
  let kws = [];
  if (withKw) { kws = parseKwList(withKw); if (!kws) return null; }
  return { n, tapped, p: m[1] === 'x' ? 'X' : +m[1], t: m[2] === 'x' ? 'X' : +m[2], colors, subtypes: subs, artifact: m[5].startsWith('artifact'), kws };
}

function manaBundles(s) {
  // "{r}{r}{r}", "{r} or {g}", "{w}, {u}, or {b}", "one mana of any color", ...
  if (s === 'one mana of any color') return [['*']];
  if (s === "one mana of any color in your commander's color identity") return [['ID']];
  let m = s.match(/^(two|three) mana of any one color$/);
  if (m) return [['*' + numOf(m[1])]];
  m = s.match(/^(two|three) mana in any combination of colors$/);
  if (m) return [Array(numOf(m[1])).fill('*')];
  if (/^(\{[wubrgc]\})+$/.test(s)) return [[...s.matchAll(/\{(\w)\}/g)].map(x => x[1].toUpperCase())];
  const parts = s.split(/,\s*(?:or\s+)?|\s+or\s+/).map(x => x.trim()).filter(Boolean);
  if (parts.length > 1 && parts.every(p => /^(\{[wubrgc]\})+$/.test(p))) return parts.map(p => [...p.matchAll(/\{(\w)\}/g)].map(x => x[1].toUpperCase()));
  return null;
}

/** Una frase -> lista di effetti, oppure null */
function sentence(s0, ctx) {
  let s = s0.trim().replace(/^then,? /, '').replace(/\.$/, '');
  if (!s) return [];
  if (/can't be regenerated/.test(s) || s === "~ can't be countered" || s === 'then shuffle' || s === 'shuffle') return [];
  let may = false;
  let m = s.match(/^you may (.+)$/);
  if (m && !/^you may pay/.test(s)) { may = true; s = m[1]; }
  // ", where X is ..."
  m = s.match(/^(.+), where x is (.+)$/);
  if (m) { const c = parseCount(m[2], ctx.def); if (!c) return null; ctx.xExpr = c; s = m[1]; }
  const fin = arr => { arr.forEach(e => { if (may) e.may = true; if (ctx.xExpr) e.xExpr = ctx.xExpr; }); ctx.xExpr = null; return arr; };
  const out = one(s, ctx);
  if (out) return fin(out);
  // frasi composte: "X and Y" (con soggetto ereditato)
  const parts = s.split(/,? and (?=(?:you |each opponent |target player |that player |draws? |loses? |gains? |discards? |create |put |deals? |exile |destroy |return |scry |mills? |tap |untap |sacrifices? |surveil ))/);
  if (parts.length < 2) return null;
  const res = [];
  const subj = (parts[0].match(/^(target player|target opponent|each opponent|each player|you|that player)\b/) || [])[1];
  for (let i = 0; i < parts.length; i++) {
    let p = parts[i];
    if (i > 0 && /^(draws?|loses?|gains?|discards?|mills?|sacrifices?) /.test(p) && subj) p = (subj.startsWith('target') ? 'that player' : subj) + ' ' + p;
    const r = one(p, ctx);
    if (!r) return null;
    res.push(...r);
  }
  return fin(res);
}

function one(s, ctx) {
  let m;
  const R = p => ref(p, ctx);
  const amount = w => (w === 'that much' ? 'that' : numOf(w));
  if ((m = s.match(/^have (.+?) deal (.+)$/))) return one(`${m[1]} deals ${m[2]}`, ctx);
  if ((m = s.match(/^have (.+?) get (.+)$/))) return one(`${m[1]} gets ${m[2]}`, ctx);
  if (/^search your library for a card, then shuffle and put that card on top$/.test(s)) return [{ e: 'search', n: 1, filter: pfilter('card'), to: 'top' }];

  // ---- danni
  if ((m = s.match(/^(.+?) deals? damage equal to (?:its|~'s|that creature's) power to (.+)$/))) {
    const src = R(m[1]); if (!src) return null;
    const to = R(m[2]); if (!to) return null;
    return [{ e: 'bite', src, to }];
  }
  if ((m = s.match(/^(.+?) deals? (\d+|x|that much) damage to (.+?)(?: and (\d+|x) damage to (.+))?$/))) {
    const src = R(m[1]); if (!src) return null;
    const tos = [];
    for (const p of m[3].split(/ and (?=each )/)) { const r = R(p); if (!r) return null; tos.push(r); }
    const out = [{ e: 'damage', src, n: amount(m[2]), to: tos }];
    if (m[4]) { const r = R(m[5]); if (!r) return null; out.push({ e: 'damage', src, n: amount(m[4]), to: [r] }); }
    return out;
  }
  // ---- carte
  if ((m = s.match(new RegExp('^(?:(you|target player|that player|each player|target opponent|each opponent) )?draws? ' + N + ' cards?$')))) {
    const who = m[1] ? R(m[1]) : { r: 'you' }; if (!who) return null;
    return [{ e: 'draw', who, n: amount(m[2]) }];
  }
  if ((m = s.match(new RegExp('^(?:(you|target player|that player|each player|target opponent|each opponent) )?discards? ' + N + ' cards?( at random)?$')))) {
    const who = m[1] ? R(m[1]) : { r: 'you' }; if (!who) return null;
    return [{ e: 'discard', who, n: amount(m[2]), random: !!m[3] }];
  }
  if ((m = s.match(/^draw (a|one|two|three) cards?, then discard (a|one|two|three) cards?$/))) return [{ e: 'draw', who: { r: 'you' }, n: numOf(m[1]) }, { e: 'discard', who: { r: 'you' }, n: numOf(m[2]) }];
  if ((m = s.match(new RegExp('^(?:(you|target player|that player|each player|target opponent|each opponent) )?mills? ' + N + ' cards?$')))) {
    const who = m[1] ? R(m[1]) : { r: 'you' }; if (!who) return null;
    return [{ e: 'mill', who, n: amount(m[2]) }];
  }
  if ((m = s.match(/^scry (\d+|x)$/))) return [{ e: 'scry', n: amount(m[1]) }];
  if ((m = s.match(/^surveil (\d+|x)$/))) return [{ e: 'surveil', n: amount(m[1]) }];
  // ---- punti vita
  if ((m = s.match(/^(?:(you|target player|that player|each player) )?gains? (\d+|x) life$/))) {
    const who = m[1] ? R(m[1]) : { r: 'you' }; if (!who) return null;
    return [{ e: 'gain', who, n: amount(m[2]) }];
  }
  if ((m = s.match(/^(you|target player|target opponent|that player|each opponent|each player|they|its controller|their controller) loses? (\d+|x) life$/))) {
    const who = R(m[1]); if (!who) return null;
    return [{ e: 'lose', who, n: amount(m[2]) }];
  }
  if (/^its controller gains life equal to its power$/.test(s)) return [{ e: 'gainPow', of: ctx.last || { r: 'self' } }];
  if (/^you gain life equal to (?:its|that creature's) power$/.test(s)) return [{ e: 'gainPow', of: ctx.last || { r: 'self' }, you: true }];
  if (/^its controller may search their library for a basic land card, put (?:it|that card) onto the battlefield tapped, then shuffle$/.test(s)) return [{ e: 'pathRamp', of: ctx.last }];
  // ---- rimozione
  if ((m = s.match(/^destroy (.+)$/))) { const r = R(m[1]); return r ? [{ e: 'destroy', what: r }] : null; }
  if ((m = s.match(/^exile (.+?)( until ~ leaves the battlefield)?$/))) { const r = R(m[1]); return r ? [{ e: 'exile', what: r, until: !!m[2] }] : null; }
  if (/^return the exiled cards? to the battlefield under (?:its|their) owner(?:'s|s'|s)? control$/.test(s)) return [{ e: 'returnLinked' }];
  if ((m = s.match(/^return (.+?) from (your|a) graveyard to (your hand|the battlefield)( tapped)?(?: under your control)?$/))) {
    if (!/target/.test(m[1])) return null;
    const r = R(m[1] + ' from ' + m[2] + ' graveyard');
    if (!r) return null;
    return [{ e: 'regrow', what: r, to: m[3] === 'your hand' ? 'hand' : 'bf', tapped: !!m[4] }];
  }
  if ((m = s.match(/^return (.+?) to (?:its|their) owner(?:'s|s'|s)? hands?$/))) { const r = R(m[1]); return r ? [{ e: 'bounce', what: r }] : null; }
  if ((m = s.match(/^put (.+?) on (?:the )?(top|bottom) of (?:its|their) owner(?:'s|s'|s)? library$/))) { const r = R(m[1]); return r ? [{ e: 'tuck', what: r, top: m[2] === 'top' }] : null; }
  // ---- modifiche
  if ((m = s.match(/^(.+?) gets? ([+-](?:\d+|x))\/([+-](?:\d+|x))(?: and gains? (.+?))? until end of turn$/))) {
    const r = R(m[1]); if (!r) return null;
    let kws = [];
    if (m[4]) { kws = parseKwList(m[4]); if (!kws) return null; }
    const v = x => (/x/.test(x) ? (x[0] === '-' ? '-X' : 'X') : +x);
    return [{ e: 'pump', what: r, p: v(m[2]), t: v(m[3]), kws }];
  }
  if ((m = s.match(/^(.+?) gains? (.+?) until end of turn$/))) {
    const r = R(m[1]); if (!r) return null;
    const kws = parseKwList(m[2]); if (!kws) return null;
    return [{ e: 'pump', what: r, p: 0, t: 0, kws }];
  }
  if ((m = s.match(/^(.+?) can't block this turn$/))) { const r = R(m[1]); return r ? [{ e: 'pump', what: r, p: 0, t: 0, kws: ['cantblock'] }] : null; }
  if ((m = s.match(/^(.+?) can't be blocked this turn$/))) { const r = R(m[1]); return r ? [{ e: 'pump', what: r, p: 0, t: 0, kws: ['unblockable'] }] : null; }
  if ((m = s.match(new RegExp('^put ' + N + ' ([+-]1)\\/([+-]1) counters? on (.+)$')))) {
    const r = R(m[4]); if (!r) return null;
    return [{ e: 'counters', what: r, n: amount(m[1]), kind: m[2] === '+1' ? 'p1' : 'm1' }];
  }
  if ((m = s.match(new RegExp('^put ' + N + ' loyalty counters? on (.+)$')))) { const r = R(m[2]); return r ? [{ e: 'counters', what: r, n: amount(m[1]), kind: 'loyalty' }] : null; }
  if ((m = s.match(/^(tap|untap) (.+)$/))) { const r = R(m[2]); return r ? [{ e: m[1], what: r }] : null; }
  if (/^(?:it|that creature|that permanent|they|those creatures|those permanents) (?:doesn't|don't) untap during (?:its|their) controller(?:'s|s'|s)? next untap step$/.test(s)) return [{ e: 'frost', what: ctx.last || { r: 'self' } }];
  if ((m = s.match(/^(.+?) fights (.+)$/))) { const a = R(m[1]); const b = a && R(m[2]); return b ? [{ e: 'fight', a, b }] : null; }
  if ((m = s.match(/^(each opponent|target opponent|target player|each player|that player) sacrifices (a|an|one|two) (.+?)(?: of their choice)?$/))) {
    const who = R(m[1]); const f = pfilter(m[3], ctx.def); if (!who || !f) return null;
    return [{ e: 'edict', who, n: numOf(m[2]), filter: f }];
  }
  if (/^sacrifice ~$/.test(s)) return [{ e: 'sacSelf' }];
  if ((m = s.match(/^sacrifice (a|an|another) (.+)$/))) { const f = pfilter((m[1] === 'another' ? 'other ' : '') + m[2], ctx.def); return f ? [{ e: 'sacYou', filter: f }] : null; }
  // ---- creazione
  if ((m = s.match(/^create (.+)$/))) {
    const d = tokenDesc(m[1], ctx); if (!d) return null;
    const out = [{ e: 'token', ...d }];
    return out;
  }
  if ((m = s.match(/^counter (target (?:.+? )?spell)(?: unless its controller pays (\{\d+\}|\{x\}|x|\d+))?$/))) {
    const r = R(m[1]); if (!r) return null;
    const pay = m[2] ? (/x/.test(m[2]) ? 'X' : +m[2].replace(/[{}]/g, '')) : 0;
    return [{ e: 'counter', what: r, unless: pay }];
  }
  // ---- ricerca nel grimorio
  if ((m = s.match(/^search your library for up to two basic land cards, reveal those cards, put one onto the battlefield tapped and the other into your hand, then shuffle$/))) {
    return [{ e: 'search', n: 2, filter: pfilter('basic land card'), cultivate: true }];
  }
  if ((m = s.match(/^search your library for (an|a|up to one|up to two|up to three|two) (?:(.+?) )?cards?(?: with (.+?))?, (?:reveal (?:it|them|that card|those cards), )?put (?:it|them|that card|those cards) (onto the battlefield( tapped)?|into your hand)(?:,| and)? then shuffle$/))) {
    let f = pfilter((m[2] ? m[2] + ' ' : '') + 'card', ctx.def);
    if (!f) return null;
    if (m[3]) {
      const mv = m[3].match(/^mana value (\d+) or less$/); if (!mv) return null; f.mvMax = +mv[1];
    }
    const n = numOf(m[1].replace('up to ', ''));
    return [{ e: 'search', n, filter: f, to: m[4].startsWith('onto') ? 'bf' : 'hand', tapped: !!m[5] }];
  }
  if ((m = s.match(/^add (.+)$/))) {
    const b = manaBundles(m[1]); if (!b) return null;
    return [{ e: 'mana', bundles: b }];
  }
  return null;
}

/** Testo di un'abilità (una o più frasi) -> { effects, targets } */
function effectsOf(text, ctx) {
  const effects = [];
  const sents = text.split(/\.\s+|\.$/).map(x => x.trim()).filter(Boolean);
  let partial = false;
  for (const raw of sents) {
    const parts = raw.split(/, then (?!shuffle)/);
    for (const p of parts) {
      const r = sentence(p, ctx);
      if (r) { effects.push(...r); continue; }
      // le frasi condizionali ("If ...") si possono ignorare: la carta funziona con il resto
      if (/^if /.test(p) || /^(this ability|activate only|spend only)/.test(p)) { partial = true; continue; }
      return null;
    }
  }
  return effects.length ? { effects, partial } : null;
}

// ------------------------------------------------------------------------------------------------ righe della carta
function parseKeywordLine(line, def, out) {
  const parts = line.split(/,\s*|;\s*/).map(x => x.trim()).filter(Boolean);
  const kws = []; const extra = []; let unknown = false; let partial = false;
  for (const p of parts) {
    let m;
    if (KEYWORDS.includes(p)) { kws.push(p); continue; }
    if ((m = p.match(/^ward \{(\d+)\}$/))) { extra.push(() => { def.ward = +m[1]; }); continue; }
    if ((m = p.match(/^equip (\{[^}]+\}(?:\{[^}]+\})*)$/))) {
      const cost = m[1];
      extra.push(() => def.abilities.push({ kind: 'act', cost: { mana: parseCost(cost) }, effects: [{ e: 'attach', to: { r: 'tgt', i: 0 } }],
        targets: [{ kind: 'obj', count: 1, filter: { types: ['creature'], subtypes: [], non: [], nonsub: [], colors: [], noncolors: [], kws: [], nokws: [], ctrl: 'you' } }], sorcery: true, equip: true, text: 'Equip' }));
      continue;
    }
    if ((m = p.match(/^enchant (.+)$/))) {
      const f = pfilter(m[1], def);
      if (!f) { unknown = true; break; }
      extra.push(() => { def.enchant = f; });
      continue;
    }
    if (KW_KNOWN.test(p)) { partial = true; continue; }
    unknown = true; break;
  }
  if (unknown) return false;
  for (const k of kws) def.kw[k] = true;
  extra.forEach(f => f());
  if (partial) out.partial = true;
  return true;
}

const TRIGGERS = [
  [/^when(?:ever)? ~ enters(?: the battlefield)? or attacks, (.+)$/, ['etb', 'attacks']],
  [/^when(?:ever)? ~ enters(?: the battlefield)? or dies, (.+)$/, ['etb', 'dies']],
  [/^when(?:ever)? ~ enters(?: the battlefield)?, (.+)$/, ['etb']],
  [/^when(?:ever)? ~ dies, (.+)$/, ['dies']],
  [/^when(?:ever)? ~ leaves the battlefield, (.+)$/, ['ltb']],
  [/^whenever ~ attacks or blocks, (.+)$/, ['attacks', 'blocks']],
  [/^whenever ~ attacks, (.+)$/, ['attacks']],
  [/^whenever ~ blocks, (.+)$/, ['blocks']],
  [/^whenever ~ deals combat damage to a player(?: or planeswalker)?, (.+)$/, ['cdp']],
  [/^whenever ~ deals combat damage to an opponent, (.+)$/, ['cdp']],
  [/^whenever ~ deals damage to an opponent, (.+)$/, ['cdp']],
  [/^at the beginning of your upkeep, (.+)$/, ['upkeep']],
  [/^at the beginning of your end step, (.+)$/, ['endstep']],
  [/^at the beginning of each end step, (.+)$/, ['eachEndstep']],
  [/^at the beginning of combat on your turn, (.+)$/, ['combat']],
  [/^at the beginning of your precombat main phase, (.+)$/, ['main1']],
  [/^whenever you gain life, (.+)$/, ['gainLife']],
  [/^whenever you draw a card, (.+)$/, ['drawYou']],
  [/^whenever an opponent draws a card, (.+)$/, ['drawOpp']],
  [/^whenever a creature you control attacks, (.+)$/, ['allyAttacks']],
];

function parseTrigger(line, def, ctx) {
  for (const [re, ons] of TRIGGERS) {
    const m = line.match(re);
    if (m) {
      if (ons[0] === 'drawOpp') ctx.trigPlayer = true;
      if (ons[0] === 'allyAttacks') ctx.last = { r: 'trig' };
      const r = effectsOf(m[1], ctx);
      return r ? { kind: 'trig', on: ons, ...r } : null;
    }
  }
  let m = line.match(/^whenever (another|a|an) (.+?) (?:you control )?enters(?: the battlefield)?(?: under your control)?, (.+)$/);
  if (m) {
    const f = pfilter(m[2], def); if (!f) return null;
    if (/you control|under your control/.test(line.split(',')[0])) f.ctrl = 'you';
    if (m[1] === 'another') f.other = true;
    ctx.last = { r: 'trig' };
    const r = effectsOf(m[3], ctx);
    return r ? { kind: 'trig', on: ['enters'], filter: f, ...r } : null;
  }
  m = line.match(/^whenever (another|a|an) (.+?) (?:you control )?dies, (.+)$/);
  if (m) {
    const f = pfilter(m[2], def); if (!f) return null;
    if (/you control/.test(line.split(',')[0])) f.ctrl = 'you';
    if (m[1] === 'another') f.other = true;
    const r = effectsOf(m[3], ctx);
    return r ? { kind: 'trig', on: ['dies2'], filter: f, ...r } : null;
  }
  m = line.match(/^whenever you cast (?:an|a) ?(.*?) ?spell, (.+)$/);
  if (m) {
    let f = null;
    if (m[1]) { f = pfilter(m[1] + ' spell', def); if (!f) return null; f.spell = false; }
    const r = effectsOf(m[2], ctx);
    return r ? { kind: 'trig', on: ['cast'], filter: f, ...r } : null;
  }
  return undefined; // non è un innesco
}

function parseActivated(line, def, ctx) {
  const i = line.indexOf(': ');
  if (i < 0) return undefined;
  const costStr = line.slice(0, i).trim();
  let body = line.slice(i + 2).trim();
  const cost = {};
  if (/^[+-]?(\d+|x)$/.test(costStr)) {
    cost.loyalty = costStr === '0' ? 0 : costStr.toLowerCase() === '-x' ? 'X' : +costStr;
  } else {
    for (const p of costStr.split(/,\s*/)) {
      let m;
      if (p === '{t}') cost.tap = true;
      else if (/^(\{[^}]+\})+$/.test(p)) cost.mana = parseCost(p);
      else if (p === 'sacrifice ~') cost.sacSelf = true;
      else if ((m = p.match(/^sacrifice (a|an|another|two) (.+)$/))) { const f = pfilter((m[1] === 'another' ? 'other ' : '') + m[2], def); if (!f) return null; cost.sac = f; if (m[1] === 'two') cost.sacN = 2; }
      else if ((m = p.match(/^pay (\d+) life$/))) cost.life = +m[1];
      else if ((m = p.match(/^discard (a|one|two) cards?$/))) cost.discard = numOf(m[1]);
      else return /\{|sacrifice|pay|discard|tap|remove|exile|return/.test(p) ? null : undefined;
    }
  }
  let sorcery = false, once = false;
  body = body.replace(/\s*activate (?:this ability )?only as a sorcery\.?/, () => { sorcery = true; return ''; })
    .replace(/\s*activate (?:this ability )?only once each turn\.?/, () => { once = true; return ''; })
    .replace(/\s*activate only during your turn\.?/, () => { sorcery = true; return ''; }).trim();
  const r = effectsOf(body, ctx);
  if (!r) return null;
  const ab = { kind: 'act', cost, sorcery: sorcery || cost.loyalty !== undefined, once, ...r };
  ab.isMana = !cost.loyalty && cost.loyalty !== 0 && r.effects.some(e => e.e === 'mana') && !ctx.targets.length &&
    r.effects.every(e => e.e === 'mana' || (e.e === 'damage' && e.to.length === 1 && e.to[0].r === 'you') || e.e === 'sacSelf' || e.e === 'lose');
  return ab;
}

function parseStatic(line, def) {
  let m;
  if ((m = line.match(/^(other )?(.+?) (you control|your opponents control) (?:get|gets) ([+-]\d+)\/([+-]\d+)(?: and (?:have|has) (.+))?$/))) {
    const f = pfilter(m[2], def); if (!f) return null;
    if (!f.types.length && f.subtypes.length) f.types.push('creature');
    f.ctrl = m[3] === 'you control' ? 'you' : 'opp';
    if (m[1]) f.other = true;
    let kws = [];
    if (m[6]) { kws = parseKwList(m[6]); if (!kws) return null; }
    return { kind: 'anthem', filter: f, p: +m[4], t: +m[5], kws };
  }
  if ((m = line.match(/^(other )?(.+?) you control (?:have|has) (.+)$/))) {
    const f = pfilter(m[2], def); if (!f) return null;
    if (!f.types.length && f.subtypes.length) f.types.push('creature');
    f.ctrl = 'you'; if (m[1]) f.other = true;
    const kws = parseKwList(m[3]); if (!kws) return null;
    return { kind: 'anthem', filter: f, p: 0, t: 0, kws };
  }
  if ((m = line.match(/^(enchanted|equipped) (creature|permanent) gets ([+-]\d+)\/([+-]\d+)(?: and (?:has|gains) (.+))?$/))) {
    let kws = [];
    if (m[5]) { kws = parseKwList(m[5]); if (!kws) return null; }
    return { kind: 'attached', p: +m[3], t: +m[4], kws };
  }
  if ((m = line.match(/^(enchanted|equipped) creature has (.+)$/))) { const kws = parseKwList(m[2]); return kws ? { kind: 'attached', p: 0, t: 0, kws } : null; }
  if (/^enchanted creature can't attack or block$/.test(line) || /^enchanted creature can't attack, block, or crew vehicles$/.test(line) ||
    /^enchanted creature can't attack or block, and its activated abilities can't be activated$/.test(line)) return { kind: 'attached', p: 0, t: 0, kws: ['cantattack', 'cantblock'] };
  if (/^enchanted creature can't block$/.test(line)) return { kind: 'attached', p: 0, t: 0, kws: ['cantblock'] };
  if (/^enchanted (creature|permanent) doesn't untap during its controller's untap step$/.test(line)) return { kind: 'attached', p: 0, t: 0, kws: ['nountap'] };
  if (/^~ enters(?: the battlefield)? tapped$/.test(line)) return { kind: 'etb', tapped: true };
  if ((m = line.match(/^~ enters(?: the battlefield)? with (\w+) \+1\/\+1 counters? on it$/))) return { kind: 'etb', counters: numOf(m[1]) };
  if ((m = line.match(/^~ enters(?: the battlefield)? tapped unless you control an? (\w+) or an? (\w+)$/))) return { kind: 'etb', unlessCtrl: [m[1], m[2]] };
  if (/^~ enters(?: the battlefield)? tapped unless you control two or fewer other lands$/.test(line)) return { kind: 'etb', fast: true };
  if (/^~ enters(?: the battlefield)? tapped unless you control two or more other lands$/.test(line)) return { kind: 'etb', slow: true };
  if (/^as ~ enters(?: the battlefield)?, you may pay 2 life\. if you don't, (?:it|~) enters(?: the battlefield)? tapped\.?$/.test(line)) return { kind: 'etb', shock: true };
  if (/^~ can't block\.?$/.test(line)) return { kind: 'self', kws: ['cantblock'] };
  if ((m = line.match(/^~ can't be blocked by creatures with power (\d+) or less$/))) return { kind: 'self', kws: ['evade' + m[1]] };
  if (/^~ can block only creatures with flying$/.test(line)) return { kind: 'self', kws: ['blockflyonly'] };
  if (/^you have no maximum hand size$/.test(line)) return { kind: 'nomax' };
  if ((m = line.match(/^(.+?) spells with (\w+) you cast cost \{(\d+)\} less to cast$/))) {
    const f = pfilter(m[1] + ' spell with ' + m[2], def); if (!f) return null; f.spell = false;
    return { kind: 'reduce', filter: f, n: +m[3] };
  }
  if ((m = line.match(/^(.+?) spells? you cast cost \{(\d+)\} less to cast$/))) {
    const f = pfilter(m[1] + ' spell', def); if (!f) return null; f.spell = false;
    return { kind: 'reduce', filter: f, n: +m[2] };
  }
  if ((m = line.match(/^(other )?(.+?) creatures get ([+-]\d+)\/([+-]\d+)(?: and have (.+))?$/))) {
    const f = pfilter(m[2] + ' creature', def); if (!f) return null;
    if (m[1]) f.other = true;
    let kws = [];
    if (m[5]) { kws = parseKwList(m[5]) || []; }
    return { kind: 'anthem', filter: f, p: +m[3], t: +m[4], kws };
  }
  if (/^~ can't be blocked\.?$/.test(line)) return { kind: 'self', kws: ['unblockable'] };
  if (/^~ can't attack or block\.?$/.test(line)) return { kind: 'self', kws: ['cantattack', 'cantblock'] };
  if (/^~ can't be countered\.?$/.test(line) || /^this spell can't be countered\.?$/.test(line)) return { kind: 'noop' };
  return null;
}

// ------------------------------------------------------------------------------------------------ compilazione completa
function cleanTypeLine(tl) {
  const [left, right = ''] = tl.split(/\s+—\s+|\s+-\s+/);
  const lw = left.toLowerCase().split(/\s+/);
  return {
    supertypes: lw.filter(w => SUPERTYPES.includes(w)),
    types: lw.filter(w => CARD_TYPES.includes(w)).map(t => (t === 'tribal' ? 'kindred' : t)),
    subtypes: right.split(/\s+/).filter(Boolean),
  };
}

/** Dati Scryfall (ridotti) -> definizione di carta per il motore */
export function compileCard(sc) {
  const face = sc.card_faces && !sc.oracle_text && sc.card_faces[0] ? sc.card_faces[0] : sc;
  const typeLine = face.type_line || sc.type_line || '';
  const tl = cleanTypeLine(typeLine);
  const name = face.name || sc.name;
  const def = {
    name, fullName: sc.name,
    nameIt: (face.printed_name || sc.printed_name || '').trim() || null,
    typeIt: face.printed_type_line || sc.printed_type_line || null,
    textIt: face.printed_text || sc.printed_text || null,
    img: sc.img || (face.image_uris || sc.image_uris || {}).normal || null,
    imgSmall: sc.imgSmall || (face.image_uris || sc.image_uris || {}).small || null,
    manaCost: face.mana_cost || '',
    cost: parseCost(face.mana_cost || ''),
    cmc: sc.cmc ?? 0,
    typeLine, ...tl,
    power: face.power != null ? (parseInt(face.power, 10) || 0) : null,
    toughness: face.toughness != null ? (parseInt(face.toughness, 10) || 0) : null,
    loyalty: face.loyalty != null ? (parseInt(face.loyalty, 10) || 0) : null,
    colors: face.colors || sc.colors || [],
    identity: sc.color_identity || [],
    oracle: face.oracle_text || '',
    kw: {}, ward: 0, abilities: [], triggers: [], statics: [], etb: {}, spell: null,
    unsupported: [], partialLines: [],
    legal: sc.legalities || {},
    set: sc.set || '', cn: sc.collector_number || '',
    layoutNote: sc.card_faces && sc.card_faces.length > 1 ? 'Solo il primo lato è simulato.' : null,
  };
  // le terre base producono mana per il loro tipo
  const basicMana = { Plains: 'W', Island: 'U', Swamp: 'B', Mountain: 'R', Forest: 'G' };
  for (const st of def.subtypes) if (basicMana[st] && def.types.includes('land')) {
    def.abilities.push({ kind: 'act', cost: { tap: true }, effects: [{ e: 'mana', bundles: [[basicMana[st]]] }], isMana: true, intrinsic: true });
  }
  try { parseText(def); }
  catch (e) {
    // testo non leggibile: la carta resta giocabile come semplice permanente/magia senza effetti
    def.abilities = def.abilities.filter(a => a.intrinsic); def.triggers = []; def.statics = []; def.spell = null; def.kw = {};
    def.unsupported = (def.oracle || '').split('\n').filter(Boolean);
  }
  if (def.types.includes('creature') && def.cost.X === 0 && /\*/.test(String(face.power ?? '') + String(face.toughness ?? ''))) {
    def.unsupported.push('Forza/costituzione variabile (*): usata come 0.');
  }
  if (def.layoutNote) def.partialLines.push(def.layoutNote);
  def.support = def.unsupported.length ? 'partial' : 'full';
  return def;
}

function parseText(def) {
  let t = def.oracle || '';
  t = t.replace(/\s*\([^)]*\)/g, '').replace(/[−–]/g, '-');
  const names = [def.name];
  if (def.name.includes(',')) names.push(def.name.split(',')[0]);
  else if (def.supertypes.includes('legendary') && def.name.includes(' of ')) names.push(def.name.split(' of ')[0]);
  for (const n of names.sort((a, b) => b.length - a.length)) t = t.split(n).join('\u0001');
  t = t.replace(/\bthis (creature|spell|land|artifact|enchantment|aura|equipment|vehicle|permanent|planeswalker|card|token|saga|battle)\b/gi, '\u0001');
  const rawLines = t.split('\n').map(x => x.trim()).filter(Boolean);
  // i punti elenco delle scelte modali si uniscono alla riga "Choose one —"
  const lines = [];
  for (const l of rawLines) {
    if (l.startsWith('•') && lines.length) lines[lines.length - 1] += '\n' + l;
    else lines.push(l);
  }
  const isSpell = def.types.includes('instant') || def.types.includes('sorcery');
  const spellParts = [];
  for (const orig of lines) {
    let line = orig.toLowerCase().replace(/\u0001/g, '~');
    const shown = orig.replace(/\u0001/g, def.name);
    // parole d'abilità ("Landfall — ...")
    line = line.replace(/^(?!choose)[a-z' ,]+ — (?=\S)/, '');
    const ctx = { def, targets: [], last: null };
    const status = { partial: false };
    if (parseKeywordLine(line.replace(/\.$/, ''), def, status)) {
      if (status.partial) def.partialLines.push(shown);
      continue;
    }
    if (/^choose (one|two|one or both|one or more) —\n/.test(line) || /^choose (one|two|one or both) —/.test(line)) {
      const modes = [];
      let ok = true;
      for (const b of line.split('\n').slice(1)) {
        const c2 = { def, targets: [], last: null };
        const txt = b.replace(/^•\s*/, '');
        const r = effectsOf(txt, c2);
        if (!r) { ok = false; modes.push(null); continue; }
        modes.push({ effects: r.effects, targets: c2.targets, text: txt });
      }
      if (!modes.some(Boolean)) { def.unsupported.push(shown); continue; }
      if (!ok) def.unsupported.push(shown + ' (alcune scelte non sono simulate)');
      const modal = { modes: modes.map((m, i) => m && { ...m, textShown: orig.split('\n')[i + 1]?.replace(/^•\s*/, '').replace(/\u0001/g, def.name) }).filter(Boolean) };
      if (isSpell) spellParts.push({ modal });
      else def.unsupported.push(shown);
      continue;
    }
    const trig = parseTrigger(line, def, ctx);
    if (trig) { trig.targets = ctx.targets; trig.text = shown; def.triggers.push(trig); if (trig.partial) def.partialLines.push(shown); continue; }
    if (trig === null) { def.unsupported.push(shown); continue; }
    if (!isSpell || /^\{|^[+-]?\d+: /.test(line)) {
      const act = parseActivated(line, def, ctx);
      if (act) { act.targets = ctx.targets; act.text = shown; def.abilities.push(act); continue; }
      if (act === null) { def.unsupported.push(shown); continue; }
    }
    const st = parseStatic(line.replace(/\.$/, ''), def);
    if (st) {
      if (st.kind === 'etb') Object.assign(def.etb, st);
      else if (st.kind === 'self') st.kws.forEach(k => { def.kw[k] = true; });
      else if (st.kind !== 'noop') def.statics.push(st);
      continue;
    }
    if (isSpell) {
      const r = effectsOf(line, ctx);
      if (r) { spellParts.push({ effects: r.effects, targets: ctx.targets }); if (r.partial) def.partialLines.push(shown); continue; }
    }
    def.unsupported.push(shown);
  }
  if (isSpell) {
    const modal = spellParts.find(p => p.modal);
    if (modal) def.spell = { modes: modal.modal.modes };
    else if (spellParts.length) {
      // più righe di effetti: i bersagli vengono rinumerati in sequenza
      const effects = []; const targets = [];
      for (const p of spellParts) {
        const off = targets.length;
        targets.push(...p.targets);
        effects.push(...shiftRefs(p.effects, off));
      }
      def.spell = { effects, targets };
    }
  }
  // Aura: il bersaglio dell'incantesimo è la creatura da incantare
  if (def.subtypes.includes('Aura') && def.enchant) def.auraTarget = { kind: 'obj', count: 1, filter: def.enchant };
  if (def.kw.prowess) def.triggers.push({ kind: 'trig', on: ['cast'], filter: { types: [], subtypes: [], non: ['creature'], nonsub: [], colors: [], noncolors: [], kws: [], nokws: [] }, effects: [{ e: 'pump', what: { r: 'self' }, p: 1, t: 1, kws: [] }], targets: [], text: 'Prodezza' });
}

function shiftRefs(effects, off) {
  if (!off) return effects;
  const fix = v => {
    if (Array.isArray(v)) return v.map(fix);
    if (v && typeof v === 'object') {
      const o = {};
      for (const [k, x] of Object.entries(v)) o[k] = fix(x);
      if (o.r === 'tgt') o.i += off;
      return o;
    }
    return v;
  };
  return effects.map(fix);
}

// ------------------------------------------------------------------------------------------------ pedine
const TOKEN_NAMES_IT = { Treasure: 'Tesoro', Food: 'Cibo', Clue: 'Indizio', Blood: 'Sangue', Map: 'Mappa' };
export function tokenDef(d) {
  if (d.named) {
    const base = { name: d.named, nameIt: TOKEN_NAMES_IT[d.named] || d.named, token: true, types: ['artifact'], subtypes: [d.named], supertypes: [],
      cost: parseCost(''), cmc: 0, colors: [], identity: [], kw: {}, ward: 0, abilities: [], triggers: [], statics: [], etb: {}, unsupported: [], partialLines: [], power: null, toughness: null, typeLine: 'Token Artifact — ' + d.named };
    if (d.named === 'Treasure') base.abilities.push({ kind: 'act', cost: { tap: true, sacSelf: true }, effects: [{ e: 'mana', bundles: [['*']] }], isMana: true, text: '{T}, Sacrifica: aggiungi un mana di qualsiasi colore.' });
    if (d.named === 'Food') base.abilities.push({ kind: 'act', cost: { tap: true, sacSelf: true, mana: parseCost('{2}') }, effects: [{ e: 'gain', who: { r: 'you' }, n: 3 }], targets: [], text: '{2}, {T}, Sacrifica: guadagni 3 punti vita.' });
    if (d.named === 'Clue') base.abilities.push({ kind: 'act', cost: { sacSelf: true, mana: parseCost('{2}') }, effects: [{ e: 'draw', who: { r: 'you' }, n: 1 }], targets: [], text: '{2}, Sacrifica: pesca una carta.' });
    return base;
  }
  const kw = {}; (d.kws || []).forEach(k => { kw[k] = true; });
  const name = d.subtypes.join(' ') || 'Pedina';
  return { name, nameIt: name, token: true, types: d.artifact ? ['artifact', 'creature'] : ['creature'], subtypes: d.subtypes, supertypes: [],
    cost: parseCost(''), cmc: 0, colors: d.colors, identity: d.colors, kw, ward: 0, abilities: [], triggers: [], statics: [], etb: {}, unsupported: [], partialLines: [],
    power: d.p, toughness: d.t, typeLine: `Token ${d.artifact ? 'Artifact ' : ''}Creature — ${name}` };
}
