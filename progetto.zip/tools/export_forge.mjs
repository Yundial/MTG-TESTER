// Esporta i mazzi del bot nel formato .dck di Forge (cartella forge/).
import { mkdirSync, writeFileSync, rmSync } from 'node:fs';
import { BOT_DECKS, parseList } from '../web/js/botdecks.js';

const OUT = new URL('../forge/', import.meta.url).pathname;
const LVL = ['1 Facile', '2 Medio', '3 Difficile e Incubo'];
rmSync(OUT + 'mazzi', { recursive: true, force: true });
const all = [];
for (const d of BOT_DECKS) {
  const dir = `${OUT}mazzi/${d.format === 'commander' ? 'Commander' : '60 carte'}/${LVL[d.level]}`;
  mkdirSync(dir, { recursive: true });
  const cards = parseList(d.list);
  const lines = ['[metadata]', `Name=${d.name}`, `Description=${d.desc}`];
  if (d.commander) lines.push('[Commander]', `1 ${d.commander}`);
  lines.push('[Main]', ...cards.map(x => `${x.n} ${x.name}`), '[Sideboard]', '');
  const file = d.name.replace(/[^\w\- ',]+/g, '_').replace(/'/g, '');
  writeFileSync(`${dir}/${file}.dck`, lines.join('\n'));
  all.push(`=== ${d.name} (${d.format === 'commander' ? 'Commander' : '60 carte'} · ${LVL[d.level].slice(2)}) ===`,
    ...(d.commander ? ['Commander', `1 ${d.commander}`, '', 'Deck'] : []), ...cards.map(x => `${x.n} ${x.name}`), '');
}
writeFileSync(`${OUT}mazzi/TUTTE_LE_LISTE.txt`, all.join('\n'));
console.log('mazzi Forge esportati in', OUT + 'mazzi');
