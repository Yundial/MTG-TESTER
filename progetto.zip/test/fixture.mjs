// Carica i dati di prova in formato simile a Scryfall.
import { readFileSync } from 'node:fs';
const here = new URL('.', import.meta.url).pathname;
export function loadFixture() {
  const out = [];
  for (const line of readFileSync(here + 'fixture_cards.txt', 'utf8').split('\n')) {
    if (!line.trim() || line.startsWith('#')) continue;
    const [name, cost, type, pt, text, it] = line.split(/\s*\|\s*/).map(x => (x ?? '').trim());
    const colors = [...new Set([...cost.matchAll(/\{([WUBRG])/g)].map(m => m[1]))];
    const identity = [...new Set([...colors, ...[...text.matchAll(/\{([WUBRG])\}/g)].map(m => m[1])])];
    const cmc = [...cost.matchAll(/\{([^}]+)\}/g)].reduce((s, m) => s + (/^\d+$/.test(m[1]) ? +m[1] : m[1] === 'X' ? 0 : 1), 0);
    const sc = { name, mana_cost: cost, type_line: type, oracle_text: text.replace(/\\n/g, '\n'), cmc, colors, color_identity: identity,
      legalities: { standard: 'legal', pioneer: 'legal', modern: 'legal', commander: 'legal' }, set: 'tst', collector_number: String(out.length + 1) };
    if (pt.startsWith('L:')) sc.loyalty = pt.slice(2);
    else if (pt.includes('/')) { const [p, t] = pt.split('/'); sc.power = p; sc.toughness = t; }
    if (it) { sc.printed_name = it; sc.lang = 'it'; }
    out.push(sc);
  }
  return out;
}
