// Test mirati delle regole: ogni scenario parte da una situazione costruita a mano.
import { loadFixture } from './fixture.mjs';
import { registerCard, createGame, run, respond, addCard, stats, actionInfo, legalActions, cname } from '../web/js/engine/game.js';
import { botAnswer } from '../web/js/engine/bot.js';
for (const sc of loadFixture()) registerCard(sc);

let fails = 0, passes = 0;
const ok = (c, msg) => { if (c) passes++; else { fails++; console.log('  ✗', msg); } };

function setup(format = 'constructed') {
  const G = createGame({ format, seed: 7, first: 0, players: [
    { name: 'Tu', deck: Array(30).fill('Island'), bot: null }, { name: 'Bot', deck: Array(30).fill('Swamp'), bot: 'hard' }] });
  for (const P of G.players) { P.library.push(...P.hand); P.hand = []; for (const id of P.library) G.objs[id].zone = 'library'; }
  G.tasks = []; G.pending = null; G.turn = 3; G.active = 0; G.step = 'main1';
  G.tasks.push({ t: 'prio', passes: 0, p: 0 });
  return G;
}
const go = G => run(G);
const pend = G => G.pending;
/** risolve automaticamente: il bot risponde con l'IA, il giocatore 0 passa sempre */
function autoUntil(G, cond, max = 200) {
  for (let i = 0; i < max && !G.over && G.pending && !cond(G); i++) {
    const P = G.pending;
    if (P.player === 1) respond(G, botAnswer(G, 'hard'));
    else if (P.type === 'priority') respond(G, { pass: true });
    else if (P.type === 'attack') respond(G, { attacks: [] });
    else if (P.type === 'block') respond(G, { blocks: [] });
    else if (P.type === 'yesno') respond(G, { yes: true });
    else if (P.type === 'choose') respond(G, { ids: P.cards.slice(0, P.min) });
    else if (P.type === 'targets') respond(G, { targets: P.specs.map(s => [s.options[0]]) });
    else if (P.type === 'mulligan') respond(G, { keep: true });
  }
}
const lands = (G, p, name, n) => { for (let i = 0; i < n; i++) addCard(G, name, p, 'bf'); };

// 1) Fulmine sulla creatura avversaria
{
  console.log('Fulmine');
  const G = setup(); lands(G, 0, 'Mountain', 1);
  const bear = addCard(G, 'Grizzly Bears', 1, 'bf');
  const bolt = addCard(G, 'Lightning Bolt', 0, 'hand');
  go(G);
  ok(pend(G)?.type === 'priority' && pend(G).player === 0, 'priorità al giocatore');
  const a = legalActions(G, 0).find(x => x.id === bolt.id);
  ok(!!a, 'Fulmine lanciabile');
  const info = actionInfo(G, 0, a);
  const tgt = info.specs[0].options.find(r => r.id === bear.id);
  respond(G, { ...a, targets: [[tgt]] });
  autoUntil(G, G => !G.stack.length && G.pending?.player === 0);
  ok(bear.zone === 'gy', 'gli orsi muoiono');
  ok(bolt.zone === 'gy', 'il Fulmine va al cimitero');
}
// 2) Contromagia dell'avversario e Perdita di Mana con pagamento
{
  console.log('Contromagie');
  const G = setup(); lands(G, 0, 'Island', 2); lands(G, 1, 'Island', 2);
  const cs = addCard(G, 'Counterspell', 1, 'hand');
  const ae = addCard(G, 'Air Elemental', 0, 'hand');
  lands(G, 0, 'Island', 3);
  go(G);
  respond(G, legalActions(G, 0).find(x => x.id === ae.id));
  ok(G.stack.length === 1, 'Elementale in pila');
  autoUntil(G, G => G.pending?.player === 0 && !G.stack.length);
  ok(ae.zone === 'gy' && cs.zone === 'gy', 'il bot neutralizza (Difficile)');
  const G2 = setup(); lands(G2, 0, 'Island', 9); lands(G2, 1, 'Island', 2);
  addCard(G2, 'Mana Leak', 1, 'hand');
  const ae2 = addCard(G2, 'Air Elemental', 0, 'hand');
  go(G2);
  respond(G2, legalActions(G2, 0).find(x => x.id === ae2.id));
  autoUntil(G2, G => G.pending?.type === 'yesno' || (G.pending?.player === 0 && !G.stack.length));
  ok(G2.pending?.type === 'yesno' && G2.pending.purpose === 'payUnless', 'chiede di pagare 3');
  respond(G2, { yes: true });
  autoUntil(G2, G => G.pending?.player === 0 && !G.stack.length);
  ok(ae2.zone === 'bf', "pagato: l'Elementale entra");
}
// 3) Combattimento: attacco improvviso, tocco letale + travolgere, legame vitale
{
  console.log('Combattimento');
  const G = setup();
  const knight = addCard(G, 'Lyra Dawnbringer', 0, 'bf'); // 5/5 volare, attacco improvviso, legame vitale
  const hawk = addCard(G, 'Vampire Nighthawk', 1, 'bf');  // 2/3 volare tocco letale
  G.players[1].bot = 'easy';
  go(G);
  autoUntil(G, G => G.pending?.type === 'attack');
  respond(G, { attacks: [{ id: knight.id }] });
  autoUntil(G, G => G.pending?.type === 'block');
  respond(G, { blocks: [{ b: hawk.id, a: knight.id }] });
  autoUntil(G, G => G.step === 'main2');
  ok(hawk.zone === 'gy', 'il falco muore prima di colpire (attacco improvviso)');
  ok(knight.zone === 'bf', 'Lyra sopravvive');
  ok(G.players[0].life === 25, 'legame vitale +5 (' + G.players[0].life + ')');
}
{
  const G = setup();
  const ooze = addCard(G, 'Pelakka Wurm', 0, 'bf'); // 7/7 travolgere
  addCard(G, 'Typhoid Rats', 0, 'bf');
  const wall = addCard(G, 'Giant Spider', 1, 'bf'); // 2/4
  G.players[1].bot = 'easy';
  go(G);
  autoUntil(G, G => G.pending?.type === 'attack');
  respond(G, { attacks: [{ id: ooze.id }] });
  autoUntil(G, G => G.pending?.type === 'block');
  respond(G, { blocks: [{ b: wall.id, a: ooze.id }] });
  autoUntil(G, G => G.step === 'main2');
  ok(G.players[1].life === 17, 'travolgere: 3 danni passano (' + G.players[1].life + ')');
}
// 4) Commander: lancio dalla zona di comando, tassa, ritorno
{
  console.log('Commander');
  const G = createGame({ format: 'commander', seed: 3, first: 0, players: [
    { name: 'Tu', deck: Array(40).fill('Mountain'), commander: 'Krenko, Mob Boss', bot: null }, { name: 'Bot', deck: Array(40).fill('Swamp'), bot: 'hard' }] });
  ok(G.players[0].life === 40, '40 punti vita');
  for (const P of G.players) { P.library.push(...P.hand); P.hand = []; }
  G.tasks = [{ t: 'prio', passes: 0, p: 0 }]; G.pending = null; G.turn = 3; G.step = 'main1';
  lands(G, 0, 'Mountain', 6);
  addCard(G, 'Murder', 1, 'hand'); lands(G, 1, 'Swamp', 3);
  go(G);
  const cmd = G.objs[G.players[0].commanderId];
  const a = legalActions(G, 0).find(x => x.id === cmd.id);
  ok(!!a, 'comandante lanciabile dalla zona di comando');
  respond(G, a);
  autoUntil(G, G => G.pending?.player === 0 && !G.stack.length);
  ok(cmd.zone === 'command', `ucciso dal bot torna nella zona di comando (zona: ${cmd.zone})`);
  ok(G.players[0].cmdTax === 1, 'tassa +2 registrata');
  const info = actionInfo(G, 0, { t: 'cast', id: cmd.id });
  ok(info.cost.includes('+2'), 'costo con tassa: ' + info.cost);
}
// 5) Aura Pacifismo e Equipaggiamento
{
  console.log('Aure ed Equipaggiamenti');
  const G = setup(); lands(G, 0, 'Plains', 4);
  const bear = addCard(G, 'Grizzly Bears', 1, 'bf');
  const pac = addCard(G, 'Pacifism', 0, 'hand');
  const sword = addCard(G, 'Bonesplitter', 0, 'bf');
  const mine = addCard(G, 'Savannah Lions', 0, 'bf');
  go(G);
  const a = legalActions(G, 0).find(x => x.id === pac.id);
  const info = actionInfo(G, 0, a);
  respond(G, { ...a, targets: [[info.specs[0].options.find(r => r.id === bear.id)]] });
  autoUntil(G, G => G.pending?.player === 0 && !G.stack.length);
  ok(pac.zone === 'bf' && pac.att === bear.id, 'Pacifismo assegnato');
  ok(stats(G, bear).kw.cantblock && stats(G, bear).kw.cantattack, 'gli orsi non possono attaccare né bloccare');
  const eq = legalActions(G, 0).find(x => x.id === sword.id);
  const ei = actionInfo(G, 0, eq);
  respond(G, { ...eq, targets: [[ei.specs[0].options.find(r => r.id === mine.id)]] });
  autoUntil(G, G => G.pending?.player === 0 && !G.stack.length);
  ok(stats(G, mine).p === 4, 'Spaccaossa: +2/+0 (' + stats(G, mine).p + ')');
}
// 6) Planeswalker, Luce Esiliante, X, spazzata
{
  console.log('Planeswalker, esilio temporaneo, X');
  const G = setup(); lands(G, 0, 'Swamp', 5);
  addCard(G, 'Grizzly Bears', 1, 'hand');
  const lili = addCard(G, 'Liliana Vess', 0, 'hand');
  go(G);
  respond(G, legalActions(G, 0).find(x => x.id === lili.id));
  autoUntil(G, G => G.pending?.player === 0 && !G.stack.length);
  ok(lili.zone === 'bf' && lili.c.loyalty === 5, 'Liliana in campo con 5 fedeltà');
  const plus = legalActions(G, 0).find(x => x.id === lili.id && x.ai === 0);
  ok(!!plus, '+1 disponibile');
  const pi = actionInfo(G, 0, plus);
  respond(G, { ...plus, targets: [[pi.specs[0].options.find(r => r.p === 1)]] });
  autoUntil(G, G => !G.stack.length);
  ok(lili.c.loyalty === 6 && G.players[1].gy.some(id => G.objs[id].key === 'Grizzly Bears'), 'fedeltà 6 e il bot scarta');
  ok(!legalActions(G, 0).some(x => x.id === lili.id), 'una sola abilità di fedeltà per turno');

  const H = setup(); lands(H, 0, 'Plains', 3);
  const ae = addCard(H, 'Air Elemental', 1, 'bf');
  const bl = addCard(H, 'Banishing Light', 0, 'hand');
  const cs = addCard(H, 'Murder', 1, 'hand'); lands(H, 1, 'Swamp', 3); void cs;
  go(H);
  respond(H, legalActions(H, 0).find(x => x.id === bl.id));
  autoUntil(H, G => G.pending?.type === 'targets' || (G.pending?.player === 0 && !G.stack.length));
  if (H.pending?.type === 'targets') respond(H, { targets: [[H.pending.specs[0].options[0]]] });
  autoUntil(H, G => G.pending?.player === 0 && !G.stack.length);
  ok(ae.zone === 'exile', 'Luce Esiliante esilia l\'Elementale');
  // il bot non può distruggere un incantesimo con Omicidio: lo distruggiamo a mano
  const { moveTo } = await import('../web/js/engine/game.js');
  moveTo(H, bl.id, 'gy');
  ok(ae.zone === 'bf', 'se Luce Esiliante lascia il campo, l\'Elementale ritorna');

  const X = setup(); lands(X, 0, 'Mountain', 6);
  const bz = addCard(X, 'Blaze', 0, 'hand');
  go(X);
  const xa = legalActions(X, 0).find(x => x.id === bz.id);
  const xi = actionInfo(X, 0, xa);
  ok(xi.xMax === 5, 'X massimo 5 con 6 montagne (' + xi.xMax + ')');
  respond(X, { ...xa, x: 5, targets: [[{ p: 1 }]] });
  autoUntil(X, G => G.pending?.player === 0 && !G.stack.length);
  ok(X.players[1].life === 15, 'Blaze X=5 al volto (' + X.players[1].life + ')');

  const W = setup(); lands(W, 0, 'Plains', 4);
  addCard(W, 'Grizzly Bears', 1, 'bf'); addCard(W, 'Savannah Lions', 0, 'bf');
  const wr = addCard(W, 'Wrath of God', 0, 'hand');
  go(W);
  respond(W, legalActions(W, 0).find(x => x.id === wr.id));
  autoUntil(W, G => G.pending?.player === 0 && !G.stack.length);
  ok(!W.bf.some(id => W.objs[id].key === 'Grizzly Bears' || W.objs[id].key === 'Savannah Lions'), "Ira di Dio distrugge tutte le creature");
}
// 7) Ricerca terre, terre shock, pedine, innesco "muore", Prodezza
{
  console.log('Ricerche, terre e inneschi');
  const G = setup(); lands(G, 0, 'Forest', 2);
  const rg = addCard(G, 'Rampant Growth', 0, 'hand');
  addCard(G, 'Forest', 0, 'library');
  go(G);
  respond(G, legalActions(G, 0).find(x => x.id === rg.id));
  autoUntil(G, G => G.pending?.type === 'choose');
  ok(G.pending?.type === 'choose' && G.pending.purpose === 'search', 'chiede quale terra cercare');
  respond(G, { ids: [G.pending.cards.find(id => G.objs[id].key === 'Forest')] });
  autoUntil(G, G => !G.stack.length);
  ok(G.bf.filter(id => G.objs[id].key === 'Forest').length === 3, 'terza Foresta in campo');

  const S = setup();
  const sf = addCard(S, 'Sacred Foundry', 0, 'hand');
  go(S);
  respond(S, legalActions(S, 0).find(x => x.id === sf.id));
  ok(S.pending?.type === 'yesno' && S.pending.purpose === 'shock', 'terra shock: chiede i 2 punti vita');
  respond(S, { yes: true });
  ok(sf.zone === 'bf' && !sf.tapped && S.players[0].life === 18, 'stappata pagando 2');

  const T = setup(); lands(T, 0, 'Mountain', 4);
  const bb = addCard(T, 'Beetleback Chief', 0, 'hand');
  go(T);
  respond(T, legalActions(T, 0).find(x => x.id === bb.id));
  autoUntil(T, G => G.pending?.player === 0 && !G.stack.length);
  ok(T.bf.filter(id => T.objs[id].token).length === 2, 'Capo Dorsocorazzato crea 2 Goblin');

  const D = setup(); lands(D, 0, 'Forest', 7); lands(D, 1, 'Swamp', 3);
  const wurm = addCard(D, 'Pelakka Wurm', 0, 'bf');
  const mur = addCard(D, 'Murder', 0, 'hand'); lands(D, 0, 'Swamp', 3);
  go(D);
  const hand0 = D.players[0].hand.length;
  const ma = legalActions(D, 0).find(x => x.id === mur.id);
  respond(D, { ...ma, targets: [[{ id: wurm.id, zcc: wurm.zcc }]] });
  autoUntil(D, G => G.pending?.player === 0 && !G.stack.length);
  ok(wurm.zone === 'gy' && D.players[0].hand.length === hand0, 'Pelakka muore e fa pescare (mano ' + D.players[0].hand.length + ' vs ' + hand0 + ')');

  const P = setup(); lands(P, 0, 'Mountain', 2);
  const sw = addCard(P, 'Monastery Swiftspear', 0, 'bf');
  const sh = addCard(P, 'Shock', 0, 'hand');
  go(P);
  const sa = legalActions(P, 0).find(x => x.id === sh.id);
  respond(P, { ...sa, targets: [[{ p: 1 }]] });
  autoUntil(P, G => G.pending?.player === 0 && !G.stack.length);
  ok(stats(P, sw).p === 2 && stats(P, sw).t === 3, 'Prodezza +1/+1 (' + stats(P, sw).p + '/' + stats(P, sw).t + ')');
}
// 8) Mulligan londinese e scarto a fine turno
{
  console.log('Mulligan e mano massima');
  const G = createGame({ format: 'constructed', seed: 11, first: 0, players: [
    { name: 'Tu', deck: Array(60).fill('Mountain'), bot: null }, { name: 'Bot', deck: Array(60).fill('Swamp'), bot: 'easy' }] });
  run(G);
  ok(G.pending.type === 'mulligan', 'chiede il mulligan');
  respond(G, { keep: false });
  ok(G.pending.type === 'mulligan' && G.pending.bottom === 1, 'secondo giro: 1 da mettere in fondo');
  respond(G, { keep: true });
  ok(G.pending.type === 'choose' && G.pending.purpose === 'bottom', 'sceglie la carta da mettere in fondo');
  respond(G, { ids: [G.pending.cards[0]] });
  ok(G.players[0].hand.length === 6, 'mano da 6');
}
console.log(`\n${passes} verifiche superate, ${fails} fallite`);
process.exit(fails ? 1 : 0);
