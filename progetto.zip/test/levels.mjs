// Confronto tra livelli: stesso mazzo da entrambe le parti, posti alternati.
import { playGame } from './duel.mjs';
import { BOT_DECKS } from '../web/js/botdecks.js';
const pairs = [['easy', 'medium'], ['medium', 'hard'], ['hard', 'nightmare']];
const n = +(process.argv[2] || 2);
const fmt = process.argv[3] || 'constructed';
for (const [lo, hi] of pairs) {
  let win = 0, tot = 0, ms = 0;
  let seed = 100;
  for (const d of BOT_DECKS.filter(x => x.format === fmt)) for (let g = 0; g < n; g++) {
    const swap = g % 2;
    const r = playGame(d, d, swap ? hi : lo, swap ? lo : hi, seed++);
    ms += r.ms;
    const w = r.G.over?.winner;
    if (w == null) continue;
    tot++;
    if ((w === 1) !== !!swap) win++;
  }
  console.log(`${hi} batte ${lo}: ${win}/${tot} (${Math.round(100 * win / tot)}%) tempo medio ${Math.round(ms / (tot || 1))}ms`);
}
