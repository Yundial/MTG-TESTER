// Partite bot contro bot con tutti i mazzi: verifica che il motore non si blocchi.
import { loadFixture } from './fixture.mjs';
import { registerCard, createGame, run, respond, DEFS } from '../web/js/engine/game.js';
import { botAnswer, seedBot } from '../web/js/engine/bot.js';
import { BOT_DECKS, parseList } from '../web/js/botdecks.js';

for (const sc of loadFixture()) registerCard(sc);
const expand = d => parseList(d.list).flatMap(x => Array(x.n).fill(x.name));
const args = process.argv.slice(2);
const games = +(args.find(a => /^\d+$/.test(a)) || 2);
const only = args.find(a => a.startsWith('--deck='))?.slice(7);
const lvlArg = args.find(a => a.startsWith('--level='))?.slice(8);
const levels = lvlArg ? lvlArg.split(',') : ['easy', 'medium', 'hard', 'nightmare'];
const verbose = args.includes('-v');

export function playGame(dA, dB, la, lb, seed) {
  seedBot(seed);
  const G = createGame({ format: dA.format, seed, players: [
    { name: 'A', deck: expand(dA), commander: dA.commander || null, bot: la },
    { name: 'B', deck: expand(dB), commander: dB.commander || null, bot: lb }] });
  run(G);
  let n = 0;
  const t0 = Date.now();
  while (!G.over && G.pending && n++ < 20000) {
    const lvl = G.players[G.pending.player].bot;
    const ans = botAnswer(G, lvl);
    respond(G, ans);
  }
  return { G, ms: Date.now() - t0, decisions: n };
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const missing = new Set();
  for (const d of BOT_DECKS) for (const x of parseList(d.list)) if (!DEFS.has(x.name)) missing.add(x.name);
  if (missing.size) console.log('MANCANTI', [...missing]);
  const stats = { A: 0, B: 0, draw: 0 };
  let seed = 1;
  const decks = BOT_DECKS.filter(d => !only || d.id.includes(only));
  let errors = 0;
  for (const dA of decks) {
    const pool = BOT_DECKS.filter(d => d.format === dA.format);
    for (let g = 0; g < games; g++) {
      const dB = pool[(g * 7 + seed) % pool.length];
      const la = levels[g % levels.length], lb = levels[(g + 1) % levels.length];
      try {
        const { G, ms, decisions } = playGame(dA, dB, la, lb, seed++);
        const w = G.over?.winner;
        if (w === 0) stats.A++; else if (w === 1) stats.B++; else stats.draw++;
        console.log(`${dA.id}(${la}) vs ${dB.id}(${lb}): ${w == null ? 'pari' : w === 0 ? 'vince A' : 'vince B'} turno ${G.turn} [${G.over?.reason}] vite ${G.players[0].life}/${G.players[1].life} ${ms}ms ${decisions} dec`);
        if (verbose) console.log(G.log.map(l => l.text).join('\n'));
        if (!G.over) { errors++; console.log('BLOCCATA', JSON.stringify(G.pending).slice(0, 300)); }
      } catch (e) { errors++; console.log('ERRORE', dA.id, dB.id, e.stack); }
    }
  }
  console.log(stats, 'errori', errors);
  if (errors) process.exit(1);
}
