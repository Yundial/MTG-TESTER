// Prova dell'interfaccia in Chromium con Scryfall simulato (dati di prova).
import { createRequire } from 'node:module';
const { chromium, devices } = createRequire(import.meta.url)(process.env.PW || 'playwright');
import { createServer } from 'node:http';
import { readFileSync, existsSync, mkdirSync } from 'node:fs';
import { extname, join } from 'node:path';
import { loadFixture } from './fixture.mjs';

const ROOT = new URL('../web/', import.meta.url).pathname;
const OUT = process.env.OUT || '/tmp/mtgt-shots';
mkdirSync(OUT, { recursive: true });
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.webmanifest': 'application/manifest+json' };
const server = createServer((req, res) => {
  let p = decodeURIComponent(new URL(req.url, 'http://x').pathname);
  if (p.endsWith('/')) p += 'index.html';
  const f = join(ROOT, p);
  if (!existsSync(f)) { res.writeHead(404); res.end(); return; }
  res.writeHead(200, { 'Content-Type': MIME[extname(f)] || 'application/octet-stream' });
  res.end(readFileSync(f));
}).listen(0);
const port = server.address().port;

const cards = loadFixture();
const byName = new Map(cards.map(c => [c.name.toLowerCase(), c]));
const en = c => ({ ...c, lang: 'en', printed_name: undefined });
const it = c => (c.printed_name ? { ...c, lang: 'it' } : null);

const browser = await chromium.launch();
const ctx = await browser.newContext({ ...devices[process.env.DEVICE || 'iPhone 13'] });
const page = await ctx.newPage();
const errors = [];
page.on('pageerror', e => errors.push('pageerror: ' + e.message));
page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
await page.route('https://api.scryfall.com/**', async route => {
  const u = new URL(route.request().url());
  if (u.pathname === '/cards/collection') {
    const body = JSON.parse(route.request().postData());
    const data = [], nf = [];
    for (const id of body.identifiers) { const c = byName.get(id.name.toLowerCase()); if (c) data.push(en(c)); else nf.push(id); }
    return route.fulfill({ json: { data, not_found: nf } });
  }
  if (u.pathname === '/cards/search') {
    const q = u.searchParams.get('q');
    const isIt = q.startsWith('lang:it');
    const names = [...q.matchAll(/!"([^"]+)"/g)].map(m => m[1].toLowerCase());
    let res;
    if (names.length) res = names.map(n => byName.get(n)).filter(Boolean);
    else {
      const words = q.replace(/lang:it/, '').split(/\s+/).filter(w => w && !/[:<>=()]/.test(w)).map(w => w.toLowerCase());
      res = cards.filter(c => words.every(w => c.name.toLowerCase().includes(w) || (c.printed_name || '').toLowerCase().includes(w)));
      const t = q.match(/t:(\w+)/); if (t) res = res.filter(c => c.type_line.toLowerCase().includes(t[1]));
    }
    res = isIt ? res.map(it).filter(Boolean) : res.map(en);
    if (!res.length) return route.fulfill({ status: 404, json: { object: 'error' } });
    return route.fulfill({ json: { data: res.slice(0, 175), has_more: false } });
  }
  return route.fulfill({ status: 404, json: {} });
});

const shot = async name => { await page.screenshot({ path: `${OUT}/${name}.png` }); };
await page.goto(`http://localhost:${port}/`);
await page.waitForSelector('.home-btn');
await shot('01-home');

// importa un mazzo
await page.click('text=I miei mazzi');
await page.click('text=Importa');
const { BOT_DECKS } = await import('../web/js/botdecks.js');
const bd = BOT_DECKS.find(d => d.id === (process.env.DECK || 'm-boros'));
const list = (bd.commander ? `Commander\n1 ${bd.commander}\n\nDeck\n` : '') + bd.list;
await page.fill('textarea', list);
await page.fill('.modal input.field', 'Il mio Boros');
await page.click('.modal-buttons >> text=Importa');
await page.waitForSelector('text=Il mio Boros');
await shot('02-decks');
await page.click('text=Il mio Boros');
await page.waitForSelector('.tabs');
await page.waitForTimeout(600);
await shot('03-editor');
// ricerca
await page.click('text=Cerca carte');
await page.fill('.search input.field', 'fulmine');
await page.click('.search >> text=Cerca');
await page.waitForSelector('.results .result');
await shot('04-search');
await page.goBack(); await page.goBack();

// partita
await page.click('text=Gioca una partita di prova');
await page.click(process.env.DECK?.startsWith('c-') ? 'text=Commander' : 'text=60 carte');
await page.click('.row-card >> nth=0');
await page.click('.row-card >> text=' + (process.env.LEVEL || 'Medio'));
await page.waitForSelector('text=Vedi/Modifica');
await shot('05-botdecks');
await page.click('.row-card >> text=' + (process.env.OPP || 'Golgari Midrange'));
await page.click('text=Inizio io');
await page.click('text=Inizia la partita');
await page.waitForSelector('.modal >> text=Tengo', { timeout: 15000 });
await shot('06-mulligan');
await page.click('.modal >> text=Tengo');

// gioca: terra + magie, poi passa; ripete per diversi turni
let turnShots = 0;
for (let i = 0; i < 400; i++) {
  await page.waitForTimeout(60);
  if (await page.locator('.modal').count()) {
    const title = await page.locator('.modal h2').first().textContent().catch(() => '');
    if (/vinto|perso|Pareggio/.test(title)) { await shot('99-end'); break; }
    // risposte automatiche ai dialoghi
    const btns = page.locator('.modal .modal-buttons button');
    const cells = page.locator('.modal .pcell');
    if (await cells.count() && !(await page.locator('.modal h2', { hasText: 'mano' }).count())) { await cells.first().click(); await page.waitForTimeout(80); }
    if (await page.locator('.modal').count()) {
      const names = await btns.allTextContents();
      const pick = ['Conferma', 'Sì', 'Tengo', 'Chiudi'].find(n => names.includes(n));
      if (pick) await btns.filter({ hasText: pick }).first().click();
      else if (await page.locator('.modal .action-btn').count()) await page.locator('.modal .action-btn').first().click();
      else if (await page.locator('.modal .menu-item').count()) await page.locator('.modal .menu-item').first().click();
      else await btns.last().click();
    }
    continue;
  }
  const primary = page.locator('.actionbar .primary');
  if (!(await primary.count())) continue;
  // carte giocabili in mano
  const playable = page.locator('.hand-card.hl');
  if (await playable.count() && Math.random() < 0.8) {
    await playable.first().click();
    await page.waitForTimeout(80);
    if (turnShots < 2) { await shot('07-action-' + turnShots); }
    if (await page.locator('.modal .action-btn').count()) await page.locator('.modal .action-btn').first().click();
    continue;
  }
  const txt = await primary.textContent();
  if (/Nessun blocco/.test(txt)) {
    const blk = page.locator('.field.me .perm.hl');
    if (await blk.count()) { await blk.first().click(); await page.waitForTimeout(60); const tg = page.locator('.field.opp .perm.target'); if (await tg.count()) { await tg.first().click(); await page.waitForTimeout(60); if (turnShots < 8) await shot('10-block-' + i); } }
  }
  if (/Attacca|Non attaccare/.test(txt) && Math.random() < 0.7) await page.locator('.actionbar .outline', { hasText: 'Tutte' }).click().catch(() => {});
  if (turnShots < 6 && i % 25 === 0) { await shot('08-board-' + turnShots); turnShots++; }
  await primary.click().catch(() => {});
}
await shot('09-final');
console.log('errori:', errors.length ? errors : 'nessuno');
const st = await page.evaluate(() => localStorage.getItem('mtgt.game') ? 'partita salvata' : 'nessuna partita salvata');
console.log(st);
await browser.close();
server.close();
