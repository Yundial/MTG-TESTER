import { loadFixture } from './fixture.mjs';
import { compileCard } from '../web/js/engine/cards.js';
let full = 0, part = 0;
const verbose = process.argv.includes('-v');
for (const sc of loadFixture()) {
  const d = compileCard(sc);
  if (d.unsupported.length) { part++; console.log('PARZIALE', d.name, '::', d.unsupported.join(' || ')); }
  else full++;
  if (verbose) console.log(d.name, JSON.stringify({ spell: d.spell, ab: d.abilities, tr: d.triggers, st: d.statics, kw: d.kw, etb: d.etb }));
}
console.log(`complete ${full}, parziali ${part}`);
